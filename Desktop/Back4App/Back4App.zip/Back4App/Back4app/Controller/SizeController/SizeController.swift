//
//  SizeController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 27/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol SizeControllerDelegate {
    func SizeSuccessResponse(dataArr : [JSON])
    func SizeFailedResponse(error : String)
    func SizeSaveSuccessResponse(sucessMsg : String)
    func FetchSizeDataResponse(dataDict : [String : JSON], sizeArray : [JSON])
}
class SizeController: NSObject {

    var delegate : SizeControllerDelegate?
    func FetchSizeList()
    {
        let api = Constant.Api.SIZE_LIST
        print("size api list ======= ", api)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequest([:], withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
           // debugPrint(data!)
            self.handleSizeResponse(response: data!)
        })
    }
    func handleSizeResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                guard let dictArr = response[Constant.Server_Key.data].array else
                {
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                }
                self.delegate?.SizeSuccessResponse(dataArr: dictArr)
                print("Size fetch Response ===========", response)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
    func SaveSizeDetails(params : [String : Any])
    {
        guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {
            return
        }
        let api = Constant.Api.SAVE_SIZE_DATA //+ uid
        print("size save api ===== ", api)
        print(params)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequestWithAccessToken(params, accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
          //  debugPrint(data!)
            self.handleSaveSizeResponse(response: data!)
        })
    }
    func handleSaveSizeResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                guard let dict = response[Constant.Server_Key.data].dictionaryObject else
                {
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                }
                self.delegate?.SizeSaveSuccessResponse(sucessMsg: response[Constant.Server_Key.message].stringValue)
                print("Size saved Response ===========", response)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
    func fetchSavedSizeData()
    {
        let api = Constant.Api.FETCH_SIZE_LIST
        guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {return}
        print("fetch size api====", api)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequestWithAccessToken([:], accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.SizeFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleFetchSizeResponse(response: data!)
        })
    }
    func handleFetchSizeResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                guard let dict = response[Constant.Server_Key.data].dictionary else
                {
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                }
                guard let arr = response[Constant.Server_Key.sizedata].array else
                {
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                }
                
                self.delegate?.FetchSizeDataResponse(dataDict: dict, sizeArray: arr)
                print("Size fetche Response ===========", response)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SizeFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
    
}
