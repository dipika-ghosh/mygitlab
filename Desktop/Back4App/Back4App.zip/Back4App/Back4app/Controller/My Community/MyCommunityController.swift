//
//  MyCommunityController.swift
//  Back4app
//
//  Created by Dipika Ghosh on 01/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol MyCommunityControllerDelegate {
     func MyCommunityControllerSuccessResponse(dataArr : [JSON])
    func MyCommunityControllerFailedResponse(error:String,status:Int)
}
class MyCommunityController: NSObject {
    var delegate : MyCommunityControllerDelegate?
    func FetchMyCommunityList()
    {
        guard let id = Utility.getObjectForKey(Constant.user_defaults_value.user_id) as? String else
        {
            return
        }
        guard let access_token = Utility.getObjectForKey(Constant.user_defaults_value.access_token) as? String else
        {
            return
        }
        let api = Constant.Api.MY_COMMUNITY_LIST + id
        print("my community api list ======= ", api)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequestWithAccessToken([:], accessToken: access_token, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
              //  self.delegate?.MyCommunityControllerFailedResponse(error: error!.localizedDescription, status: <#Int#>)
                return
            }
            guard let _ = data else {
                self.delegate?.MyCommunityControllerFailedResponse(error: error!.localizedDescription, status: data![Constant.Server_Key.status].intValue)
                return
            }
            debugPrint(data!)
            self.handleSizeResponse(response: data!)
        })
    }
    func handleSizeResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                guard let dictArr = response[Constant.Server_Key.data]["communities"].array else
                {
                    self.delegate?.MyCommunityControllerFailedResponse(error: response[Constant.Server_Key.message].stringValue, status: response[Constant.Server_Key.status].intValue)
                    return
                }
                self.delegate?.MyCommunityControllerSuccessResponse(dataArr: dictArr)
                print("Size Response ===========", response)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.MyCommunityControllerFailedResponse(error: response[Constant.Server_Key.message].stringValue, status: response[Constant.Server_Key.status].intValue)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.MyCommunityControllerFailedResponse(error: response[Constant.Server_Key.message].stringValue, status: response[Constant.Server_Key.status].intValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.MyCommunityControllerFailedResponse(error: response[Constant.Server_Key.message].stringValue, status: response[Constant.Server_Key.status].intValue)
                })
            }
        }
    }
}
