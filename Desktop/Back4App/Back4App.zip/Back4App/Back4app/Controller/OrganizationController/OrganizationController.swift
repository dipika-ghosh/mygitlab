//
//  OrganizationController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 07/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol OrganizationDelegates : AnyObject {
    func OrganizationSuccessResponse(responseArr : [JSON])
    func OrganizationFailedResponse(error : String)
}
class OrganizationController: NSObject {
    weak var delegate : OrganizationDelegates?
    func fetchOrganizationList()
    {
        let api = Constant.Api.ORGANIZATION_LIST
        print("ngo list api ------", api)
        guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {return}
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequestWithAccessToken([:], accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.OrganizationFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.OrganizationFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleResponse(response: data!)
        })
    }
    func handleResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                print(response)
                guard let dictArr = response[Constant.Server_Key.data].array else {
                    self.delegate?.OrganizationFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dictArr)
                self.delegate?.OrganizationSuccessResponse(responseArr: dictArr)
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.OrganizationFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.OrganizationFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
