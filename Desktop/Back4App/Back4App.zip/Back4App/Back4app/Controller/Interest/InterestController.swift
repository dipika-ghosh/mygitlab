//
//  InterestController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 30/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol InterestListDelegates
{
    func InterestListSuccessResponse(responseArr : [JSON])
    func InterestListFailedResponse(error : String)
}
class InterestController: NSObject {
    var delegate : InterestListDelegates?
    func FetchInterestList()
    {
        let api = Constant.Api.INTEREST_LIST
        print("Interest list api :  \(api)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequest([:], withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.InterestListFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.InterestListFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleInterestResponse(response: data!)
        })
    }
    func handleInterestResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                
                print(response)
                guard let dictArr = response[Constant.Server_Key.data].array else {
                    self.delegate?.InterestListFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dictArr)
                self.delegate?.InterestListSuccessResponse(responseArr: dictArr)
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.InterestListFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.InterestListFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
