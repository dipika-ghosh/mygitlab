//
//  CheckUserController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 01/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol CheckUserDelegates {
    func CheckUserSuccessResponse(isAvailable : Bool, message : String)
    func CheckUserFailedResponse(error : String)
}
class CheckUserController: NSObject {
    var delegate : CheckUserDelegates?
    
    func CheckUserExistance(email : String)
    {
        let api = Constant.Api.USER_EXISTANCE + email
        print("check user api ======== ", api)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequest([:], withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.CheckUserFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.CheckUserFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleCheckUserResponse(response: data!)
        })
    }
    func handleCheckUserResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                
                print(response)
                self.delegate?.CheckUserSuccessResponse(isAvailable: response[Constant.Server_Key.isAvailable].boolValue, message: response[Constant.Server_Key.message].stringValue)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.CheckUserSuccessResponse(isAvailable: response[Constant.Server_Key.isAvailable].boolValue, message: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.CheckUserFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
