//  SignUpController.swift
//  Back4app
//  Created by Dipika Ghosh on 25/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
protocol SignUpControllerDelegate{
    func SuccessResponse(responseDict : [String : Any])
    func FailedResponse(error:String)
}
class SignUpController: NSObject {
    var delegate : SignUpControllerDelegate?
    func signUP(param:[String:Any],image:UIImage){
        let api = Constant.Api.SIGN_UP
        print("Sign up api :  \(api)")
        print("\(param)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequestMultipleImageForMultiPart(param: param, withMethod: api, withImage: image,withCompletion: {(_ data: Data, _ response: URLResponse, _ error: Error?) -> Void in
            if error == nil {
                do{
                    let dic = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as!  [String:Any]
                    print("=========",dic as Any)
                    if ((dic[Constant.Server_Key.status] as! Int) == 200) {
                        DispatchQueue.main.async(execute: {() -> Void in
                            print(dic)
                            self.delegate?.SuccessResponse(responseDict: dic)
                        })
                    }
                    else
                    {
                        print(dic)
                        DispatchQueue.main.async(execute: {() -> Void in
                            self.delegate?.FailedResponse(error: (dic["message"] as? String)!)
                        })
                    }
                }
                catch{
                    DispatchQueue.main.async(execute: {() -> Void in
                        print("catch block")
                        print("Error with Json: \(error)")
                        self.delegate?.FailedResponse(error: error.localizedDescription)
                    })
                }
            }
            else {
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.FailedResponse(error: error!.localizedDescription)
                })
            }
        })
    }
    
    
}

