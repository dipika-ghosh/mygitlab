//
//  CommunityUpload.swift
//  Back4app
//
//  Created by Dipika Ghosh on 21/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol CommunityUploadDelegate {
    func CommunityUploadSuccessResponse(response: [String:AnyObject],status:String)
    func CommunityUploadFailedResponse(error: String)
    func CommunityUploadFailedResponseWith(error:String, statusCode:Int)
}
class CommunityUpload: NSObject {
    var delegate : CommunityUploadDelegate?
    func CommunityUpload(param:[String:Any]){
        let api = Constant.Api.UPLOAD_MY_COMMUNITY
        guard let access_token = Utility.getObjectForKey(Constant.user_defaults_value.access_token) as? String else
        {
            return
        }
        print("Interest list api :  \(api)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequestWithAccessToken(param, accessToken: access_token, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.CommunityUploadFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.CommunityUploadFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleCommunityUploadResponse(response: data!)
        })
    }
    func handleCommunityUploadResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                
                print(response)
                guard let dictArr = response[Constant.Server_Key.data].dictionaryObject else {
                  //  self.delegate?.CommunityUploadFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dictArr)
                delegate?.CommunityUploadSuccessResponse(response: dictArr as [String : AnyObject], status: response[Constant.Server_Key.message].stringValue)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.CommunityUploadFailedResponseWith(error: response[Constant.Server_Key.message].stringValue, statusCode: 201)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.CommunityUploadFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.CommunityUploadFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
