//
//  Parameter.swift
//  Back4app
//
//  Created by Dipika Ghosh on 25/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
struct Parameter {
    struct Registration {
        static let email                        = "email"
        static let password                     = "password"
        static let deviceToken                  = "deviceToken"
        static let deviceType                   = "deviceType"
        static let profileImage                 = "profileImage"
        static let register_type                = "register_type"
        static let name                         = "name"
        static let address                      = "address"
        static let phone                        = "phone"
        static let description                  = "description"
        static let role                         = "role"
        static let communities                  = "communities"
        static let interests                    = "interests"
        static let facebook_auth_key            = "facebook_auth_key"
        static let google_auth_key              = "google_auth_key"
        static let profileImageSocial           = "profileImageSocial"
        
    }
    struct Login {
        static let email = "email"
        static let password = "password"
        static let device_token = "device_token"
        static let device_type = "device_type"
    }
    struct SizeSave {
        static let gender = "gender"
        static let size = "size"
    }
    struct Size {
        static let size_id = "size_id"
        static let category_id = "category_id"
    }
    struct Donation {
        static let ngo_id = "ngo_id"
        static let amount = "amount"
    }
}
