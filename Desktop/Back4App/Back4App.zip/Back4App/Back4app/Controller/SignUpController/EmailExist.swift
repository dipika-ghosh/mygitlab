//  EmailExist.swift
//  Back4app
//  Created by Dipika Ghosh on 10/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
protocol EmailExistDelegate {
    func emailExistFailedResponse(error:String)
    func emailExistSuccessResponse(responseArr : [String:Any],msg:String, isAvailable:Bool)
}

class EmailExist: NSObject {
    var delegate : EmailExistDelegate?
    func emailAlredyExistOrNot(param:[String:Any]){
        let api = Constant.Api.EMAIL_EXIST_CHECK
        print("Interest list api :  \(api)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequest(param, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.emailExistFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.emailExistFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleInterestResponse(response: data!)
        })
    }
    func handleInterestResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                
                print(response)
                let dictArr = response[Constant.Server_Key.data].dictionaryObject  ?? [:]// else {
                  //  self.delegate?.emailExistFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    //return
                    
              //  }
                print(dictArr)
                let token = response[Constant.Server_Key.token].stringValue
                UserDefaults.standard.set(token, forKey: Constant.user_defaults_value.access_token)
                self.delegate?.emailExistSuccessResponse(responseArr: dictArr, msg: response[Constant.Server_Key.message].stringValue, isAvailable: response[Constant.Server_Key.isAvailable].boolValue)
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.emailExistFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.emailExistFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }

}

