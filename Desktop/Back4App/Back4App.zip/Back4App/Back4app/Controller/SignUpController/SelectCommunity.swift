//
//  SelectCommunity.swift
//  Back4app
//
//  Created by Dipika Ghosh on 27/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol SelectCommunityDelegate {
    func SelectCommunitySuccessResponse(response: [JSON])
    func SelectCommunityFailedResponse(error:String)
    func SelectCommunityFailedResponseWithStatus(error : String, statusCode : Int)
}
class SelectCommunity: NSObject {
    var delegate : SelectCommunityDelegate?
    func fetchCommunityList(interest_id:String){
        let api = Constant.Api.SELECT_COMMUNITY + interest_id
        print("Login api :  \(api)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequest([:], withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.SelectCommunityFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.SelectCommunityFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleLoginResponse(response: data!)
        })
    }
    
    
    func fetchMyCommunityList(interest_id:String){
        let api = Constant.Api.SELECT_MY_COMMUNITY + interest_id
         guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {return}
        print("Login api :  \(api)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequestWithAccessToken([:], accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.SelectCommunityFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.SelectCommunityFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleLoginResponse(response: data!)
        })
    }
    
    
    
    
    func handleLoginResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                
                print(response)
                guard let dictArr = response[Constant.Server_Key.data].array else {
                    self.delegate?.SelectCommunityFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dictArr)
                delegate?.SelectCommunitySuccessResponse(response: dictArr)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SelectCommunityFailedResponseWithStatus(error: response[Constant.Server_Key.message].stringValue, statusCode: 201)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SelectCommunityFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.SelectCommunityFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
