//
//  NonProfitableController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 02/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol NonProfitableDelegats {
    func NonProfitSuccessResponse(responseArr : [JSON])
    func NonProfitFailedResponse(error : String)
    func DonateSuccessResponse(responseDict : [String : Any], successMsg : String)
}

class NonProfitableController: NSObject {
     var delegate : NonProfitableDelegats?
    func FetchNonProfitList(id:String)
    {
        guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {
            return
        }
        let api = Constant.Api.NON_PROFIT_LIST + id
        print("non profit api ==== ", api)
         print("strToken ==== ", strToken)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendGetRequestWithAccessToken([:], accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.NonProfitFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.NonProfitFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleResponse(response: data!)
        })
        
    }
    func handleResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                print(response)
                guard let dictArr = response[Constant.Server_Key.data].array else {
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dictArr)
                self.delegate?.NonProfitSuccessResponse(responseArr: dictArr)
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
    func DonateMoney(params : [String : Any])
    {
        guard let strToken = UserDefaults.standard.value(forKey: Constant.user_defaults_value.access_token) as? String else {
            return
        }
        let api = Constant.Api.DONATE
        print("donation api======\(api)")
        print(params)
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequestWithAccessToken(params, accessToken: strToken, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            if error != nil {
                self.delegate?.NonProfitFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.NonProfitFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleDonateResponse(response: data!)
        })
    }
    func handleDonateResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                print(response)
                guard let dict = response[Constant.Server_Key.data].dictionaryObject else {
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                    
                }
                print(dict)
                self.delegate?.DonateSuccessResponse(responseDict: dict, successMsg: response[Constant.Server_Key.message].stringValue)
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.NonProfitFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
