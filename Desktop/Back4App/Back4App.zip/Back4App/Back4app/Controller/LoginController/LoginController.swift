//
//  LoginController.swift
//  Back4app
//
//  Created by Agnisikha Guria on 25/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
protocol LoginResponseDelegates {
    func LoginSuccessResponse(response : [String : Any])
    func LoginFailedResponse(error : String)
    func LoginFailedResponseWithStatus(error : String, statusCode : Int)
}

class LoginController: NSObject {
    var delegate : LoginResponseDelegates?
    func SubmitLogin(params : [String : Any])
    {
        let api = Constant.Api.LOGIN
        print("Login api :  \(api)")
        print("\(params)")
        DataManager.shared.showLoader()
        DataManager.shared.apiManager.sendPostRequest(params, withMethod: api, withCompletion: {( data: JSON?,  response: URLResponse, _ error: Error?) -> Void in
            
            
            if error != nil {
                self.delegate?.LoginFailedResponse(error: error!.localizedDescription)
                return
            }
            guard let _ = data else {
                self.delegate?.LoginFailedResponse(error: error!.localizedDescription)
                return
            }
            debugPrint(data!)
            self.handleLoginResponse(response: data!)
        })
    }
    func handleLoginResponse(response : JSON?)
    {
        if let response = response
        {
            if response[Constant.Server_Key.status].intValue == 200
            {
                guard let dict = response[Constant.Server_Key.data].dictionaryObject else
                {
                    self.delegate?.LoginFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    return
                }
                let token = response[Constant.Server_Key.token].stringValue
                UserDefaults.standard.set(token, forKey: Constant.user_defaults_value.access_token)
                self.delegate?.LoginSuccessResponse(response: dict)
                print("Login Response ===========", response)
            }
            else if response[Constant.Server_Key.status].intValue == 201
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                   // self.delegate?.LoginFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                    self.delegate?.LoginFailedResponseWithStatus(error: response[Constant.Server_Key.message].stringValue, statusCode: 201)
                })
            }
            else if response[Constant.Server_Key.status].intValue == 500
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.LoginFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
            else
            {
                print("response=======", response)
                DispatchQueue.main.async(execute: {() -> Void in
                    self.delegate?.LoginFailedResponse(error: response[Constant.Server_Key.message].stringValue)
                })
            }
        }
    }
}
