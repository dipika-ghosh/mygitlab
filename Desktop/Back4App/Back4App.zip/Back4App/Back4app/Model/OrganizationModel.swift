//
//  OrganizationModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 07/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
struct OrganizationModel {
    var ngo : NGOModel?
    var id : String?
    init(organizationModel : JSON) {
        self.id = organizationModel["_id"].stringValue
        self.ngo = NGOModel(ngoModel: (organizationModel["ngo"] as? JSON)!)
    }
}
struct NGOModel {
    var registrationNumber : String?
    var registrationDate : String?
    var name : String?
    init(ngoModel : JSON) {
        self.registrationNumber = ngoModel["registration_number"].stringValue
        self.registrationDate = ngoModel["registration_date"].stringValue
        self.name = ngoModel["name"].stringValue
    }
}
