//  SignupModel.swift
//  Back4app
//  Created by Dipika Ghosh on 26/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
class SignupModel: NSObject {
    public var data : UserData!
    public var message : String!
    public var status : Int!
    public var token : String!
    override init() {
        
    }
    init(signupModel:[String:Any]) {
        self.data = UserData(UserDataDict: signupModel["data"] as! [String : Any])
        self.message = (signupModel["message"]) as? String
        self.status = signupModel["status"] as? Int
        self.token = signupModel["token"] as? String
    }
}
class UserData : NSObject {
    
    public var v : Int!
    public var id : String!
    public var address : String!
    public var communities : [AnyObject]!
    public var createdAt : String!
    public var descriptionField : String!
    public var deviceToken : String!
    public var deviceType : String!
    public var email : String!
    public var facebookAuthKey : String!
    public var googleAuthKey : String!
    public var interests : [AnyObject]!
    public var isActive : Bool!
    public var isDeleted : Bool!
    public var isEmailVerified : Bool!
    public var name : String!
    public var password : String!
    public var phone : String!
    public var profileImage : String!
    public var registerType : String!
    public var role : String!
   // public var size : Size!
    public var updatedAt : String!
    public var verificationCode : String!
    override init() {
        
    }
    init(UserDataDict:[String:Any]) {
        self.id = UserDataDict["_id"] as? String
        self.address = UserDataDict["address"] as? String
        self.createdAt = UserDataDict["createdAt"] as? String
        self.descriptionField = UserDataDict["description"] as? String
        self.deviceToken = UserDataDict["deviceToken"] as? String
        self.email = UserDataDict["email"] as? String
        self.name = UserDataDict["name"] as? String
        self.phone = UserDataDict["phone"] as? String
        self.profileImage = UserDataDict["profileImage"] as? String
        self.registerType = UserDataDict["register_type"] as? String
        self.isEmailVerified = UserDataDict["isEmailVerified"] as? Bool
        self.facebookAuthKey = UserDataDict["facebook_auth_key"] as? String
        self.googleAuthKey = UserDataDict["google_auth_key"] as? String
        self.verificationCode = UserDataDict["verificationCode"] as? String
    }
    
}
