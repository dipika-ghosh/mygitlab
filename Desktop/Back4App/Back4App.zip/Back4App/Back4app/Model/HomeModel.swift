//
//  HomeModel.swift
//  Back4app
//
//  Created by Dipika Ghosh on 02/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
struct HomeModel
{
    var v : Int?
    var id : String?
    var createdAt : String?
    var image : String?
    var isDeleted : Bool?
    var name : String?
    var status : String?
    var updatedAt : String?
    
    init(HomeDict : JSON)
    {
        self.id = HomeDict["_id"].stringValue
        self.name = HomeDict["name"].stringValue
        self.image = HomeDict["image"].stringValue
        self.status = HomeDict["status"].stringValue
    }
    
}
