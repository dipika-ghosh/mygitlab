//
//  MyCommunityModel.swift
//  Back4app
//
//  Created by Dipika Ghosh on 01/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
/*class MyCommunityModel: NSObject {
    public var v : Int!
    public var id : String!
    public var createdAt : String!
    public var descriptionField : String!
    public var interestId : String!
    public var isDeleted : Bool!
    public var logo : String!
    public var status : String!
    public var title : String!
    public var updatedAt : String!
    override init() {
        
    }
    init(MyCommunityDict:JSON) {
        self.id = MyCommunityDict["_id"].stringValue
        self.title = MyCommunityDict["title"].stringValue
        self.logo = MyCommunityDict["logo"].stringValue
        self.status = MyCommunityDict["status"].stringValue
        self.interestId = MyCommunityDict["interest_id"].stringValue
        self.isDeleted = MyCommunityDict["isDeleted"].boolValue
        self.updatedAt = MyCommunityDict["updatedAt"].stringValue
        self.v = MyCommunityDict["__v"].intValue
        
    }
}
*/
struct MyCommunityModel {
    var v : Int?
    var id : String?
    var createdAt : String?
    var descriptionField : String?
    var interestId : String?
    var isDeleted : Bool?
    var logo : String?
    var status : String?
    var title : String?
    var updatedAt : String?
    
    init(MyCommunityDict:JSON)
    {
        self.v = MyCommunityDict["__v"].intValue
        self.id = MyCommunityDict["_id"].stringValue
        self.title = MyCommunityDict["title"].stringValue
        self.logo = MyCommunityDict["logo"].stringValue
        self.status = MyCommunityDict["status"].stringValue
        self.interestId = MyCommunityDict["interest_id"].stringValue
        self.isDeleted = MyCommunityDict["isDeleted"].boolValue
        self.updatedAt = MyCommunityDict["updatedAt"].stringValue
    }
}
