//
//  InterestModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 30/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
/*class InterestModel : NSObject
{
     var v : Int?
     var id : String?
     var createdAt : String?
     var image : String?
     var isDeleted : Bool?
     var name : String?
     var status : String?
     var updatedAt : String?
    override init() {
        
    }
    init(interestModel : JSON)
    {
        self.id = interestModel["_id"].stringValue
        self.image = interestModel["image"].stringValue
        self.name = interestModel["name"].stringValue
        self.v = interestModel["__v"].intValue
        self.createdAt = interestModel["createdAt"].stringValue
        self.isDeleted = interestModel["isDeleted"].boolValue
        self.status = interestModel["status"].stringValue
        self.updatedAt = interestModel["updatedAt"].stringValue
    }
}*/
struct InterestModel {
    var v : Int?
    var id : String?
    var createdAt : String?
    var image : String?
    var isDeleted : Bool?
    var name : String?
    var status : String?
    var updatedAt : String?
    
    init(interestModel : JSON)
    {
        self.v = interestModel["__v"].intValue
        self.id = interestModel["_id"].stringValue
        self.createdAt = interestModel["createdAt"].stringValue
        self.image = interestModel["image"].stringValue
        self.isDeleted = interestModel["isDeleted"].boolValue
        self.name = interestModel["name"].stringValue
        self.status = interestModel["status"].stringValue
        self.updatedAt = interestModel["updatedAt"].stringValue
    }
}
