//
//  UserInfoModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 10/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
struct UserInfoModel {
     var id : String?
     var address : String?
     var category = [CategoryModel]()
     var descriptionField : String?
     var deviceToken : String?
     var deviceType : String?
     var email : String?
     var facebookAuthKey : String?
     var gender : String?
     var googleAuthKey : String?
     var isActive : Bool?
     var isDeleted : Bool?
     var isEmailVerified : Bool?
     //var isFollowed : AnyObject?
     var name : String?
     var phone : String?
     var profileImage : String?
     var profileImageSocial : String?
     var registerType : String?
     var role : String?
     var sizeData = [SizeData]()
    // var userCommunities = [UserCommunity]!
     var userInterests = [InterestModel]()
     var verificationCode : String?
    
    init(userInfoModel : [String : JSON]) {
        self.gender = userInfoModel["gender"]?.stringValue
        let sizeArr = userInfoModel["sizeData"]?.array
        if let arr = sizeArr
        {
            for item in arr
            {
                let obj = SizeData(sizeData: item)
                self.sizeData.append(obj)
            }
        }
        let categoryArr = userInfoModel["categoryData"]?.array
        if let arr = categoryArr
        {
            for item in arr
            {
                let obj = CategoryModel(categoryModel: item)
                self.category.append(obj)
            }
        }
    }
}
