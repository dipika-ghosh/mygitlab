//
//  NonProfitModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 03/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
struct NonProfitModel {
    var v : Int?
    var id : String?
    var createdAt : String?
    var description : String?
    var image : String?
    var isDeleted : Bool?
    var status : String?
    var title : String?
    var updatedAt : String?
    
    init(nonProfitModel : JSON) {
        self.v = nonProfitModel["__v"].intValue
        self.id = nonProfitModel["_id"].stringValue
        self.createdAt = nonProfitModel["createdAt"].stringValue
        self.description = nonProfitModel["description"].stringValue
        self.image = nonProfitModel["image"].stringValue
        self.isDeleted = nonProfitModel["isDeleted"].boolValue
        self.status = nonProfitModel["status"].stringValue
        self.title = nonProfitModel["title"].stringValue
        self.updatedAt = nonProfitModel["updatedAt"].stringValue
    }
}

