//
//  SizeModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 31/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
struct SizeData
{
    var v : Int?
    var id : String?
    var createdAt : String?
    var isDeleted : Bool?
    var status : String?
    var title : String?
    var updatedAt : String?
    var categoryId : String?
    
    init(sizeData : JSON)
    {
        self.v = sizeData["__v"].intValue
        self.id = sizeData["_id"].stringValue
        self.createdAt = sizeData["createdAt"].stringValue
        self.isDeleted = sizeData["isDeleted"].boolValue
        self.status = sizeData["status"].stringValue
        self.title = sizeData["title"].stringValue
        self.updatedAt = sizeData["updatedAt"].stringValue
        self.categoryId = sizeData["categoryId"].stringValue
    }
}
struct SizeModel {
    var id : String?
    var isDeleted : Bool?
    var sizeData = [SizeData]()
    var status : String?
    var title : String?
    init(sizeModel : JSON)
    {
        self.id = sizeModel["_id"].stringValue
        self.isDeleted = sizeModel["isDeleted"].boolValue
        self.status = sizeModel["status"].stringValue
        self.title = sizeModel["title"].stringValue
        let sizeArr = sizeModel["sizeData"].array
        if let arr = sizeArr
        {
            for item in arr
            {
                let objItem = SizeData(sizeData: item)
                self.sizeData.append(objItem)
            }
        }
    }
}
