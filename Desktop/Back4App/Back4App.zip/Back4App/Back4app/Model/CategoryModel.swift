//
//  CategoryModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 10/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
struct CategoryModel {
     var v : Int?
     var id : String?
     var createdAt : String?
     var isDeleted : Bool?
     var status : String?
     var title : String?
     var updatedAt : String?
    init(categoryModel : JSON) {
        
    }
}
