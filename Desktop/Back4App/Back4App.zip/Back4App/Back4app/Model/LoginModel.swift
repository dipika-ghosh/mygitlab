//
//  LoginModel.swift
//  Back4app
//
//  Created by Agnisikha Guria on 27/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import SwiftyJSON
class LoginModel : NSObject
{
     var v : Int?
     var id : String?
     var address : String?
    // var communities : [AnyObject]!
     var createdAt : String?
     var descriptionField : String?
     var deviceToken : String?
     var deviceType : String?
     var email : String?
     var facebookAuthKey : String?
     var googleAuthKey : String?
    // var interests : [AnyObject]!
     var isActive : Bool?
     var isDeleted : Bool?
     var isEmailVerified : Bool?
     var name : String?
     var password : String?
     var phone : String?
     var profileImage : String?
     var registerType : String?
    // var role : loginRole?
   //  var size : loginSize?
     var updatedAt : String?
     var verificationCode : String?
    
    override init() {
        
    }
    init(loginModel : [String : Any])
    {
        self.v = loginModel["__v"] as? Int
        self.id = loginModel["_id"] as? String
        self.address = loginModel["address"] as? String
        self.createdAt = loginModel["createdAt"] as? String
        self.descriptionField = loginModel["description"] as? String
        self.deviceToken = loginModel["deviceToken"] as? String
        self.email = loginModel["email"] as? String
        self.facebookAuthKey = loginModel["facebook_auth_key"] as? String
        self.googleAuthKey = loginModel["google_auth_key"] as? String
        self.isActive = loginModel["isActive"] as? Bool
        self.isDeleted = loginModel["isDeleted"] as? Bool
        self.isEmailVerified = loginModel["isEmailVerified"] as? Bool
        self.name = loginModel["name"] as? String
        self.password = loginModel["password"] as? String
        self.phone = loginModel["phone"] as? String
        self.profileImage = loginModel["profileImage"] as? String
        self.registerType = loginModel["register_type"] as? String
    }
}
