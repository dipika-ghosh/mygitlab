//
//  SelectCommunityModel.swift
//  Back4app
//
//  Created by Dipika Ghosh on 27/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import SwiftyJSON
class SelectCommunityModel: NSObject {
    public var v : Int!
    public var id : String!
    public var brandId : [AnyObject]!
    public var createdAt : String!
    public var descriptionField : String!
    public var interestId : String!
    public var isDeleted : Bool!
    public var logo : String!
    public var status : String!
    public var title : String!
    public var updatedAt : String!
    override init() {
        
    }
    init(CommunityDict:JSON) {
         self.v = CommunityDict["__v"].intValue
         self.descriptionField = CommunityDict["description"].stringValue
         self.id = CommunityDict["_id"].stringValue
         self.createdAt = CommunityDict["createdAt"].stringValue
         self.status = CommunityDict["status"].stringValue
         self.isDeleted = CommunityDict["isDeleted"].boolValue
         self.logo = CommunityDict["logo"].stringValue
         self.title = CommunityDict["title"].stringValue
    }
}
