//  TabbarVC.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class TabbarVC: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        UITabBar.appearance().backgroundColor = UIColor.white
        let v1 = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "HomeNav") as! UINavigationController
        let v2 = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "CommunityNav") as! UINavigationController
        let v3 = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "AddNav") as! UINavigationController
        let v4 = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "SearchNav") as! UINavigationController
        let v5 = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "ProfileNav") as! UINavigationController
        //MARK: set tabbar text and unselected icon
        v1.tabBarItem = UITabBarItem(title: "Home", image: UIImage(named: "home")?.withRenderingMode(.alwaysOriginal), tag: 0)
        v2.tabBarItem = UITabBarItem(title: "Community", image: UIImage(named: "group")?.withRenderingMode(.alwaysOriginal), tag: 2)
        v3.tabBarItem = UITabBarItem(title: "Add", image: UIImage(named: "add")?.withRenderingMode(.alwaysOriginal), tag: 1)
        v4.tabBarItem = UITabBarItem(title: "Search", image: UIImage(named: "search")?.withRenderingMode(.alwaysOriginal), tag: 3)
        v5.tabBarItem = UITabBarItem(title: "Me", image: UIImage(named: "user")?.withRenderingMode(.alwaysOriginal), tag: 4)
         //MARK: set tabbar selected icon
        v1.tabBarItem.selectedImage = UIImage(named: "homeactive")?.withRenderingMode(.alwaysOriginal)
        v2.tabBarItem.selectedImage = UIImage(named: "groupactive")?.withRenderingMode(.alwaysOriginal)
        v3.tabBarItem.selectedImage = UIImage(named: "addactive")?.withRenderingMode(.alwaysOriginal)
        v4.tabBarItem.selectedImage = UIImage(named: "searchactive")?.withRenderingMode(.alwaysOriginal)
        v5.tabBarItem.selectedImage = UIImage(named: "useractive")?.withRenderingMode(.alwaysOriginal)
        //MARK: set tabbar unselected text colour
        v1.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
        v2.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
        v3.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
        v4.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
        v5.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
        //MARK: set tabbar selected text colour
        v1.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(hexString: "#F53157")], for: .selected)
        v2.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(hexString: "#F53157")], for: .selected)
        v3.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(hexString: "#F53157")], for: .selected)
        v4.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(hexString: "#F53157")], for: .selected)
        v5.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor(hexString: "#F53157")], for: .selected)
    
        self.viewControllers = [v1, v2, v3, v4, v5]
        self.selectedIndex = 0
    }
    
    
    
    
    
    
    

}
