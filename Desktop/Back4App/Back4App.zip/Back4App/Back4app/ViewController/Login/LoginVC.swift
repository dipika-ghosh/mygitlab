//  ViewController.swift
//  Back4app
//  Created by webskitters on 10/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class LoginVC: UIViewController {
    @IBOutlet weak var loginTblVw: UITableView!
    var cell : LoginCell = LoginCell()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
}

