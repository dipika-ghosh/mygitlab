//  ViewController.swift
//  Back4app
//  Created by webskitters on 10/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
import FBSDKLoginKit
import GoogleSignIn
class LoginVC: UIViewController {
    @IBOutlet weak var loginTblVw: UITableView!
    var cell : LoginCell = LoginCell()
    var nameAnimated = false
    var passAnimated = false
    var LoginParams : [String : Any] = [Parameter.Login.email : "",
                                        Parameter.Login.password : "",
                                        Parameter.Login.device_token : "",
                                        Parameter.Login.device_type : ""]
    var loginController = LoginController()
    var loginData = LoginModel()
    var objEmailExist = EmailExist()
    var firstName = NSString()
    var lastName = NSString()
    var userID = NSString()
    var email = NSString()
    var facebookProfileUrl = String()
    var selectSocialType = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loginController.delegate = self
        objEmailExist.delegate = self
    }
}
extension LoginVC : LoginResponseDelegates
{
    func LoginSuccessResponse(response: [String : Any]) {
        loginData = LoginModel(loginModel: response)
        let userId = loginData.id
        let isEmailVerified = loginData.isEmailVerified
        print("user id ===== ", userId)
        let name = loginData.name
        print("profile name ======", name)
        UserDefaults.standard.set(name, forKey: Constant.user_defaults_value.user_name)
        UserDefaults.standard.set(userId, forKey: Constant.user_defaults_value.user_id)
        UserDefaults.standard.set(isEmailVerified, forKey: Constant.user_defaults_value.isEmailVerified)
        UserDefaults.standard.set(loginData.profileImage, forKey: Constant.user_defaults_value.profileImage)
        
        DispatchQueue.main.async(execute: {() -> Void in
            DataManager.shared.hideLoader()
            let appDelegate = UIApplication.shared.delegate! as! AppDelegate
            let mainVC = TabbarVC()
            appDelegate.window?.rootViewController = mainVC
            appDelegate.window?.makeKeyAndVisible()
        })
    }
    func LoginFailedResponseWithStatus(error: String, statusCode: Int) {
        if statusCode == 201
        {
            DataManager.shared.hideLoader()
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                    self.loginTblVw.reloadData()
                })
            })
        }
    }
    func LoginFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
}
extension LoginVC : GIDSignInDelegate
{
    // MARK: - Google Sign in
        func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
                  withError error: Error!)
        {
            if let error = error {
                if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                    print("The user has not signed in before or they have since signed out.")
                } else {
                    print("\(error.localizedDescription)")
                }
                return
            }
            // Perform any operations on signed in user here.
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            if user.profile.hasImage
            {
                let imageUrl = user.profile.imageURL(withDimension: 120)
                print(imageUrl)
                DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial] = imageUrl
            }
            
            print(userId,idToken,fullName,givenName,familyName,email)
            DataManager.shared.userInfoData[Parameter.Registration.email] = email
            DataManager.shared.userInfoData[Parameter.Registration.google_auth_key] = idToken
            DataManager.shared.userInfoData[Parameter.Registration.register_type] = "google"
            DataManager.shared.userInfoData[Parameter.Registration.name] = givenName
            let param: [String:Any] = ["email" :email as Any,
                                       "register_type" : "google"
            ]
            self.objEmailExist.emailAlredyExistOrNot(param: param)
        }
        func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
                  withError error: Error!) {
            // Perform any operations when the user disconnects from app here.
            // ...
            print(error.localizedDescription)
        }
    
}

