//
//  LoginVC+Extension.swift
//  Back4app
//
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension LoginVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier:Constant.CellIdentifier.LoginCell) as! LoginCell
        cell.selectionStyle = .none
        cell.bttnCreateAccount.addTarget(self, action: #selector(SignUpAction), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension LoginVC
{
    func setupUI(){
        loginTblVw.separatorStyle = .none
        loginTblVw.tableHeaderView = UIView(frame: CGRect.zero)
        loginTblVw.tableFooterView = UIView(frame: CGRect.zero)
        loginTblVw.delegate = self
        loginTblVw.dataSource = self
        self.loginTblVw.register(UINib(nibName: Constant.NibName.LoginCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.LoginCell)
    }
    @objc func SignUpAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.SignUpVC) as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
