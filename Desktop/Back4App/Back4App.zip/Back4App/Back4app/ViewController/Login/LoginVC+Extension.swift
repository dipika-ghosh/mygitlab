//  LoginVC+Extension.swift
//  Back4app
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import GoogleSignIn
import FBSDKShareKit
import FBSDKCoreKit
import FBSDKLoginKit
import SwiftyJSON
extension LoginVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier:Constant.CellIdentifier.LoginCell) as! LoginCell
        cell.selectionStyle = .none
        cell.txtPassword.delegate = self
        cell.txtUserName.delegate = self
        cell.bttnCreateAccount.addTarget(self, action: #selector(SignUpAction), for: .touchUpInside)
        cell.bttnLogin.addTarget(self, action: #selector(LoginAction), for: .touchUpInside)
        cell.btnGoogle.addTarget(self, action: #selector(GoogleSignInAction), for: .touchUpInside)
        cell.bttnFacebook.addTarget(self, action: #selector(facebookSignInAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension LoginVC
{
    func setupUI(){
        loginTblVw.separatorStyle = .none
        loginTblVw.tableHeaderView = UIView(frame: CGRect.zero)
        loginTblVw.tableFooterView = UIView(frame: CGRect.zero)
        loginTblVw.delegate = self
        loginTblVw.dataSource = self
        self.loginTblVw.register(UINib(nibName: Constant.NibName.LoginCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.LoginCell)
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.restorePreviousSignIn()
    }
    @objc func GoogleSignInAction()
    {
        self.selectSocialType = "google"
        GIDSignIn.sharedInstance()?.delegate = self
        GIDSignIn.sharedInstance()?.signIn()
        DataManager.shared.userInfoData[Parameter.Registration.facebook_auth_key] = ""
    }
    @objc func facebookSignInAction(){
         self.selectSocialType = "facebook"
        let login : FBSDKLoginManager = FBSDKLoginManager()
        login.logOut()
        login.logIn(withReadPermissions: ["public_profile", "email"], from: nil, handler: {(result: FBSDKLoginManagerLoginResult!, error: Error!) -> Void in
            if error != nil {
                //print("Process error\(error?.description)")
            }
            else if result.isCancelled {
                print("Cancelled")
            }
            else {
                print("Logged in")
                self.getFBUserData()
            }
        })
        // facebookallapp@gmail.com
        // qwerty!@#$
    }
    @objc func SignUpAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.SignUpVC) as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func LoginAction()
    {
        if isValidated()
        {
            LoginParams[Parameter.Login.email] = cell.txtUserName.text
            LoginParams[Parameter.Login.password] = cell.txtPassword.text
            loginController.SubmitLogin(params: LoginParams)
           /* let appDelegate = UIApplication.shared.delegate! as! AppDelegate
            let mainVC = TabbarVC()
            appDelegate.window?.rootViewController = mainVC
            appDelegate.window?.makeKeyAndVisible()*/
        }
    }
    func isValidated() -> Bool {
        if (cell.txtUserName.text?.isEmpty)! || cell.txtUserName.text == "" || cell.txtUserName.text == " " {
            DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.Email_Error, vc:self )
            }
            return false
        }
        else if (Utility.validateEmail(cell.txtUserName.text!) == false)
        {
            DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.ValidEmail_Error, vc:self )
            }
            return false
        }
        else if (cell.txtPassword.text?.isEmpty)! || cell.txtPassword.text == "" || cell.txtPassword.text == " " {
            DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.Password_Error, vc:self )
            }
            return false
        }
        else {
            return true
        }
    }
    //MARK: Facebook Integration methods 😃          
    func getFBUserData()
    {
        if ((FBSDKAccessToken.current) != nil)
        {
            let graphRequest : FBSDKGraphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "email, first_name, last_name"])
            graphRequest.start(completionHandler: { (connection, result, error) -> Void in
                if ((error) != nil)
                {
                    // Process error
                    print("Error: \(String(describing: error))")
                }
                else
                {
                    print("fetched user: \(String(describing: result))")
                    let firstName : NSString = (result as! NSDictionary).value(forKey: "first_name") as! NSString
                    let lastName : NSString = (result as! NSDictionary).value(forKey: "last_name") as! NSString
                    let userID = (result as! NSDictionary).value(forKey: "id") as! NSString
                    let facebookProfileUrl = "http://graph.facebook.com/\(userID)/picture?type=large"
                    self.firstName = firstName
                    self.lastName = lastName
                    self.userID = userID
                    self.facebookProfileUrl = facebookProfileUrl
                    if let email : NSString = ((result as! NSDictionary).value(forKey: "email") as? NSString) {
                        print("====",email)
                        self.firstName = firstName
                        self.lastName = lastName
                        self.userID = userID
                        self.facebookProfileUrl = facebookProfileUrl
                        self.email = email
                        let param: [String:Any] = ["email" :email,
                                                   "register_type" : "facebook"
                        ]
                        self.objEmailExist.emailAlredyExistOrNot(param: param)
                    }else{
                         print("Account registered with phone number")
                        self.ifFBLoginUsingPhoneNo()
                    }
                }
            })
        }
    }
    func ifFBLoginUsingPhoneNo(){
        let alertController = UIAlertController(title: "Add email", message: "", preferredStyle: .alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter a valid email"
        }
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            let firstTextField = alertController.textFields![0] as UITextField
            if self.validateEmail(email: firstTextField.text!){
                self.email = firstTextField.text! as NSString
                let param: [String:Any] = ["email" :firstTextField.text!,
                                           "register_type" : "facebook"]
                self.objEmailExist.emailAlredyExistOrNot(param: param)
            }
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil )
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func validateEmail(email:String) -> Bool{
         if (Utility.validateEmail(email) == false)
        {
            DispatchQueue.main.async{
               // Utility.showAlert(message: Constant.Error_Message.ValidEmail_Error, vc:self )
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: Constant.Error_Message.ValidEmail_Error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                    self.ifFBLoginUsingPhoneNo()
                })
            }
            return false
        }
        return true
    }
}
extension LoginVC : EmailExistDelegate{
    func emailExistFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
    func emailExistSuccessResponse(responseArr: [String:Any], msg: String, isAvailable: Bool) {
        DataManager.shared.hideLoader()
        print("email exist response===",responseArr)
        if isAvailable == true{
            DispatchQueue.main.async(execute: {() -> Void in
                self.loginData = LoginModel(loginModel: responseArr)
                let userId = self.loginData.id
                let isEmailVerified = self.loginData.isEmailVerified
               // let strToken = self.loginData.
                print("user id ===== ", userId)
                let name = self.loginData.name
                print("profile name ======", name)
                UserDefaults.standard.set(name, forKey: Constant.user_defaults_value.user_name)
                UserDefaults.standard.set(userId, forKey: Constant.user_defaults_value.user_id)
                UserDefaults.standard.set(isEmailVerified, forKey: Constant.user_defaults_value.isEmailVerified)
                DispatchQueue.main.async(execute: {() -> Void in
                    DataManager.shared.hideLoader()
                    let appDelegate = UIApplication.shared.delegate! as! AppDelegate
                    let mainVC = TabbarVC()
                    appDelegate.window?.rootViewController = mainVC
                    appDelegate.window?.makeKeyAndVisible()
                })
            })
        }else
        {
            if (self.selectSocialType == "facebook"){
                DispatchQueue.main.async(execute: {() -> Void in
                    DataManager.shared.userInfoData[Parameter.Registration.name] = self.firstName
                    let device_token = Utility.getObjectForKey(Constant.user_defaults_value.device_token) as? String ?? ""
                    DataManager.shared.userInfoData[Parameter.Registration.email] = self.email
                    DataManager.shared.userInfoData[Parameter.Registration.password] = ""
                    DataManager.shared.userInfoData[Parameter.Registration.deviceToken] = device_token
                    DataManager.shared.userInfoData[Parameter.Registration.deviceType] = "iOS"
                    DataManager.shared.userInfoData[Parameter.Registration.register_type] = "facebook"
                    DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial] = self.facebookProfileUrl
                    DataManager.shared.userInfoData[Parameter.Registration.facebook_auth_key] = self.userID
                    DataManager.shared.userInfoData[Parameter.Registration.google_auth_key] = ""
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.NewCommunityVC) as! NewCommunityVC
                    self.navigationController?.pushViewController(vc, animated: true)
                })
            }else
            {
                DispatchQueue.main.async(execute: {() -> Void in
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.NewCommunityVC) as! NewCommunityVC
                    self.navigationController?.pushViewController(vc, animated: true)
                })
            }
        }
    }
}
extension LoginVC : UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == cell.txtUserName
        {
            textField.placeholder = nil
            cell.lblUserName.isHidden = false
            if !nameAnimated
            {
                cell.lblUserName.pushTransition(0.3)
                nameAnimated = true
            }
        }
        if textField == cell.txtPassword
        {
            textField.placeholder = nil
            cell.lblPassword.isHidden = false
            if !passAnimated
            {
                cell.lblPassword.pushTransition(0.3)
                passAnimated = true
            }
        }
    }
}
