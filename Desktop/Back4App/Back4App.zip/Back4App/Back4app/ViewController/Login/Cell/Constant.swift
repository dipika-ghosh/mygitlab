//  Constant.swift
//  Back4app
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
struct Constant {
    struct CellIdentifier {
        static let LoginCell                               = "LoginCell"
        static let SignUpCell                              = "SignUpCell"
        static let FashionCell                             = "FashionCell"
        static let FashionCollectionCell                   = "FashionCollectionCell"
        static let CommunitiesCell                         = "CommunitiesCell"
        static let ComunityCollectionCell                  = "ComunityCollectionCell"
        static let ComponentCell                           = "ComponentCell"
        static let SizeCell                                = "SizeCell"
        static let ShowImageCell                           = "ShowImageCell"
        static let ProfileCell                             = "ProfileCell"
        static let ItemImageCell                           = "ItemImageCell"
        static let HomeCell                                = "HomeCell"
        static let ListCollectionCell                      = "ListCollectionCell"
        static let AddCell                                 = "AddCell"
        static let SearchCell                              = "SearchCell"
        static let NavigationCell                          = "NavigationCell"
        static let PostDetailsCell                         = "PostDetailsCell"
        static let DetailsImageCell                        = "DetailsImageCell"
        static let SubmitCell                              = "SubmitCell"
        static let JoinCommunityCollectionCell             = "JoinCommunityCollectionCell"
        static let JoinCommunityCell                       = "JoinCommunityCell"
        static let ProductCell                             = "ProductCell"
        static let WhoCell                                 = "WhoCell"
        static let FollowersCell                           = "FollowersCell"
        static let WhoCell2                                = "WhoCell2"
        static let AboutCell                               = "AboutCell"
        static let NewCommunityCell1                       = "NewCommunityCell1"
        static let NewCommunityCell2                       = "NewCommunityCell2"
        static let NewCommunicationCell3                   = "NewCommunicationCell3"
        static let OrganisationListCell                    = "OrganisationListCell"

    }
    struct NibName {
        
        static let LoginCell                               = "LoginCell"
        static let SignUpCell                              = "SignUpCell"
        static let FashionCell                             = "FashionCell"
        static let FashionCollectionCell                   = "FashionCollectionCell"
        static let CommunitiesCell                         = "CommunitiesCell"
        static let ComunityCollectionCell                  = "ComunityCollectionCell"
        static let ComponentCell                           = "ComponentCell"
        static let SizeCell                                = "SizeCell"
        static let ShowImageCell                           = "ShowImageCell"
        static let HomeCell                                = "HomeCell"
        static let ListCollectionCell                      = "ListCollectionCell"
        static let ProfileCell                             = "ProfileCell"
        static let ItemImageCell                           = "ItemImageCell"
        static let AddCell                                 = "AddCell"
        static let SearchCell                              = "SearchCell"
        static let NavigationCell                          = "NavigationCell"
        static let PostDetailsCell                         = "PostDetailsCell"
        static let DetailsImageCell                        = "DetailsImageCell"
        static let SubmitCell                              = "SubmitCell"
        static let JoinCommunityCollectionCell             = "JoinCommunityCollectionCell"
        static let JoinCommunityCell                       = "JoinCommunityCell"
        static let ProductCell                             = "ProductCell"
        static let WhoCell                                 = "WhoCell"
        static let FollowersCell                           = "FollowersCell"
        static let WhoCell2                                = "WhoCell2"
        static let AboutCell                               = "AboutCell"
        static let NewCommunityCell1                       = "NewCommunityCell1"
        static let NewCommunityCell2                       = "NewCommunityCell2"
        static let NewCommunicationCell3                   = "NewCommunicationCell3"
        static let OrganisationListCell                    = "OrganisationListCell"
    }

    struct StoryBoard
    {
        static let MainStoryBoard : UIStoryboard           = UIStoryboard(name: "Main", bundle:nil)
        
        struct Identifer {
            static let LoginVC                             = "LoginVC"
            static let SignUpVC                            = "SignUpVC"
            static let ShowImageVC                         = "ShowImageVC"
            static let FashionVC                           = "FashionVC"
            static let SizeVC                              = "SizeVC"
            static let CommunitiesVC                       = "CommunitiesVC"
            static let ProfileVC                           = "ProfileVC"
            static let AddVC                               = "AddVC"
            static let SearchVC                            = "SearchVC"
            static let PostDetailsVC                       = "PostDetailsVC"
            static let HomeVC                              = "HomeVC"
            static let PostSubmitVC                        = "PostSubmitVC"
            static let JoinCommunityVC                     = "JoinCommunityVC"
            static let ProductVC                           = "ProductVC"
            static let WhoVC                               = "WhoVC"
            static let FollowersVC                         = "FollowersVC"
            static let AboutVC                             = "AboutVC"
            static let NewCommunityVC                      = "NewCommunityVC"
            static let OrganizationListVC                  = "OrganizationListVC"

        }
    }
    struct user_defaults_value {
        static let user_id                                 = "user_id"
        static let access_token                            = "token"
        static let isVerified                              = "isVerified"
        static let device_token                            = "device_token"
        static let isEmailVerified                         = "isEmailVerified"
        static let user_name                               = "user_name"
        static let profileImage                            = "profileImage"
    }
    struct Error_Message {
        static let Email_Error                          = "Please enter your email"
        static let Password_Error                       = "Please enter your password"
        static let PasswordCount_Error                  = "Please enter minimum 6 characters"
        static let ValidEmail_Error                     = "Please enter valid email id"
        static let ImageUpload_Error                    = "Please upload an image"
        static let DontHaveCamera_Error                 = "You don't have camera"
        static let Image_Upload_Sucess                  = "Image uploaded sucessfully"
        static let Fashion_Select_Error                 = "Select your fashion"
        static let Community_Selection_Error            = "Select your community"
        static let Logout_Confirmation                  = "Do you want to log out?"
        static let Amount_Error                         = "Please enter some amount"
        static let size_Selected_error                  = "Minimum one field is required"
    }
    struct Api {
        
        static let BASE_URL                              = "http://104.211.219.149:1424/api/"
        static let BASE_URL_IMAGE_PATH                   = "http://104.211.219.149:1424/"
        
        static let COMMUNITY_IMG_BASE_URL                = BASE_URL_IMAGE_PATH + "uploads/community/"
        static let INTEREST_LIST_IMAGE_BASE_URL          = "https://back4app.s3.eu-west-2.amazonaws.com/interest/"
        
        
        static let SIGN_UP                               = BASE_URL + "user/register"
        static let LOGIN                                 = BASE_URL + "user/login"
        static let SELECT_COMMUNITY                      = BASE_URL + "community/interest/"
        static let SIZE_LIST                             = BASE_URL + "size/list"
        static let INTEREST_LIST                         = BASE_URL + "interest/list"
        static let SAVE_SIZE_DATA                        = BASE_URL + "user/fashionsize"
        static let MY_COMMUNITY_LIST                     = BASE_URL + "user/user-community/"
        static let LOGOUT                                = BASE_URL + "user/logout"
        static let HOME_LIST                             = BASE_URL + "homepage/user-details/"
        static let ORGANIZATION_LIST                     = BASE_URL + "ngo/list"
        static let NON_PROFIT_LIST                       = BASE_URL + "post/search/byngo/"
        static let DONATE                                = BASE_URL + "donation/post"
        static let FETCH_SIZE_LIST                       = BASE_URL + "user/viewuser"
        static let EMAIL_EXIST_CHECK                     = BASE_URL + "user/check-user/"
        static let SELECT_MY_COMMUNITY                   = BASE_URL + "community/remaining/interest/"
        static let UPLOAD_MY_COMMUNITY                   = BASE_URL + "user/profile/add/arttribute"
        
    }
    struct Server_Key {
        static let status = "status"
        static let data = "data"
        static let message = "message"
        static let token = "token"
        static let isAvailable = "isAvailable"
        static let sizedata = "sizedata"
    }
    struct variableText
    {
        static let appName                            = "Back4App"
        static let ok                                 = "ok"
    }
}



