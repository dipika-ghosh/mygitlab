//
//  Constant.swift
//  Back4app
//
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
struct Constant {
    struct CellIdentifier {
        static let LoginCell                               = "LoginCell"
        static let SignUpCell                              = "SignUpCell"
        static let FashionCell                             = "FashionCell"
        static let FashionCollectionCell                   = "FashionCollectionCell"
        static let CommunitiesCell                         = "CommunitiesCell"
        static let ComunityCollectionCell                  = "ComunityCollectionCell"
        static let ComponentCell                           = "ComponentCell"
        static let SizeCell                                = "SizeCell"
        static let ShowImageCell                           = "ShowImageCell"
        static let ProfileCell                             = "ProfileCell"
        static let ItemImageCell                           = "ItemImageCell"
        static let HomeCell                                = "HomeCell"
        static let ListCollectionCell                      = "ListCollectionCell"
        static let AddCell                                 = "AddCell"
        static let SearchCell                              = "SearchCell"
        static let NavigationCell                          = "NavigationCell"
        static let PostDetailsCell                         = "PostDetailsCell"
        static let DetailsImageCell                        = "DetailsImageCell"
        static let JoinCommunityCell                       = "JoinCommunityCell"
        static let JoinCommunityCollectionCell = "JoinCommunityCollectionCell"
    }
    struct NibName {
        
        static let LoginCell                            = "LoginCell"
        static let SignUpCell                           = "SignUpCell"
        static let FashionCell                          = "FashionCell"
        static let FashionCollectionCell                = "FashionCollectionCell"
        static let CommunitiesCell                      = "CommunitiesCell"
        static let ComunityCollectionCell               = "ComunityCollectionCell"
        static let ComponentCell                        = "ComponentCell"
        static let SizeCell                             = "SizeCell"
        static let ShowImageCell                        = "ShowImageCell"
        static let HomeCell                             = "HomeCell"
        static let ListCollectionCell                   = "ListCollectionCell"
        static let ProfileCell                          = "ProfileCell"
        static let ItemImageCell                        = "ItemImageCell"
        static let AddCell                              = "AddCell"
        static let SearchCell                           = "SearchCell"
        static let NavigationCell                       = "NavigationCell"
        static let PostDetailsCell                      = "PostDetailsCell"
        static let DetailsImageCell                     = "DetailsImageCell"
        static let JoinCommunityCell                    = "JoinCommunityCell"
        static let JoinCommunityCollectionCell = "JoinCommunityCollectionCell"
    }

    struct StoryBoard
    {
        static let MainStoryBoard : UIStoryboard        = UIStoryboard(name: "Main", bundle:nil)
        
        struct Identifer {
            static let LoginVC                  = "LoginVC"
            static let SignUpVC                 = "SignUpVC"
            static let ShowImageVC              = "ShowImageVC"
            static let FashionVC                = "FashionVC"
            static let SizeVC                   = "SizeVC"
            static let CommunitiesVC            = "CommunitiesVC"
            static let ProfileVC                = "ProfileVC"
            static let AddVC                    = "AddVC"
            static let SearchVC                 = "SearchVC"
            static let PostDetailsVC            = "PostDetailsVC"
            static let HomeVC                   = "HomeVC"
            static let JoinCommunityVC          = "JoinCommunityVC"
        }
    }
}

