//
//  LoginCell.swift
//  Back4app
//
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import GoogleSignIn
class LoginCell: UITableViewCell {
    @IBOutlet weak var bttnLogin: UIButton!
    @IBOutlet weak var viewGmail: UIView!
    @IBOutlet weak var viewFacebook: UIView!
    @IBOutlet weak var gradVW1: UIView!
    @IBOutlet weak var gradVW2: UIView!
    @IBOutlet weak var lblFacebook: UILabel!
    @IBOutlet weak var userNameVW: UIView!
    @IBOutlet weak var lblGoogle: UILabel!
    @IBOutlet weak var bttnCreateAccount: UIButton!
    @IBOutlet weak var lblNameWidth: NSLayoutConstraint!
    @IBOutlet weak var lblPasswordWidth: NSLayoutConstraint!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var signInButton: GIDSignInButton!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var btnGoogle: UIButton!
    @IBOutlet weak var bttnFacebook: UIButton!
    
    @IBOutlet weak var passwordVW: UIView!
    @IBOutlet weak var txtPassword: UITextField!

    override func awakeFromNib() {
        super.awakeFromNib()
        userNameVW.layer.borderColor = UIColor(red: 7.0/255.0, green:  19.0/255.0, blue: 81.0/255.0, alpha: 1.0).cgColor
        userNameVW.layer.borderWidth = 0.2
        userNameVW.layer.cornerRadius = 10
        userNameVW.clipsToBounds = true
        
        passwordVW.layer.borderColor = UIColor(red: 7.0/255.0, green:  19.0/255.0, blue: 81.0/255.0, alpha: 1.0).cgColor
        passwordVW.layer.borderWidth = 0.2
        passwordVW.layer.cornerRadius = 10
        passwordVW.clipsToBounds = true
        
        viewGmail.layer.cornerRadius = 10
        viewGmail.clipsToBounds = true
        
        viewFacebook.layer.cornerRadius = 10
        viewFacebook.clipsToBounds = true
        
        gradVW1.layer.cornerRadius = 10
        gradVW1.clipsToBounds = true
        
        gradVW2.layer.cornerRadius = 10
        gradVW2.clipsToBounds = true
        
        var rect: CGRect = lblUserName.frame //get frame of label
        rect.size = (lblUserName.text?.size(withAttributes: [NSAttributedString.Key.font: UIFont(name: lblUserName.font.fontName , size: lblUserName.font.pointSize)!]))! //Calculate as per label font
        lblNameWidth.constant = rect.width
        
        var rect1: CGRect = lblPassword.frame //get frame of label
        rect1.size = (lblPassword.text?.size(withAttributes: [NSAttributedString.Key.font: UIFont(name: lblPassword.font.fontName , size: lblPassword.font.pointSize)!]))! //Calculate as per label font
        lblPasswordWidth.constant = rect1.width
        
        
        let MailTxt = NSMutableAttributedString(string: "Login in with ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        
        //let txt1 = NSMutableAttributedString(string: "Google",attributes: [NSAttributedString.Key.foregroundColor: UIColor.black,NSAttributedString.Key.font:UIFont.boldSystemFont(ofSize: 18)])
        let txt1 = NSMutableAttributedString(string: "Google",attributes: [NSAttributedString.Key.foregroundColor: UIColor.black,NSAttributedString.Key.font:UIFont.fontWorkSansMedium(fontSize: 17)])
        MailTxt.append(txt1)
    //    lblGoogle.attributedText = MailTxt

        let MailTxt1 = NSMutableAttributedString(string: "Login in with ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        
        let txt2 = NSMutableAttributedString(string: "Facebook",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font:UIFont.fontWorkSansMedium(fontSize: 17)])
        MailTxt1.append(txt2)
      //  lblFacebook.attributedText = MailTxt1
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
