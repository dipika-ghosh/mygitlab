//
//  LoginCell.swift
//  Back4app
//
//  Created by webskitters on 11/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class LoginCell: UITableViewCell {
    @IBOutlet weak var bttnLogin: UIButton!
    @IBOutlet weak var viewGmail: UIView!
    @IBOutlet weak var viewFacebook: UIView!
    @IBOutlet weak var gradVW1: UIView!
    @IBOutlet weak var gradVW2: UIView!
    @IBOutlet weak var lblFacebook: UILabel!
    @IBOutlet weak var lblGoogle: UILabel!
    @IBOutlet weak var bttnCreateAccount: UIButton!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        view1.layer.borderColor = UIColor(red: 7.0/255.0, green:  19.0/255.0, blue: 81.0/255.0, alpha: 1.0).cgColor
        view1.layer.borderWidth = 0.5
        view1.layer.cornerRadius = 10
        view1.clipsToBounds = true
        
        view2.layer.borderColor = UIColor(red: 7.0/255.0, green:  19.0/255.0, blue: 81.0/255.0, alpha: 1.0).cgColor
        view2.layer.borderWidth = 0.5
        view2.layer.cornerRadius = 10
        view2.clipsToBounds = true
        
        viewGmail.layer.cornerRadius = 10
        viewGmail.clipsToBounds = true
        
        viewFacebook.layer.cornerRadius = 10
        viewFacebook.clipsToBounds = true
        
        gradVW1.layer.cornerRadius = 10
        gradVW1.clipsToBounds = true
        
        gradVW2.layer.cornerRadius = 10
        gradVW2.clipsToBounds = true
        
        
        
        let MailTxt = NSMutableAttributedString(string: "Login in with ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        
        let txt1 = NSMutableAttributedString(string: "Google",attributes: [NSAttributedString.Key.foregroundColor: UIColor.black,NSAttributedString.Key.font:UIFont.boldSystemFont(ofSize: 18)])
        MailTxt.append(txt1)
        lblGoogle.attributedText = MailTxt

        let MailTxt1 = NSMutableAttributedString(string: "Login in with ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        
        let txt2 = NSMutableAttributedString(string: "Facebook",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font:UIFont.boldSystemFont(ofSize: 18)])
        MailTxt1.append(txt2)
        lblFacebook.attributedText = MailTxt1
        
       /* let colorTop =  UIColor(red: 245.0/255.0, green: 49.0/255.0, blue: 87.0/255.0, alpha: 1.0).cgColor
        let colorMiddle =  UIColor(red: 245.0/255.0, green: 49.0/255.0, blue: 87.0/255.0, alpha: 1.0).cgColor
        let colorBottom = UIColor(red: 183.0/255.0, green: 37.0/255.0, blue: 90.0/255.0, alpha: 1.0).cgColor
        
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [colorTop,colorMiddle,colorBottom]
        gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradient.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradient.frame = CGRect(x: 0.0, y: 0.0, width: self.bttnLogin.frame.size.width, height: self.bttnLogin.frame.size.height)
        self.bttnLogin.layer.insertSublayer(gradient, at: 0)*/
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
