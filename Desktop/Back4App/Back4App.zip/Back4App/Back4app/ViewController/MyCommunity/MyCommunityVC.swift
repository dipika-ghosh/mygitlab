//  MyCommunityVC.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class MyCommunityVC: UIViewController {
    @IBOutlet weak var tblVw: UITableView!
    @IBOutlet weak var VwPlus: UIView!
    var cell : HomeCell = HomeCell()
    var collectioncell : ListCollectionCell = ListCollectionCell()
    var objMyCommunityController = MyCommunityController()
    var objMyCommunityModel = [MyCommunityModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        objMyCommunityController.delegate = self
        objMyCommunityController.FetchMyCommunityList()
        setupUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        objMyCommunityController.FetchMyCommunityList()
    }
    @IBAction func addCommunityBttnActn(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.NewCommunityVC) as! NewCommunityVC
        DataManager.shared.communitySelectFlag = "add my community"
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
