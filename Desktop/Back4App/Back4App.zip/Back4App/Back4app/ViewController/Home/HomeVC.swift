//
//  HomeVC.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController {
    @IBOutlet weak var bttnMenu: UIButton!
    
    @IBOutlet weak var homeTblVw: UITableView!
    @IBOutlet weak var topVw: UIView!
    var cell : HomeCell = HomeCell()
    var collectioncell : ListCollectionCell = ListCollectionCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton(btnShowMenu: bttnMenu)
        setupUI()
    }
    
    
    
}
