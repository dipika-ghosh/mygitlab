//  HomeVC.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class HomeVC: BaseViewController {
    @IBOutlet weak var bttnMenu: UIButton!
    @IBOutlet weak var homeTblVw: UITableView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var topVw: UIView!
    var cell : HomeCell = HomeCell()
    var collectioncell : ListCollectionCell = ListCollectionCell()
    var objHomeController = HomeController()
    var objHomeModel = [HomeModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        objHomeController.delegate = self
        objHomeController.fetchAllInterest()
        addSlideMenuButton(btnShowMenu: bttnMenu)
        setupUI()
        guard let name = Utility.getObjectForKey(Constant.user_defaults_value.user_name) as? String else
        {
            return
        }
        self.lblName.text = name
        objHomeController.fetchAllInterest()
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        //objHomeController.fetchAllInterest()
    }

    
}

