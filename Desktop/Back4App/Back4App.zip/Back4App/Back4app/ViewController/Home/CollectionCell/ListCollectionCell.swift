//  ListCollectionCell.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class ListCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imguser: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        imguser.contentMode = .scaleToFill
        imguser.layer.cornerRadius = 10.0
        imguser.clipsToBounds = true
    }
}
