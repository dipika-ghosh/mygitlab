//  HomeVC+Extension.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension HomeVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.HomeCell) as! HomeCell
        cell.selectionStyle = .none
        cell.listCollectionVw.delegate = self
        cell.listCollectionVw.dataSource = self
        cell.listCollectionVw.register(UINib(nibName: Constant.NibName.ListCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ListCollectionCell)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height//UITableView.automaticDimension
    }
}
extension HomeVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectioncell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ListCollectionCell, for: indexPath) as! ListCollectionCell
        return collectioncell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width), height: collectionView.frame.size.height/2)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.PostDetailsVC) as! PostDetailsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension HomeVC{
    func setupUI(){
        self.homeTblVw.delegate = self
        self.homeTblVw.dataSource = self
        self.homeTblVw.tableFooterView = UIView(frame: .zero)
        self.homeTblVw.tableHeaderView = UIView(frame: .zero)
        self.homeTblVw.separatorStyle = .none
         self.homeTblVw.register(UINib(nibName: Constant.NibName.HomeCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.HomeCell)
    }
}
