//  HomeVC+Extension.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import SwiftyJSON
extension HomeVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.HomeCell) as! HomeCell
        cell.selectionStyle = .none
        cell.listCollectionVw.delegate = self
        cell.listCollectionVw.dataSource = self
        cell.listCollectionVw.register(UINib(nibName: Constant.NibName.ListCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ListCollectionCell)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height//UITableView.automaticDimension
    }
}
extension HomeVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (self.objHomeModel.count != 0){
            return self.objHomeModel.count
        }else{
            return 0
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectioncell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ListCollectionCell, for: indexPath) as! ListCollectionCell
        if (self.objHomeModel.count != 0)
        {
            collectioncell.lblTitle.text = self.objHomeModel[indexPath.row].name
            if let imgURL = self.objHomeModel[indexPath.row].image{
                collectioncell.imguser.sd_setImage(with: URL(string: imgURL), placeholderImage: UIImage(named: "travel"))
            }
        }
        return collectioncell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width), height: collectionView.frame.size.height/2)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.PostDetailsVC) as! PostDetailsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension HomeVC: HomeControllerDelegate{
    func HomeControllerSuccessResponse(dataArr: [JSON]) {
        objHomeModel.removeAll()
        for item in dataArr
        {
            let interest = HomeModel(HomeDict: item)
            self.objHomeModel.append(interest)
        }
        DispatchQueue.main.async(execute: {() -> Void in
            self.cell.listCollectionVw.reloadData()
            DataManager.shared.hideLoader()
            print("my interest array=====",dataArr)
        })
    }
    func HomeControllerFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        if error == "There was a problem finding the user."
        {
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                   // self.UnableToFindUser()
                    DataManager.shared.UnableToFindUser()
                })
            })
        }
        else
        {
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
            })
        }
    }
}
extension HomeVC{
    func setupUI(){
        self.homeTblVw.delegate = self
        self.homeTblVw.dataSource = self
        self.homeTblVw.tableFooterView = UIView(frame: .zero)
        self.homeTblVw.tableHeaderView = UIView(frame: .zero)
        self.homeTblVw.separatorStyle = .none
        self.homeTblVw.register(UINib(nibName: Constant.NibName.HomeCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.HomeCell)
    }
  /*  func UnableToFindUser()
    {
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.user_id)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.access_token)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.isVerified)
        let mainStoryboardIpad : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nav = mainStoryboardIpad.instantiateViewController(withIdentifier: "RootNavigationVC") as! RootNavigationVC
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = nav
        appDelegate.window?.makeKeyAndVisible()
    }*/
}
