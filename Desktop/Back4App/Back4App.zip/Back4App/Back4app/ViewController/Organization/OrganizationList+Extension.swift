//  OrganizationList+Extension.swift
//  Back4app
//  Created by Dipika Ghosh on 07/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension OrganizationListVC{
    func setupUI(){
        self.tblVWList.delegate = self
        self.tblVWList.dataSource = self
        self.tblVWList.tableFooterView = UIView(frame: .zero)
        self.tblVWList.tableHeaderView = UIView(frame: .zero)
        self.tblVWList.separatorStyle = .none
        self.tblVWList.register(UINib(nibName: Constant.NibName.WhoCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.WhoCell)
        self.tblVWList.register(UINib(nibName: Constant.NibName.OrganisationListCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.OrganisationListCell)
    }
}
extension OrganizationListVC :UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if organizationList.count > 0
        {
            return organizationList.count
        }
        else
        {
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier:Constant.CellIdentifier.OrganisationListCell) as! OrganisationListCell
        cell.selectionStyle = .none
        cell.lblOrganizationName.text = organizationList[indexPath.row].ngo?.name
        cell.lblRegId.text = "Registration Number : \((organizationList[indexPath.row].ngo?.registrationNumber)!)"
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.WhoVC) as! WhoVC
        vc.ngoId = organizationList[indexPath.row].id
        vc.ngoName = organizationList[indexPath.row].ngo!.name!
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
