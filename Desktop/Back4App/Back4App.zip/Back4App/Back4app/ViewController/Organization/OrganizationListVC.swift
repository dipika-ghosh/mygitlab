//  OrganizationListVC.swift
//  Back4app
//  Created by Agnisikha Guria on 07/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
class OrganizationListVC: UIViewController {
    @IBOutlet weak var gradientVw: UIView!
    @IBOutlet weak var tblVWList: UITableView!
    var cell : OrganisationListCell = OrganisationListCell()
    let organizationController = OrganizationController()
    var organizationList = [OrganizationModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        organizationController.delegate = self
        organizationController.fetchOrganizationList()
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension OrganizationListVC : OrganizationDelegates
{
    func OrganizationSuccessResponse(responseArr: [JSON]) {
        self.organizationList.removeAll()
        DataManager.shared.hideLoader()
        for item in responseArr
        {
            let obj = OrganizationModel(organizationModel: item)
            self.organizationList.append(obj)
        }
        print("ngo count === \(self.organizationList.count)")
        DispatchQueue.main.async(execute: {() -> Void in
            self.tblVWList.reloadData()
        })
    }
    func OrganizationFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
    
    
}
