//
//  OrganisationListCell.swift
//  Back4app
//
//  Created by Dipika Ghosh on 07/04/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class OrganisationListCell: UITableViewCell {

    @IBOutlet weak var lblOrganizationName: UILabel!
    @IBOutlet weak var lblRegId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
