//
//  RootNavigationVCViewController.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class RootNavigationVC: UINavigationController {
var logout = String()
    override func viewDidLoad() {
        super.viewDidLoad()

      
        
        
        
        
        
        if (logout == "logout") {
            
            let appDelegate = UIApplication.shared.delegate! as! AppDelegate
            let mainVC = TabbarVC()
            appDelegate.window?.rootViewController = mainVC
            appDelegate.window?.makeKeyAndVisible()
            
        } else {
            let mRootLoginController = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.LoginVC) as! LoginVC
            self.setViewControllers([mRootLoginController], animated: false)
        }
        
        
        
        
        
        
        
        
    }
    

    

}
