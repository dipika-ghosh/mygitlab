//
//  AddCell.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class AddCell: UITableViewCell {

    @IBOutlet weak var addVW: UIView!
    @IBOutlet weak var lblAdd: UILabel!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var imgAdd: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        addVW.layer.cornerRadius = 10
        addVW.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
