//
//  AddVC + Extensions.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension AddVC
{
    func setupUI(){
        tblAdd.separatorStyle = .none
        tblAdd.tableHeaderView = UIView(frame: CGRect.zero)
        tblAdd.tableFooterView = UIView(frame: CGRect.zero)
        tblAdd.delegate = self
        tblAdd.dataSource = self
        self.tblAdd.register(UINib(nibName: Constant.NibName.AddCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.AddCell)
    }
}
extension AddVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblAdd.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.AddCell) as! AddCell
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height //UITableView.automaticDimension
    }
}
