//  AddVC + Extensions.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import AVFoundation
import ImagePicker

extension AddVC
{
    func setupUI(){
        tblAdd.separatorStyle = .none
        tblAdd.tableHeaderView = UIView(frame: CGRect.zero)
        tblAdd.tableFooterView = UIView(frame: CGRect.zero)
        tblAdd.delegate = self
        tblAdd.dataSource = self
        self.tblAdd.register(UINib(nibName: Constant.NibName.AddCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.AddCell)
        picker.delegate = self
    }
    @objc func ChooseImage()
    {
        let config = Configuration()
        config.doneButtonTitle = "Done"
        config.noImagesTitle = "Sorry! There are no images here!"
        config.recordLocation = false
        config.allowVideoSelection = true
        
        let imagePicker = ImagePickerController(configuration: config)
        imagePicker.delegate = self
        
        present(imagePicker, animated: true, completion: nil)
    }
}
extension AddVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblAdd.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.AddCell) as! AddCell
        cell.selectionStyle = .none
        cell.btnAdd.addTarget(self, action: #selector(ChooseImage), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height //UITableView.automaticDimension
    }
}
extension AddVC :UIImagePickerControllerDelegate,UINavigationControllerDelegate,ImagePickerDelegate{
    // MARK: - ImagePickerDelegate
    
    func cancelButtonDidPress(_ imagePicker: ImagePickerController) {
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    func wrapperDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        guard images.count > 0 else { return }
       
        
//        let lightboxImages = images.map {
//            return LightboxImage(image: $0)
//        }
//
//        let lightbox = LightboxController(images: lightboxImages, startIndex: 0)
//        imagePicker.present(lightbox, animated: true, completion: nil)
    }
    
    func doneButtonDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
         print("dddd====",images.count)
        imagePicker.dismiss(animated: true, completion: nil)
    }
}
