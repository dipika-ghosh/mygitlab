//
//  AddVC.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class AddVC: UIViewController {

    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblAdd: UITableView!
    var cell : AddCell = AddCell()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }

}
