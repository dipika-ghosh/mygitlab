//  ProductVC + Extensions.swift
//  Back4app
//  Created by Agnisikha Guria on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension ProductVC
{
    func SetupUI()
    {
        tblProduct.separatorStyle = .none
        tblProduct.tableHeaderView = UIView(frame: CGRect.zero)
        tblProduct.tableFooterView = UIView(frame: CGRect.zero)
        tblProduct.delegate = self
        tblProduct.dataSource = self
        self.tblProduct.register(UINib(nibName: Constant.NibName.ProductCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.ProductCell)
    }
}
extension ProductVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblProduct.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.ProductCell) as! ProductCell
        cell.selectionStyle = .none
        cell.imgCell.image = UIImage(named: imageArray[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
