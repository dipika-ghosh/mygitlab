//
//  ProductCell.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ProductCell: UITableViewCell {

    @IBOutlet weak var imgCell: UIImageView!
    @IBOutlet weak var lblProduct: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgCell.layer.cornerRadius = 10
        imgCell.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
