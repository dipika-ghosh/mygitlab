//
//  PostSubmitVC.swift
//  Back4app
//
//  Created by Agnisikha Guria on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class PostSubmitVC: UIViewController {

    @IBOutlet weak var topVW: UIView!
    @IBOutlet weak var tblPostSubmit: UITableView!
    var collectionCell : DetailsImageCell = DetailsImageCell()
    var cell : SubmitCell = SubmitCell()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }
    

    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
