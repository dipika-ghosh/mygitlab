//
//  PostDetailsVC + Extensions.swift
//  Back4app
//
//  Created by Agnisikha Guria on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension PostSubmitVC
{
    func setupUI(){
        tblPostSubmit.separatorStyle = .none
        tblPostSubmit.tableHeaderView = UIView(frame: CGRect.zero)
        tblPostSubmit.tableFooterView = UIView(frame: CGRect.zero)
        tblPostSubmit.delegate = self
        tblPostSubmit.dataSource = self
        self.tblPostSubmit.register(UINib(nibName: Constant.NibName.SubmitCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.SubmitCell)
    }
    @objc func MoreAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.ProductVC) as! ProductVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension PostSubmitVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblPostSubmit.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.SubmitCell) as! SubmitCell
        cell.selectionStyle = .none
        cell.submitCollectionVW.delegate = self
        cell.submitCollectionVW.dataSource = self
        
        cell.submitCollectionVW.reloadData()
        cell.btnSeeMore.addTarget(self, action: #selector(MoreAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension PostSubmitVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 3
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.DetailsImageCell, for: indexPath) as! DetailsImageCell
        let image = UIImage.outlinedEllipse(size: CGSize(width: 7.0, height: 7.0), color: .white)
        collectionCell.pageControl.pageIndicatorTintColor = UIColor.init(patternImage: image!)
        collectionCell.pageControl.currentPageIndicatorTintColor = .white
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        collectionCell.pageControl.currentPage = indexPath.item
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.FollowersVC) as! FollowersVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: cell.submitCollectionVW.frame.size.width, height: cell.submitCollectionVW.frame.size.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if let _ = cell.submitCollectionVW
        {
            
            collectionCell.pageControl.currentPage = Int(scrollView.contentOffset.x) / Int(scrollView.frame.width)
        }
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
        if let _ = cell.submitCollectionVW
        {
            
            collectionCell.pageControl.currentPage = Int(scrollView.contentOffset.x) / Int(scrollView.frame.width)
        }
    }
    
}
