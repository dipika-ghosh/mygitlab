//  NavigationVC+Extension.swift
//  Back4app
//  Created by webskitters on 18/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import GoogleSignIn
extension NavigationVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTitle.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.NavigationCell) as! NavigationCell
        cell.selectionStyle = .none
        cell.lblTitle.text = arrTitle[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            print("settings")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.SizeVC) as! SizeVC
            self.navigationController?.pushViewController(vc, animated: true)

        }else if indexPath.row == 1{
            print("Profile")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.ProfileVC) as! ProfileVC
            vc.isFromNavigation = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if(indexPath.row == 2){
            print("Non Profitable organisation")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.OrganizationListVC) as! OrganizationListVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if(indexPath.row == 3){
            print("About")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.AboutVC) as! AboutVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            print("Logout")
            DispatchQueue.main.async(execute: {
                Utility.alertWithMessage(title: Constant.variableText.appName, message: Constant.Error_Message.Logout_Confirmation, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                    GIDSignIn.sharedInstance().signOut()
                    self.logoutController.LogoutAction()
            })
            })
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func setupUI(){
        self.navigationTblVW.delegate = self
        self.navigationTblVW.dataSource = self
        self.navigationTblVW.tableFooterView = UIView(frame: .zero)
        self.navigationTblVW.tableHeaderView = UIView(frame: .zero)
        self.navigationTblVW.separatorStyle = .none
        self.navigationTblVW.register(UINib(nibName: Constant.NibName.NavigationCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.NavigationCell)
    }
  /*  func UnableToFindUser()
    {
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.user_id)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.access_token)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.isVerified)
        let mainStoryboardIpad : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nav = mainStoryboardIpad.instantiateViewController(withIdentifier: "RootNavigationVC") as! RootNavigationVC
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = nav
        appDelegate.window?.makeKeyAndVisible()
    }*/
}
