//
//  NavigationVC+Extension.swift
//  Back4app
//
//  Created by webskitters on 18/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension NavigationVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.NavigationCell) as! NavigationCell
        cell.selectionStyle = .none
        cell.lblTitle.text = arrTitle[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            print("Profile")
        }else if indexPath.row == 1{
             print("Non Profitable organisation")
        }else{
            print("Logout")
            let mainStoryboardIpad : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let nav = mainStoryboardIpad.instantiateViewController(withIdentifier: "RootNavigationVC") as! RootNavigationVC
            nav.logout = "logout"
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController = nav
            appDelegate.window?.makeKeyAndVisible()
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func setupUI(){
        self.navigationTblVW.delegate = self
        self.navigationTblVW.dataSource = self
        self.navigationTblVW.tableFooterView = UIView(frame: .zero)
        self.navigationTblVW.tableHeaderView = UIView(frame: .zero)
        self.navigationTblVW.separatorStyle = .none
         self.navigationTblVW.register(UINib(nibName: Constant.NibName.NavigationCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.NavigationCell)
    }
}
