//
//  NavigationVC.swift
//  Back4app
//
//  Created by webskitters on 18/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
protocol slideMenuDelegate {
    func slideMenuItemSelectedAtIndex(_index : Int32)
}
class NavigationVC: UIViewController {

    @IBOutlet weak var bttnCross: UIButton!
    @IBOutlet weak var navigationTblVW: UITableView!
    @IBOutlet weak var contentView: UIView!
    var delegate : slideMenuDelegate?
    var btnMenu : UIButton!
    var cell : NavigationCell = NavigationCell()
    var arrTitle = ["Profile","Non Profitable Organisation","Logout"]
    override func viewDidLoad() {
        super.viewDidLoad()

       setupUI()
    }
    
    @IBAction func btnCossAction(_ sender: UIButton) {
        btnMenu.tag = 0
        
        if (self.delegate != nil) {
            var index = Int32(sender.tag)
            if(sender == self.bttnCross){
                index = -1
            }
            delegate?.slideMenuItemSelectedAtIndex(_index: index)
        }
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame = CGRect(x: UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width,height: UIScreen.main.bounds.size.height)
            self.view.layoutIfNeeded()
            self.tabBarController?.tabBar.isHidden = false
            UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
            self.view.backgroundColor = UIColor.clear
        }, completion: { (finished) -> Void in
            self.view.removeFromSuperview()
            self.removeFromParent()
        })
    }
    
    

}
