//
//  FashionCollectionCell.swift
//  Back4app
//
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class FashionCollectionCell: UICollectionViewCell {

    @IBOutlet weak var tickImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
