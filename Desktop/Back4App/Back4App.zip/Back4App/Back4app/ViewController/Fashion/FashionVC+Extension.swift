//  FashionVC+Extension.swift
//  Back4app
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension FashionVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.FashionCell) as! FashionCell
        cell.selectionStyle = .none
         cell.bttnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        cell.fashionCollectionVw.delegate = self
        cell.fashionCollectionVw.dataSource = self
        cell.fashionCollectionVw.register(UINib(nibName: Constant.NibName.FashionCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.FashionCollectionCell)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension FashionVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 8
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.FashionCollectionCell, for: indexPath) as! FashionCollectionCell
            if self.arrSelect[indexPath.item] == "1"
            {
                collectionCell.tickImg.image = #imageLiteral(resourceName: "check")
            }
            else
            {
                collectionCell.tickImg.image = #imageLiteral(resourceName: "uncheck")
            }
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        for i in 0..<arrSelect.count
        {
            if i == indexPath.item
            {
                if arrSelect[i] == "1"{
                    arrSelect[i] = "0"
                }else{
                     arrSelect[i] = "1"
                }
            }
        }
        print(self.arrSelect)
        collectionView.reloadData()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/2 - 10), height: collectionView.frame.size.height/6)
    }
}
extension FashionVC{
    func setupUI(){
        tblVwFashion.separatorStyle = .none
        tblVwFashion.tableHeaderView = UIView(frame: CGRect.zero)
        tblVwFashion.tableFooterView = UIView(frame: CGRect.zero)
        tblVwFashion.delegate = self
        tblVwFashion.dataSource = self
        self.tblVwFashion.register(UINib(nibName: Constant.NibName.FashionCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.FashionCell)
    }
    func setupArr()
    {
        for i in 0..<8
        {
            arrSelect.append("0")
        }
    }
    @objc func NextAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.JoinCommunityVC) as! JoinCommunityVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
