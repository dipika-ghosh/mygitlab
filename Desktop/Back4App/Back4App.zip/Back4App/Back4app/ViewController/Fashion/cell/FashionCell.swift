//
//  FashionCell.swift
//  Back4app
//
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class FashionCell: UITableViewCell {
    @IBOutlet weak var fashionCollectionVw: UICollectionView!
    
    @IBOutlet weak var bttnNext: UIButton!
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var progressVw: UIProgressView!
    @IBOutlet weak var gradientVw: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        
        progressVw.transform = progressVw.transform.scaledBy(x: 1, y: 5)
        progressVw.layer.cornerRadius = 10
        progressVw.clipsToBounds = true
        progressVw.layer.sublayers![1].cornerRadius = 10
        progressVw.subviews[1].clipsToBounds = true
        progressVw.progress = (((100/6) * 3) * 1/100)
        let result = progressVw.progress * 100
        let str = String(format:"%.1f", result)
        lblProgress.text = "  Progress: \(str)%"
        
        
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
