//  FashionVC.swift
//  Back4app
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class FashionVC: UIViewController {
    
    @IBOutlet weak var tblVwFashion: UITableView!
    var cell : FashionCell = FashionCell()
    var collectionCell : FashionCollectionCell = FashionCollectionCell()
    var arrSelect = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupArr()
    }
    @IBAction func bttnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
