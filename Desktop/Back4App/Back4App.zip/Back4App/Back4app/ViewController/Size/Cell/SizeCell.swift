//
//  SizeCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class SizeCell: UICollectionViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var layerVW: UIView!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var lblSelect: UILabel!
    @IBOutlet weak var btnDown: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layerVW.layer.borderColor = UIColor.lightGray.cgColor
        layerVW.layer.borderWidth = 1.0
        layerVW.layer.cornerRadius = 10.0
        layerVW.clipsToBounds = true
    }
}
