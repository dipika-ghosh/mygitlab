//
//  ComponentCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ComponentCell: UITableViewCell {

    @IBOutlet weak var imgLogo: UIImageView!
    @IBOutlet weak var sizeCollectionVW: UICollectionView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var gradVW: UIView!
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        progressBar.transform = progressBar.transform.scaledBy(x: 1, y: 5)
        progressBar.layer.cornerRadius = 10
        progressBar.clipsToBounds = true
        progressBar.layer.sublayers![1].cornerRadius = 10
        progressBar.subviews[1].clipsToBounds = true
        
//        progressBar.progress = (((100/5) * 4) * 1/100)
//        lblProgress.text = "Progress: \(progressBar.progress * 100)%"
        
        progressBar.progress = (((100/6) * 5) * 1/100)
        let result = progressBar.progress * 100
        let str = String(format:"%.1f", result)
      //  lblProgress.text = "  Progress: \(str)%"
        lblProgress.isHidden = true
        progressBar.isHidden = true
        
        gradVW.layer.cornerRadius = 10
        gradVW.clipsToBounds = true
        
        btnNext.layer.cornerRadius = 10
        btnNext.clipsToBounds = true
        
        gradVW.layer.borderWidth = 0.5
        gradVW.layer.borderColor = #colorLiteral(red: 0.6721199155, green: 0.2248106003, blue: 0.3552107811, alpha: 1)
        
        sizeCollectionVW.register(UINib(nibName: Constant.NibName.SizeCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.SizeCell)
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
