//
//  SizeVC + Extension.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import McPicker
extension SizeVC
{
    func setupUI(){
        tblSize.separatorStyle = .none
        tblSize.tableHeaderView = UIView(frame: CGRect.zero)
        tblSize.tableFooterView = UIView(frame: CGRect.zero)
        tblSize.delegate = self
        tblSize.dataSource = self
        self.tblSize.register(UINib(nibName: Constant.NibName.ComponentCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.ComponentCell)
    }
    @objc func NextAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.CommunitiesVC) as! CommunitiesVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func DownAction(sender : UIButton)
    {
        if sender.tag == 0
        {
            McPicker.showAsPopover(data: sizeArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                if let name = selections[0] {
                    self!.cell1.lblSelect.text = name
//                    let indexPath = IndexPath(item: sender.tag, section: 0)
//                    self!.cell.sizeCollectionVW.reloadItems(at: [indexPath])
                }
                }, cancelHandler: { () -> Void in
                    print("Canceled Popover")
            }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                print("Component \(componentThatChanged) changed value to \(newSelection)")
            })
        }
        else
        {
            McPicker.showAsPopover(data: shoeArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                if let name = selections[0] {
                    self!.cell1.lblSelect.text = name
                   // let indexPath = IndexPath(item: sender.tag, section: 0)
                   // self!.cell.sizeCollectionVW.reloadData()
                    
                }
                }, cancelHandler: { () -> Void in
                    print("Canceled Popover")
            }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                print("Component \(componentThatChanged) changed value to \(newSelection)")
            })
        }
    }
}
extension SizeVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblSize.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.ComponentCell) as! ComponentCell
        cell.selectionStyle = .none
        cell.sizeCollectionVW.delegate = self
        cell.sizeCollectionVW.dataSource = self
        cell.sizeCollectionVW.reloadData()
        cell.btnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension SizeVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 6
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cell1 = cell.sizeCollectionVW.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.SizeCell, for: indexPath) as! SizeCell
        cell1.lblHeading.text = " " + headingArray[indexPath.item] + " "
       // cell1.lblSelect.text = ""
        cell1.btnDown.tag = indexPath.item
        cell1.btnDown.addTarget(self, action: #selector(DownAction(sender:)), for: .touchUpInside)
        return cell1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: (collectionView.frame.size.width/2 - 10), height: collectionView.frame.size.height/4)
    }
}
