//  SizeVC + Extension.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import McPicker
extension SizeVC
{
    func setupUI(){
        tblSize.separatorStyle = .none
        tblSize.tableHeaderView = UIView(frame: CGRect.zero)
        tblSize.tableFooterView = UIView(frame: CGRect.zero)
        tblSize.delegate = self
        tblSize.dataSource = self
        self.tblSize.register(UINib(nibName: Constant.NibName.ComponentCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.ComponentCell)
    }
    @objc func NextAction()
    {
        print(arrDict)
        print(arrDict.count)
        SizeSaveParam[Parameter.SizeSave.size] = arrDict
        print(SizeSaveParam)
        if arrDict.count != 0
        {
            sizeController.SaveSizeDetails(params: SizeSaveParam)
        }else{
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: Constant.Error_Message.size_Selected_error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        }
        
    }
    @objc func DownAction(sender : UIButton)
    {
        if isFromFetch
        {
            if sender.tag == sizeFetchArr.count
            {
                self.selectedIndex = sender.tag
                McPicker.showAsPopover(data: genderDataArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                    if let name = selections[0]
                    {
                        if (self?.selecetdFetchSizeDataArr.count)! > 0
                        {
                            if self!.selecetdFetchSizeDataArr[self!.selectedIndex] != name
                            {
                                self!.selecetdFetchSizeDataArr[self!.selectedIndex] = name
                                self?.SizeSaveParam[Parameter.SizeSave.gender] = name
                            }
                        }
                        else
                        {
                            self!.selecetdFetchSizeDataArr[self!.selectedIndex].append(name)
                        }
                        print(self!.selecetdFetchSizeDataArr)
                        self!.sizeTitleVal = name
                        let index = IndexPath(item: sender.tag, section: 0)
                        self?.cell.sizeCollectionVW.reloadItems(at: [index])
                        //self!.cell.sizeCollectionVW.reloadData()
                    }
                    }, cancelHandler: { () -> Void in
                        print("Canceled Popover")
                }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                    let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                    print("Component \(componentThatChanged) changed value to \(newSelection)")
                })
            }
            else{
                self.selectedIndex = sender.tag
                self.sizeFetchPickerArr.removeAll()
                let sizeData = self.sizeFetchArr[sender.tag].sizeData
                print(sizeData.count)
                var tempArr = [String]()
                for i in sizeData{
                    tempArr.append(i.title ?? "")
                }
                let catId = self.sizeFetchArr[sender.tag].id
                self.dict[Parameter.Size.category_id] = catId
                self.sizeFetchPickerArr.append(tempArr)
                print(self.sizeFetchPickerArr)
                McPicker.showAsPopover(data: sizeFetchPickerArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                    if let name = selections[0] {
                        if (self?.selecetdFetchSizeDataArr.count)! > 0
                        {
                            if self!.selecetdFetchSizeDataArr[self!.selectedIndex] != name
                            {
                                self!.selecetdFetchSizeDataArr[self!.selectedIndex] = name
                                let sizeId = self?.getSizeId(title: name, arr: sizeData)
                                print(sizeId)
                                self?.dict[Parameter.Size.size_id] = sizeId!
                                let _ = self!.duplicacyCheck(catId: catId!)
                                self?.arrDict.append(self!.dict)
                            }
                            print(self!.arrDict)
                        }
                        else
                        {
                            self!.selecetdFetchSizeDataArr[self!.selectedIndex].append(name)
                        }
                        print(self!.selecetdFetchSizeDataArr)
                        self!.sizeTitleVal = name
                        print(self!.SizeSaveParam)
                        let index = IndexPath(item: sender.tag, section: 0)
                        self?.cell.sizeCollectionVW.reloadItems(at: [index])
                        //self!.cell.sizeCollectionVW.reloadData()
                    }
                    }, cancelHandler: { () -> Void in
                        print("Canceled Popover")
                }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                    let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                    print("Component \(componentThatChanged) changed value to \(newSelection)")
                })
            }
        }
        else{
            if sender.tag == sizeArr.count
            {
                self.selectedIndex = sizeArr.count
                McPicker.showAsPopover(data: genderDataArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                    if let name = selections[0] {
                        if (self?.selecetdSizeDataArr.count)! > 0
                        {
                            if self!.selecetdSizeDataArr[self!.selectedIndex] != name
                            {
                                self!.selecetdSizeDataArr[self!.selectedIndex] = name
                                self?.SizeSaveParam[Parameter.SizeSave.gender] = name
                            }
                        }
                        else
                        {
                            self!.selecetdSizeDataArr[self!.selectedIndex].append(name)
                        }
                        print(self!.selecetdSizeDataArr)
                        self!.sizeTitleVal = name
                        self!.cell.sizeCollectionVW.reloadData()
                    }
                    }, cancelHandler: { () -> Void in
                        print("Canceled Popover")
                }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                    let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                    print("Component \(componentThatChanged) changed value to \(newSelection)")
                })
            }
            else
            {
                self.selectedIndex = sender.tag
                self.sizeDataArr.removeAll()
                let sizeData = self.sizeArr[sender.tag].sizeData
                print(sizeData.count)
                var tempArr = [String]()
                for i in sizeData{
                    tempArr.append(i.title ?? "")
                }
                let catId = self.sizeArr[sender.tag].id
                self.dict[Parameter.Size.category_id] = catId
                self.sizeDataArr.append(tempArr)
                print(self.sizeDataArr)
                McPicker.showAsPopover(data: sizeDataArr, fromViewController: self, sourceView: sender, doneHandler: { [weak self] (selections: [Int : String]) -> Void in
                    if let name = selections[0] {
                        if (self?.selecetdSizeDataArr.count)! > 0
                        {
                            if self!.selecetdSizeDataArr[self!.selectedIndex] != name
                            {
                                self!.selecetdSizeDataArr[self!.selectedIndex] = name
                                let sizeId = self?.getSizeId(title: name, arr: sizeData)
                                print(sizeId)
                                self?.dict[Parameter.Size.size_id] = sizeId!
                                let x = self!.duplicacyCheck(catId: catId!)
                                self?.arrDict.append(self!.dict)
                            }
                            print(self!.arrDict)
                        }
                        else
                        {
                            self!.selecetdSizeDataArr[self!.selectedIndex].append(name)
                        }
                        print(self!.selecetdSizeDataArr)
                        self!.sizeTitleVal = name
                        print(self!.SizeSaveParam)
                        self!.cell.sizeCollectionVW.reloadData()
                    }
                    }, cancelHandler: { () -> Void in
                        print("Canceled Popover")
                }, selectionChangedHandler: { (selections: [Int:String], componentThatChanged: Int) -> Void  in
                    let newSelection = selections[componentThatChanged] ?? "Failed to get new selection!"
                    print("Component \(componentThatChanged) changed value to \(newSelection)")
                })
            }
        }
    }
    func duplicacyCheck(catId : String) -> Bool
    {
        var status = false
        for i in 0..<arrDict.count
        {
            let dict = arrDict[i]
            if dict[Parameter.Size.category_id] == catId
            {
                arrDict.remove(at: i)
                status = true
                break
            }
        }
        return status
    }
    func getSizeId(title : String, arr : [SizeData]) -> String
    {
        var tempStr = ""
        for i in 0..<arr.count
        {
            if title == arr[i].title
            {
                tempStr = arr[i].id!
                break
            }
        }
        return tempStr
    }
}
extension SizeVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblSize.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.ComponentCell) as! ComponentCell
        cell.selectionStyle = .none
        cell.sizeCollectionVW.delegate = self
        cell.sizeCollectionVW.dataSource = self
        cell.sizeCollectionVW.reloadData()
        cell.btnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension SizeVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if isFromFetch
        {
            let count = sizeFetchArr.count + 1
            return count
        }
        else
        {
            if sizeArr.count > 0
            {
                let count = sizeArr.count + 1
                return count
            }
            else
            {
                return 0
            }
        }
        
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        cell1 = cell.sizeCollectionVW.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.SizeCell, for: indexPath) as! SizeCell
        cell1.btnDown.tag = indexPath.item
        cell1.btnDown.addTarget(self, action: #selector(DownAction(sender:)), for: .touchUpInside)
        
        if isFromFetch
        {
            guard let _ = userInfo else {return cell1}
            if sizeFetchArr.count > 0
            {
                if indexPath.item == sizeFetchArr.count
                {
                    cell1.lblHeading.text = " Gender"
                    if selectedIndex > -1
                    {
                        cell1.lblSelect.text = selecetdFetchSizeDataArr[indexPath.item]
                    }
                    else
                    {
                        if let gender = userInfo?.gender
                        {
                            cell1.lblSelect.text = gender
                        }
                        else
                        {
                            cell1.lblSelect.text = ""
                        }
                    }
                    
                }
                else
                {
                    cell1.lblHeading.text = " " + sizeFetchArr[indexPath.item].title! + " "
                    for i in 0..<(userInfo?.sizeData.count)!
                    {
                        if selectedIndex > -1
                        {
                            cell1.lblSelect.text = self.selecetdFetchSizeDataArr[selectedIndex]
                        }
                        else
                        {
                            if sizeFetchArr[indexPath.item].id == userInfo?.sizeData[i].categoryId
                            {
                                cell1.lblSelect.text = userInfo?.sizeData[i].title
                                break
                            }
                            else
                            {
                                cell1.lblSelect.text = ""
                            }
                        }
                        
                    }
                }
            }
        }
        else
        {
            if sizeArr.count != 0{
                if indexPath.item == sizeArr.count
                {
                    cell1.lblHeading.text = " Gender"
                }
                else
                {
                    cell1.lblHeading.text = " " + sizeArr[indexPath.item].title! + " "
                }
                
                if sizeArr.count != indexPath.item{
                    if self.selectedIndex > -1
                    {
                        if indexPath.item == selectedIndex{
                            for i in 0..<sizeArr[self.selectedIndex].sizeData.count{
                                let title = sizeArr[self.selectedIndex].sizeData[i].title
                                if self.sizeTitleVal == title
                                {
                                    cell1.lblSelect.text = title
                                    break
                                }
                                else
                                {
                                    cell1.lblSelect.text = self.selecetdSizeDataArr[indexPath.item]
                                }
                            }
                        }
                        else
                        {
                            cell1.lblSelect.text = self.selecetdSizeDataArr[indexPath.item]
                        }
                    }
                }else{
                    cell1.lblSelect.text = self.selecetdSizeDataArr[indexPath.item]
                }
            }
        }
        return cell1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/2 - 10), height: collectionView.frame.size.height/4)
    }
}
