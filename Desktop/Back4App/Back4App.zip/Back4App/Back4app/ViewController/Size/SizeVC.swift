//
//  SizeVC.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class SizeVC: UIViewController {

    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblSize: UITableView!
    
    var cell : ComponentCell = ComponentCell()
    var cell1 : SizeCell = SizeCell()
    
    let headingArray = ["Shirt", "T-shirt", "Wrist", "Cap-Helmet", "Pant", "Shoe"]
    var sizeArr = [["S", "M", "L", "XL", "2XL"]]
    var shoeArr = [["4", "5", "6", "7", "8", "9"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
