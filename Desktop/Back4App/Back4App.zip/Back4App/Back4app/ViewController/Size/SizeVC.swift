//  SizeVC.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
class SizeVC: UIViewController {
    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblSize: UITableView!
    var cell : ComponentCell = ComponentCell()
    var cell1 : SizeCell = SizeCell()
    let sizeController = SizeController()
    var sizeArr = [SizeModel]()
    var SizeSaveParam : [String : Any] = [Parameter.SizeSave.gender: "",
                                          Parameter.SizeSave.size : ""]
    var itemId = String()
    var sizeDataArr = [[String]]()
    var genderDataArr = [["Male","Female","Others"]]
    var sizeTitleVal = String()
    var selectedIndex = -1
    var selecetdSizeDataArr = [String]()
    var count = 0
    var gender = String()
    var arrDict = [[String : String]]()
    var dict : [String : String] = [Parameter.Size.size_id : "",
                                    Parameter.Size.category_id : ""]
    var sizeFetchArr = [SizeModel]()
    var userInfo : UserInfoModel?
    var isFromFetch = false
    var selecetdFetchSizeDataArr = [String]()
    var sizeFetchPickerArr = [[String]]()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        sizeController.delegate = self
        sizeController.FetchSizeList()
        sizeController.fetchSavedSizeData()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func setUpDataArray()
    {
        for i in 0..<sizeFetchArr.count
        {
            for j in 0..<(userInfo?.sizeData.count)!
            {
                if sizeFetchArr[i].id == userInfo?.sizeData[j].categoryId
                {
                    self.selecetdFetchSizeDataArr[i] = (userInfo?.sizeData[j].title ?? "")
                }
            }
        }
        if let gender = userInfo?.gender
        {
            let index = selecetdFetchSizeDataArr.count - 1
            if gender != ""
            {
                self.selecetdFetchSizeDataArr[index] = gender
                self.SizeSaveParam[Parameter.SizeSave.gender] = gender
            }
        }
        print(selecetdFetchSizeDataArr)
    }
    func setUpParamDict()
    {
        self.arrDict.removeAll()
        if let _ = userInfo
        {
            if (userInfo?.sizeData.count)! > 0
            {
                for i in 0..<(userInfo?.sizeData.count)!
                {
                    dict[Parameter.Size.category_id] = userInfo?.sizeData[i].categoryId
                    dict[Parameter.Size.size_id] = userInfo?.sizeData[i].id
                    self.arrDict.append(dict)
                }
                print(arrDict.count)
                print(arrDict)
            }
        }
    }
}
extension SizeVC : SizeControllerDelegate
{
    func FetchSizeDataResponse(dataDict: [String : JSON], sizeArray: [JSON]) {
     userInfo = UserInfoModel(userInfoModel: dataDict)
        sizeFetchArr.removeAll()
        for item in sizeArray
        {
            let obj = SizeModel(sizeModel: item)
            self.sizeFetchArr.append(obj)
        }
        DataManager.shared.hideLoader()
        if (userInfo?.sizeData.count)! > 0
        {
            self.isFromFetch = true
        }
        for _ in 0..<sizeFetchArr.count+1{
            self.selecetdFetchSizeDataArr.append("")
        }
        self.setUpDataArray()
        self.setUpParamDict()
        DispatchQueue.main.async(execute: {()-> Void in
            self.tblSize.reloadData()
            DataManager.shared.hideLoader()
        })
    }
   
    
    func SizeSaveSuccessResponse(sucessMsg: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: sucessMsg, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                self.navigationController?.popViewController(animated: true)
            })
        })
    }
    func SizeSuccessResponse(dataArr: [JSON]) {
        print(dataArr)
        self.sizeArr.removeAll()
        for item in dataArr
        {
            let sizeModel = SizeModel(sizeModel: item)
            self.sizeArr.append(sizeModel)
        }
        print("size array count \(sizeArr.count)")
        for i in 0..<sizeArr.count+1{
            self.selecetdSizeDataArr.append("")
        }
        
        DispatchQueue.main.async(execute: {()-> Void in
            self.tblSize.reloadData()
            DataManager.shared.hideLoader()
        })
    }
    func SizeFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
}
