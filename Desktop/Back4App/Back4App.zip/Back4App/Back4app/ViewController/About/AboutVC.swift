//
//  AboutVC.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class AboutVC: UIViewController {

    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblAbout: UITableView!
    var cell : AboutCell = AboutCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

}
