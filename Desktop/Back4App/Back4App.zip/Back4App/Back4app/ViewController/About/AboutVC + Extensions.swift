//
//  AboutVC + Extensions.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension AboutVC
{
    func setupUI(){
        tblAbout.separatorStyle = .none
        tblAbout.tableHeaderView = UIView(frame: CGRect.zero)
        tblAbout.tableFooterView = UIView(frame: CGRect.zero)
        tblAbout.delegate = self
        tblAbout.dataSource = self
        self.tblAbout.register(UINib(nibName: Constant.NibName.AboutCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.AboutCell)
    }
    @objc func BackAction()
    {
        self.navigationController?.popViewController(animated: true)
    }
}
extension AboutVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblAbout.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.AboutCell) as! AboutCell
        cell.selectionStyle = .none
        cell.btnBack.addTarget(self, action: #selector(BackAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
