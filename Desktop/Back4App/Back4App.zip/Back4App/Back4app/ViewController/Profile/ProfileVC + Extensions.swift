//  ProfileVC + Extensions.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension ProfileVC
{
    func setupUI(){
        imgUser.layer.cornerRadius = 10
        imgUser.clipsToBounds = true
        tblProfile.separatorStyle = .none
        tblProfile.tableHeaderView = UIView(frame: CGRect.zero)
        tblProfile.tableFooterView = UIView(frame: CGRect.zero)
        tblProfile.isScrollEnabled = false
        tblProfile.delegate = self
        tblProfile.dataSource = self
        self.tblProfile.register(UINib(nibName: Constant.NibName.ProfileCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.ProfileCell)
    }
}
extension ProfileVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblProfile.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.ProfileCell) as! ProfileCell
        cell.selectionStyle = .none
        cell.profileCollectionVW.delegate = self
        cell.profileCollectionVW.dataSource = self
        cell.profileCollectionVW.reloadData()
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height //UITableView.automaticDimension
    }
}
extension ProfileVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 7
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ItemImageCell, for: indexPath) as! ItemImageCell
       
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/3 - 15), height: collectionView.frame.size.width/3)
    }
}
