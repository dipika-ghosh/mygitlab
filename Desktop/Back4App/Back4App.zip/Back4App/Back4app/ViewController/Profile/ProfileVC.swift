//  ProfileVC.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class ProfileVC: UIViewController {
    @IBOutlet weak var imgBack: UIImageView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tblProfile: UITableView!
    @IBOutlet weak var imgUser: UIImageView!
    var cell : ProfileCell = ProfileCell()
    var collectionCell : ItemImageCell = ItemImageCell()
    var isFromNavigation : Bool?
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        if let _ = isFromNavigation
        {
            if isFromNavigation!
            {
                imgBack.isHidden = false
                btnBack.isHidden = false
            }
            else
            {
                imgBack.isHidden = true
                btnBack.isHidden = true
            }
        }
        else
        {
            imgBack.isHidden = true
            btnBack.isHidden = true
        }
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
