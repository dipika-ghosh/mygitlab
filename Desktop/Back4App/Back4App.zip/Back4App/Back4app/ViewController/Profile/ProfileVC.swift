//
//  ProfileVC.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {

    @IBOutlet weak var imgBack: UIImageView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tblProfile: UITableView!
    var cell : ProfileCell = ProfileCell()
    var collectionCell : ItemImageCell = ItemImageCell()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
       
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
