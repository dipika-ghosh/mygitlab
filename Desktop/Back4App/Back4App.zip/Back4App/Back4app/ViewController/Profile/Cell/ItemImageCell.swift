//
//  ItemImageCell.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ItemImageCell: UICollectionViewCell {

    @IBOutlet weak var imgItem: UIImageView!
    @IBOutlet weak var itemVW: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        itemVW.layer.cornerRadius = 10
        itemVW.clipsToBounds = true
    }

}
