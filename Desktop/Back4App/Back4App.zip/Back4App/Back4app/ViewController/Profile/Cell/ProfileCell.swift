//
//  ProfileCell.swift
//  Back4app
//
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var nameVW: UIView!
    @IBOutlet weak var profileCollectionVW: UICollectionView!
    @IBOutlet weak var categoryVW: UIView!
    @IBOutlet weak var lowerVW: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var imgPassion: UIImageView!
    @IBOutlet weak var lblSpncr: UILabel!
    @IBOutlet weak var imgSpncr: UIImageView!
    @IBOutlet weak var lblPassion: UILabel!
    @IBOutlet weak var imgWallet: UIImageView!
    @IBOutlet weak var lblWallet: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgUser.layer.cornerRadius = 10
        imgUser.clipsToBounds = true
        
        imgSpncr.layer.borderWidth = 0.5
        imgSpncr.layer.borderColor = UIColor.black.cgColor
        imgSpncr.layer.cornerRadius = imgSpncr.frame.size.height * 0.5
        imgSpncr.clipsToBounds = true
        
        imgPassion.layer.borderWidth = 0.5
        imgPassion.layer.borderColor = UIColor.black.cgColor
        imgPassion.layer.cornerRadius = imgPassion.frame.size.height * 0.5
        imgPassion.clipsToBounds = true
        
        imgWallet.layer.borderWidth = 0.5
        imgWallet.layer.borderColor = UIColor.black.cgColor
        imgWallet.layer.cornerRadius = imgWallet.frame.size.height * 0.5
        imgWallet.clipsToBounds = true
        
         profileCollectionVW.register(UINib(nibName: Constant.NibName.ItemImageCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ItemImageCell)
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
