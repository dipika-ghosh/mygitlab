//  Extension.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension UIStoryboard {
    func instantiateViewController<T:UIViewController>(type: T.Type) -> T? {
        debugPrint(type)
        var fullName: String = NSStringFromClass(T.self)
        if let range = fullName.range(of:".", options:.backwards, range:nil, locale: nil){
            fullName = fullName.substring(from: range.upperBound)
        }
        return self.instantiateViewController(withIdentifier:fullName) as? T
    }
    class func mainStoryboard()->UIStoryboard{
        return UIStoryboard(name: "Main", bundle: nil)
    }
    class func tabBarStoryboard()->UIStoryboard{
        return UIStoryboard(name: "TabBar", bundle: nil)
    }
}
extension UIColor {
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt64()
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}
extension UIImage {
    class func outlinedEllipse(size: CGSize, color: UIColor, lineWidth: CGFloat = 1.0) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        context.setStrokeColor(color.cgColor)
        context.setLineWidth(lineWidth)
        let rect = CGRect(origin: .zero, size: size).insetBy(dx: lineWidth * 0.5, dy: lineWidth * 0.5)
        context.addEllipse(in: rect)
        context.strokePath()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}
extension UIView {
    func pushTransition(_ duration:CFTimeInterval) {
        let animation:CATransition = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name:
            CAMediaTimingFunctionName.easeInEaseOut)
        animation.type = CATransitionType.push
        animation.subtype = CATransitionSubtype.fromTop
        animation.duration = duration
        layer.add(animation, forKey: CATransitionType.push.rawValue)
    }
}
extension UIFont{
    class func fontWorkSansBlack(fontSize:CGFloat) -> UIFont? {
        return UIFont(name: "WorkSans-Black", size: fontSize)
    }
    class func fontWorkSansBold(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-Bold", size: fontSize)
    }
    class func fontWorkSansExtraBold(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-ExtraBold", size: fontSize)
    }
    class func fontWorkSansLight(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-Light", size: fontSize)
    }
    class func fontWorkSansMedium(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-Medium", size: fontSize)
    }
    class func fontWorkSansRegular(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-Regular", size: fontSize)
    }
    class func fontWorkSansSemiBold(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-SemiBold", size: fontSize)
    }
    class func fontWorkSansThin(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "WorkSans-Thin", size: fontSize)
    }
}
extension NSMutableData {
    func appendString(_ string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: false)
        append(data!)
    }
}  
extension UIImage {
    // image with rounded corners
    public func withRoundedCorners(radius: CGFloat? = nil) -> UIImage? {
        let maxRadius = min(size.width, size.height) / 2
        let cornerRadius: CGFloat
        if let radius = radius, radius > 0 && radius <= maxRadius {
            cornerRadius = radius
        } else {
            cornerRadius = maxRadius
        }
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        let rect = CGRect(origin: .zero, size: size)
        UIBezierPath(roundedRect: rect, cornerRadius: cornerRadius).addClip()
        draw(in: rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}
extension Dictionary where Value: Equatable {
    func containsValue(value : Value) -> Bool {
        return self.contains { $0.1 == value }
    }
    func someKey(forValue val: Value) -> Key? {
        return first(where: { $1 == val })?.key
    }
}
