//  NewCommunityVC+Extension.swift
//  Back4app
//  Created by Dipika Ghosh on 24/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension NewCommunityVC:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return 1
        }
        else if(section == 1){
             if interestLists.count > 0
             {
                return interestLists.count
            }
            else
             {
                return 0
            }
        }
        else
        {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            cell1 = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.NewCommunityCell1) as! NewCommunityCell1
            cell1.selectionStyle = .none
            return cell1
        case 1:
            cell2 = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.NewCommunityCell2) as! NewCommunityCell2
            cell2.selectionStyle = .none
            cell2.lblInterest.text = interestLists[indexPath.row].name
            let interestImageUrl = interestLists[indexPath.row].image!
            cell2.userImg.sd_setImage(with: URL(string:interestImageUrl), placeholderImage: UIImage(named: "travel"))
            return cell2
        default:
            cell3 = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.NewCommunicationCell3) as! NewCommunicationCell3
            cell3.selectionStyle = .none
            cell3.bttnNext.addTarget(self, action: #selector(gotoNextPage), for: .touchUpInside)
            return cell3
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1
        {
            if selectedInterest.count > 0
            {
                for _ in selectedInterest
                {
                    if selectedInterest.contains(interestLists[indexPath.row].id!)
                    {
                        break
                    }
                    else
                    {
                        self.selectedInterest.append(interestLists[indexPath.row].id!)
                    }
                }
            }
            else
            {
                self.selectedInterest.append(interestLists[indexPath.row].id!)
            }
            let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.CommunitiesVC) as! CommunitiesVC
            DataManager.shared.selectedInterest = selectedInterest
            vc.selected_id = interestLists[indexPath.row].id!
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
extension NewCommunityVC{
    func setupUI(){
        self.newCommunityTblVw.delegate = self
        self.newCommunityTblVw.dataSource = self
        self.newCommunityTblVw.tableFooterView = UIView(frame: .zero)
        self.newCommunityTblVw.tableHeaderView = UIView(frame: .zero)
        self.newCommunityTblVw.separatorStyle = .none
        self.newCommunityTblVw.register(UINib(nibName: Constant.NibName.NewCommunityCell1, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.NewCommunityCell1)
        self.newCommunityTblVw.register(UINib(nibName: Constant.NibName.NewCommunityCell2, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.NewCommunityCell2)
         self.newCommunityTblVw.register(UINib(nibName: Constant.NibName.NewCommunicationCell3, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.NewCommunicationCell3)
        interestcontroller.delegate = self
        selectedInterest.removeAll()
        interestcontroller.FetchInterestList()
    }
    @objc func gotoNextPage(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.CommunitiesVC) as! CommunitiesVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
