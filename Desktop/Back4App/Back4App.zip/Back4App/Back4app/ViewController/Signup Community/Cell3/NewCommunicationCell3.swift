//
//  NewCommunicationCell3.swift
//  Back4app
//
//  Created by Dipika Ghosh on 24/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
class NewCommunicationCell3: UITableViewCell {
    @IBOutlet weak var gradientVw: UIView!
    @IBOutlet weak var progressVw: UIProgressView!
    
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var bttnNext: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        progressVw.transform = progressVw.transform.scaledBy(x: 1, y: 5)
        progressVw.layer.cornerRadius = 10
        progressVw.clipsToBounds = true
        progressVw.layer.sublayers![1].cornerRadius = 10
        progressVw.subviews[1].clipsToBounds = true
        
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
        
        bttnNext.layer.cornerRadius = 10
        bttnNext.clipsToBounds = true
        
        progressVw.progress = (((100/6) * 4) * 1/100)
        let result = progressVw.progress * 100
        let str = String(format:"%.1f", result)
        lblProgress.text = "  Progress: \(str)%"
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
