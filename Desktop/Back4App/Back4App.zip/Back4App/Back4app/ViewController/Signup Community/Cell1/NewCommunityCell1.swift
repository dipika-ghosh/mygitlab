//
//  NewCommunityCell1.swift
//  Back4app
//
//  Created by Dipika Ghosh on 24/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class NewCommunityCell1: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
