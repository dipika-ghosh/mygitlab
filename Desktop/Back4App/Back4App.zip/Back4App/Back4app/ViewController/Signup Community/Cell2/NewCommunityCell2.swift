//  NewCommunityCell2.swift
//  Back4app
//  Created by Dipika Ghosh on 24/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class NewCommunityCell2: UITableViewCell {
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var lblInterest: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        userImg.contentMode = .scaleAspectFill
        userImg.layer.cornerRadius = 10.0
        userImg.clipsToBounds = true
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
