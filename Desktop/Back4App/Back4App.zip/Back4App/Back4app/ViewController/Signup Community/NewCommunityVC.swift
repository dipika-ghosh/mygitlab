//  NewCommunityVC.swift
//  Back4app
//  Created by Dipika Ghosh on 24/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
class NewCommunityVC: UIViewController {
    @IBOutlet weak var newCommunityTblVw: UITableView!
    var cell1:NewCommunityCell1 = NewCommunityCell1()
    var cell2 : NewCommunityCell2 = NewCommunityCell2()
    var cell3 : NewCommunicationCell3 = NewCommunicationCell3()
    let interestcontroller = InterestController()
    var interestLists = [InterestModel]()
    var selectedInterest = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
       setupUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension NewCommunityVC : InterestListDelegates
{
    func InterestListSuccessResponse(responseArr: [JSON]) {
        interestLists.removeAll()
        for item in responseArr
        {
            let interest = InterestModel(interestModel: item)
            self.interestLists.append(interest)
        }
        print("ineterest count \(interestLists.count)")
        DispatchQueue.main.async(execute: {() -> Void in
            self.newCommunityTblVw.reloadData()
            DataManager.shared.hideLoader()
        })
    }
    func InterestListFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
}
