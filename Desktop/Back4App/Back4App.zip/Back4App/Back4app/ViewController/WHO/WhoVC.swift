//  WhoVC.swift
//  Back4app
//  Created by Dipika Ghosh on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import McPicker
import SwiftyJSON
class WhoVC: UIViewController {
    @IBOutlet weak var whoTblVw: UITableView!
    @IBOutlet weak var gradientVW: UIView!
    @IBOutlet weak var vwDonate: UIView!
    @IBOutlet weak var closeImg: UIImageView!
    @IBOutlet weak var txtCurrency: UITextField!
    var cell : WhoCell = WhoCell()
    var cell2 : WhoCell2 = WhoCell2()
    var indicatorBackView: UIView!
    var activityView = UIActivityIndicatorView(style: .whiteLarge)
    @IBOutlet weak var bttnDonate: UIButton!
    @IBOutlet weak var gradientVw: UIView!
    @IBOutlet weak var lblNgoName: UILabel!
    //var currencyArr = [["$", "€"]]
    let nonProfitController = NonProfitableController()
    var nonProfitList = [NonProfitModel]()
    var DonationParam : [String : Any] = [Parameter.Donation.ngo_id : "",
                                          Parameter.Donation.amount: ""]

    var ngoId : String?
    var ngoName = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        nonProfitController.delegate = self
        guard let _ = ngoId else {return}
        nonProfitController.FetchNonProfitList(id:ngoId!)
        DonationParam[Parameter.Donation.ngo_id] = ngoId
        self.lblNgoName.text = ngoName
    }
    @IBAction func btnDonateAction(_ sender: Any) {
        let validated : () -> Bool = {
            if self.txtCurrency.text == "" || self.txtCurrency.text == " " || self.txtCurrency.text?.lowercased() == "enter amount"
            {
                Utility.showAlert(message: Constant.Error_Message.Amount_Error, vc: self)
                return false
            }
            else
            {
                return true
            }
        }
        if validated()
        {
            DonationParam[Parameter.Donation.amount] = txtCurrency.text
            nonProfitController.DonateMoney(params: DonationParam)
        }
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func bttnSelectCurrency(_ sender: UIButton) {
        
    }

    }
extension WhoVC : NonProfitableDelegats
{
    func DonateSuccessResponse(responseDict: [String : Any], successMsg: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: successMsg, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                self.view.endEditing(true)
                self.indicatorBackView.isHidden = true
                self.vwDonate.isHidden = true
                self.closeImg.isHidden = true
            })
        })
    }
    
   
    func NonProfitSuccessResponse(responseArr: [JSON]) {
        self.nonProfitList.removeAll()
        DataManager.shared.hideLoader()
        for item in responseArr
        {
            let obj = NonProfitModel(nonProfitModel: item)
            self.nonProfitList.append(obj)
        }
        print("non profit list count \(self.nonProfitList.count)")
        DispatchQueue.main.async(execute: {() -> Void in
            self.whoTblVw.reloadData()
        })
    }
    func NonProfitFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                 self.navigationController?.popViewController(animated: true)
            })
        })
    }
}
extension WhoVC : UITextFieldDelegate
{
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == txtCurrency
        {
            DonationParam[Parameter.Donation.amount] = txtCurrency.text
        }
    }
}
