//  WhoVC+Extension.swift
//  Back4app
//  Created by Dipika Ghosh on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import McPicker
extension WhoVC:UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            if nonProfitList.count > 0
            {
                return nonProfitList.count
            }
            else
            {
                return 0
            }
        }
        else
        {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            cell = tableView.dequeueReusableCell(withIdentifier: Constant.NibName.WhoCell) as! WhoCell
            cell.selectionStyle = .none
            cell.lblTitle.text = nonProfitList[indexPath.row].title
            cell.lblDetails.text = nonProfitList[indexPath.row].description
            cell.userImg.sd_setImage(with: URL(string:self.nonProfitList[indexPath.row].image!), placeholderImage: UIImage(named: "model"))
            return cell
        default:
            cell2 = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.WhoCell2) as! WhoCell2
            cell2.selectionStyle = .none
            cell2.bttnDonate.addTarget(self, action: #selector(donateNow), for: .touchUpInside)
            return cell2
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension WhoVC{
    @objc func donateNow(){
        print("Donate Now")
      self.view.endEditing(true)
        indicatorBackView.isHidden = false
        vwDonate.isHidden = false
         closeImg.isHidden = false
    }
    func setupUI(){
        self.whoTblVw.delegate = self
        self.whoTblVw.dataSource = self
        self.whoTblVw.tableFooterView = UIView(frame: .zero)
        self.whoTblVw.tableHeaderView = UIView(frame: .zero)
        self.whoTblVw.separatorStyle = .none
        self.whoTblVw.register(UINib(nibName: Constant.NibName.WhoCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.WhoCell)
         self.whoTblVw.register(UINib(nibName: Constant.NibName.WhoCell2, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.WhoCell2)
        txtCurrency.delegate = self
        setupVW()
    }
   private func setupVW()
    {
        indicatorBackView = UIView(frame: CGRect(x: self.view.frame.origin.x - 30, y: self.view.frame.origin.y - 100, width:
            self.view.frame.width, height: self.view.frame.height))
        indicatorBackView.backgroundColor = UIColor(hexString: "#EEF2F6").withAlphaComponent(0.8)
        indicatorBackView.isHidden = true
        vwDonate.isHidden = true
        closeImg.isHidden = true
        self.indicatorBackView.translatesAutoresizingMaskIntoConstraints = true
        self.indicatorBackView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.gradientVW.addSubview(indicatorBackView)
        activityView.translatesAutoresizingMaskIntoConstraints = false
        self.gradientVW.addSubview(activityView)
        activityView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        activityView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        let tapevent = UITapGestureRecognizer(target: self, action: #selector(self.handleTapEvent(_:)))
        indicatorBackView.addGestureRecognizer(tapevent)
        indicatorBackView.isUserInteractionEnabled = true
        vwDonate.layer.cornerRadius = 10
        vwDonate.clipsToBounds = true
        bttnDonate.layer.cornerRadius = 10
        bttnDonate.clipsToBounds = true
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
        self.gradientVW.addSubview(closeImg)
        self.gradientVW.bringSubviewToFront(vwDonate)
    }
    @objc func handleTapEvent(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
        indicatorBackView.isHidden = true
        vwDonate.isHidden = true
        closeImg.isHidden = true
    }

}
