//  WhoCell.swift
//  Back4app
//  Created by Dipika Ghosh on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class WhoCell: UITableViewCell {
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        userImg.layer.cornerRadius = 10
        userImg.clipsToBounds = true
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
