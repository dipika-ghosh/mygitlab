//  WhoCell2.swift
//  Back4app
//  Created by Dipika Ghosh on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class WhoCell2: UITableViewCell {
    @IBOutlet weak var bttnDonate: UIButton!
    @IBOutlet weak var gradientVw: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
        
        bttnDonate.layer.cornerRadius = 10
        bttnDonate.clipsToBounds = true
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
