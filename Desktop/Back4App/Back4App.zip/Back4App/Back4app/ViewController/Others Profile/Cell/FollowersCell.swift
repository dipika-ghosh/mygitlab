//
//  FollowersCell.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class FollowersCell: UITableViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var lblFollow: UILabel!
    @IBOutlet weak var imgFollow: UIImageView!
    @IBOutlet weak var collectioncVWFollower: UICollectionView!
    @IBOutlet weak var imgSpncr: UIImageView!
    @IBOutlet weak var imgPassion: UIImageView!
    @IBOutlet weak var lblSpncr: UILabel!
    @IBOutlet weak var lblPassion: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectioncVWFollower.register(UINib(nibName: Constant.NibName.ItemImageCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ItemImageCell)
        imgSpncr.layer.borderWidth = 0.5
        imgSpncr.layer.borderColor = UIColor.black.cgColor
        imgSpncr.layer.cornerRadius = imgSpncr.frame.size.height * 0.5
        imgSpncr.clipsToBounds = true
        
        imgPassion.layer.borderWidth = 0.5
        imgPassion.layer.borderColor = UIColor.black.cgColor
        imgPassion.layer.cornerRadius = imgPassion.frame.size.height * 0.5
        imgPassion.clipsToBounds = true

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
