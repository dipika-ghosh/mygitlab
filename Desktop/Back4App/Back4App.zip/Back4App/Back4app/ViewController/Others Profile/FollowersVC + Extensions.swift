//
//  FollowersVC + Extensions.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension FollowersVC
{
    func setupUI(){
        imgUser.layer.cornerRadius = 10
        imgUser.clipsToBounds = true
        tblFollowers.separatorStyle = .none
        tblFollowers.tableHeaderView = UIView(frame: CGRect.zero)
        tblFollowers.tableFooterView = UIView(frame: CGRect.zero)
        tblFollowers.isScrollEnabled = false
        tblFollowers.delegate = self
        tblFollowers.dataSource = self
        self.tblFollowers.register(UINib(nibName: Constant.NibName.FollowersCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.FollowersCell)
    }
}
extension FollowersVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblFollowers.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.FollowersCell) as! FollowersCell
        cell.selectionStyle = .none
        cell.collectioncVWFollower.delegate = self
        cell.collectioncVWFollower.dataSource = self
        cell.collectioncVWFollower.reloadData()
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height //UITableView.automaticDimension
    }
}
extension FollowersVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 1
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ItemImageCell, for: indexPath) as! ItemImageCell
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/3 - 15), height: collectionView.frame.size.width/3)
    }
}
