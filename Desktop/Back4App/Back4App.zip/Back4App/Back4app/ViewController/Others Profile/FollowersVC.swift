//
//  FollowersVC.swift
//  Back4app
//
//  Created by Agnisikha Guria on 23/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class FollowersVC: UIViewController {

    @IBOutlet weak var tblFollowers: UITableView!
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var imgBack: UIImageView!
    var cell : FollowersCell = FollowersCell()
    var collectionCell : ItemImageCell = ItemImageCell()

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
