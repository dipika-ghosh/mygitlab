//
//  PostDetailsCell.swift
//  Back4app
//
//  Created by Agnisikha Guria on 19/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class PostDetailsCell: UITableViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var imgHeart: UIImageView!
    @IBOutlet weak var imgBag: UIImageView!
    @IBOutlet weak var imgAddFriend: UIImageView!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var postCollectionVW: UICollectionView!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var btnSeeMore: UIButton!
    @IBOutlet weak var btnTellUs: UIButton!
    @IBOutlet weak var gradVW1: UIView!
    @IBOutlet weak var gradVW2: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        postCollectionVW.register(UINib(nibName: Constant.NibName.DetailsImageCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.DetailsImageCell)
        postCollectionVW.isPagingEnabled = true
        
        gradVW1.layer.cornerRadius = 10
        gradVW1.clipsToBounds = true
        
        gradVW2.layer.cornerRadius = 10
        gradVW2.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
