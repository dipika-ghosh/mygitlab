//
//  DetailsImageCell.swift
//  Back4app
//
//  Created by Agnisikha Guria on 19/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class DetailsImageCell: UICollectionViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var pageControl: UIPageControl!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        cellVW.layer.cornerRadius = 10
        cellVW.clipsToBounds = true
    }

}
