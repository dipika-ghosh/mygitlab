//
//  PostDetailsVC + Extensions.swift
//  Back4app
//
//  Created by Agnisikha Guria on 19/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension PostDetailsVC
{
    func setupUI(){
        tblPost.separatorStyle = .none
        tblPost.tableHeaderView = UIView(frame: CGRect.zero)
        tblPost.tableFooterView = UIView(frame: CGRect.zero)
        tblPost.delegate = self
        tblPost.dataSource = self
        self.tblPost.register(UINib(nibName: Constant.NibName.PostDetailsCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.PostDetailsCell)
    }
}
extension PostDetailsVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblPost.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.PostDetailsCell) as! PostDetailsCell
        cell.selectionStyle = .none
        cell.postCollectionVW.delegate = self
        cell.postCollectionVW.dataSource = self
        
        cell.postCollectionVW.reloadData()
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height //UITableView.automaticDimension
    }
}
extension PostDetailsVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 1
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.DetailsImageCell, for: indexPath) as! DetailsImageCell
        let image = UIImage.outlinedEllipse(size: CGSize(width: 7.0, height: 7.0), color: .white)
        collectionCell.pageControl.pageIndicatorTintColor = UIColor.init(patternImage: image!)
        collectionCell.pageControl.currentPageIndicatorTintColor = .white
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        collectionCell.pageControl.currentPage = indexPath.section
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: cell.postCollectionVW.frame.size.width, height: cell.postCollectionVW.frame.size.height)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if let _ = cell.postCollectionVW
        {
            let offSet = cell.postCollectionVW.contentOffset.x
            let width = cell.postCollectionVW.frame.width
            let horizontalCenter = width / 2
            
            collectionCell.pageControl.currentPage = Int(offSet + horizontalCenter) / Int(width)
        }
        
    }
    
}
