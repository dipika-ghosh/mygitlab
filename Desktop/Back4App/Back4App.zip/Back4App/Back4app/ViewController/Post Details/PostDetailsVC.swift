//
//  PostDetailsVC.swift
//  Back4app
//
//  Created by Agnisikha Guria on 19/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class PostDetailsVC: UIViewController {

    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblPost: UITableView!
    var cell : PostDetailsCell = PostDetailsCell()
    var collectionCell : DetailsImageCell = DetailsImageCell()
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
