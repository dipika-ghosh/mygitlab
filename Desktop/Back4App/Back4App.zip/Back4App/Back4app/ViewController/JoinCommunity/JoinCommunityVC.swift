//  JoinCommunityVC.swift
//  Back4app
//  Created by Dipika Ghosh on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class JoinCommunityVC: UIViewController {
    @IBOutlet weak var communityTblvw: UITableView!
    var cell : JoinCommunityCell = JoinCommunityCell()
    var collectionCell : JoinCommunityCollectionCell = JoinCommunityCollectionCell()
    var arr = ["Outdoors","Sports","Auto","Fashion","Art","Dining","Int 7","Int 8"]
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
