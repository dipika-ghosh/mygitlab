//
//  JoinCommunityVC+Extension.swift
//  Back4app
//
//  Created by Dipika Ghosh on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension JoinCommunityVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1 
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.JoinCommunityCell) as! JoinCommunityCell
        cell.selectionStyle = .none
        cell.bttnNext.addTarget(self, action: #selector(gotoNextPage), for: .touchUpInside)
        cell.communityCollectionVw.delegate = self
        cell.communityCollectionVw.dataSource = self
        cell.communityCollectionVw.register(UINib(nibName: Constant.NibName.JoinCommunityCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.JoinCommunityCollectionCell)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension//self.communityTblvw.frame.height//UITableView.automaticDimension
    }
    
    func setupUI(){
        self.communityTblvw.delegate = self
        self.communityTblvw.dataSource = self
        self.communityTblvw.tableFooterView = UIView(frame: .zero)
        self.communityTblvw.tableHeaderView = UIView(frame: .zero)
        self.communityTblvw.separatorStyle = .none
        self.communityTblvw.register(UINib(nibName: Constant.NibName.JoinCommunityCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.JoinCommunityCell)
    }
    @objc func gotoNextPage(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.SizeVC) as! SizeVC
        self.navigationController?.pushViewController(vc, animated: true)

    }
}
extension JoinCommunityVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.JoinCommunityCollectionCell, for: indexPath) as! JoinCommunityCollectionCell
        collectionCell.lblName.text = arr[indexPath.item]
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/4 - 10), height: collectionView.frame.size.height/3)
    }
    
}
