//
//  JoinCommunityCell.swift
//  Back4app
//
//  Created by Dipika Ghosh on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class JoinCommunityCell: UITableViewCell {
    @IBOutlet weak var gradientVw: UIView!
    
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var bttnNext: UIButton!
    
    @IBOutlet weak var lblProgress: UILabel!
    
    @IBOutlet weak var communityCollectionVw: UICollectionView!
    
    @IBOutlet weak var progressVw: UIProgressView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        progressVw.transform = progressVw.transform.scaledBy(x: 1, y: 5)
        progressVw.layer.cornerRadius = 10
        progressVw.clipsToBounds = true
        progressVw.layer.sublayers![1].cornerRadius = 10
        progressVw.subviews[1].clipsToBounds = true
        
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
        
        userImg.contentMode = .scaleToFill
        userImg.layer.cornerRadius = 10.0
        userImg.clipsToBounds = true
//        progressVw.progress = (((100/3) * 2) * 1/100)
//        lblProgress.text = "  Progress: \(progressVw.progress * 100)%"
        
        progressVw.progress = (((100/6) * 4) * 1/100)
        let result = progressVw.progress * 100
        let str = String(format:"%.1f", result)
        lblProgress.text = "  Progress: \(str)%"
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
