//
//  JoinCommunityCollectionCell.swift
//  Back4app
//
//  Created by Dipika Ghosh on 20/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class JoinCommunityCollectionCell: UICollectionViewCell {
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var myVw: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        myVw.layer.shadowColor = UIColor.lightGray.cgColor
        myVw.layer.shadowOffset = CGSize(width: 0, height: 2)
        myVw.layer.shadowOpacity = 1.0
        
        myVw.clipsToBounds = true
    }

}
