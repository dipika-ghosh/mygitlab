//  CommunitiesVC+Extension.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import SwiftyJSON
import SDWebImage
extension CommunitiesVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.CommunitiesCell) as! CommunitiesCell
        cell.selectionStyle = .none
        cell.communitycollectionVw.delegate = self
        cell.communitycollectionVw.dataSource = self
        cell.bttnNext.addTarget(self, action: #selector(gotoNext), for: .touchUpInside)
        cell.communitycollectionVw.register(UINib(nibName: Constant.NibName.ComunityCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ComunityCollectionCell)
        
        
        if (DataManager.shared.communitySelectFlag == "add my community"){
              let Profile_img = UserDefaults.standard.value(forKey: Constant.user_defaults_value.profileImage) as? String ?? ""
              let Profile_name = UserDefaults.standard.value(forKey: Constant.user_defaults_value.user_name) as? String ?? ""
             cell.lblName.text = Profile_name
            cell.imgUser.sd_setImage(with: URL(string:Profile_img), placeholderImage: UIImage(named: "travel"))
            
        }else{
            cell.lblName.text = "\(DataManager.shared.userInfoData[Parameter.Registration.name]!)"
            let registerType = "\(DataManager.shared.userInfoData[Parameter.Registration.register_type]!)"
            if (registerType == "facebook"){
                cell.imgUser.sd_setImage(with: URL(string:DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial] as! String), placeholderImage: UIImage(named: "travel"))
            }
            else if registerType == "google"
            {
                cell.imgUser.sd_setImage(with: DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial] as? URL, placeholderImage: UIImage(named: "travel"))
            }
            else
            {
                guard let img = uploadImage else {
                    return cell
                }
                cell.imgUser.image = img
            }
        }
        
        
        
       
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
   @objc func gotoNext(){
    
    let validated : () -> Bool = {
        for i in 0..<self.arrSelect.count
        {
            if self.arrSelect[i] == "1"
            {
                return true
            }
            else
            {
                continue
            }
        }
        return false
    }
    
    if validated()
    {
         if (DataManager.shared.communitySelectFlag == "add my community"){
            CommunityDataArr.updateValue(DataManager.shared.selectedCommunity, forKey: "communities")
             CommunityDataArr.updateValue(DataManager.shared.selectedInterest, forKey: "interests")
            print(CommunityDataArr)
            objCommunityUpload.CommunityUpload(param:CommunityDataArr)
           
         }else{
            for i in 0..<DataManager.shared.selectedInterest.count
            {
                DataManager.shared.userInfoData.updateValue(DataManager.shared.selectedInterest[i], forKey: "interests[\(i)]")
            }
            for i in 0..<DataManager.shared.selectedCommunity.count
            {
                DataManager.shared.userInfoData.updateValue(DataManager.shared.selectedCommunity[i], forKey: "communities[\(i)]")
            }
            print(DataManager.shared.userInfoData)
            let registerType = "\(DataManager.shared.userInfoData[Parameter.Registration.register_type]!)"
            if (registerType == "facebook"){
                let url = URL(string:"\(DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial]!)")
                if let data = try? Data(contentsOf: url!)
                {
                    let image: UIImage = UIImage(data: data)!
                    objSignUpController.signUP(param:  DataManager.shared.userInfoData, image: image)
                }
            }
            else if registerType == "google"
            {
                let imageUrl = URL(string:"\(DataManager.shared.userInfoData[Parameter.Registration.profileImageSocial]!)")
                if let data = try? Data(contentsOf: imageUrl!)
                {
                    let image: UIImage = UIImage(data: data)!
                    print("Params=====", DataManager.shared.userInfoData)
                    objSignUpController.signUP(param:  DataManager.shared.userInfoData, image: image)
                }
            }
            else{
                
                objSignUpController.signUP(param:  DataManager.shared.userInfoData, image: DataManager.shared.userInfoData[Parameter.Registration.profileImage] as! UIImage)
            }
        }
        }
    else
    {
        Utility.showAlert(message: Constant.Error_Message.Community_Selection_Error, vc: self)
    }
    }   
    
  /*  func ValidateData() -> Bool
    {
        for i in 0..<arrSelect.count
        {
            if arrSelect[i] == "1"
            {
                return true
            }
            else
            {
                continue
            }
        }
        return false
    }*/
}
extension CommunitiesVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
       
            if (self.objSelectCommunityModel.count) != 0{
                return self.objSelectCommunityModel.count
            }else
            {
                return 0
            }
       
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ComunityCollectionCell, for: indexPath) as! ComunityCollectionCell
        if self.arrSelect[indexPath.item] == "1"
        {
            collectionCell.imgTick.image = #imageLiteral(resourceName: "grennTick")
        }
        else
        {
            collectionCell.imgTick.image = UIImage(named: "")
        }
        
           if (self.objSelectCommunityModel.count != 0){
                collectionCell.lblTitle.text = self.objSelectCommunityModel[indexPath.row].title
                collectionCell.imgCommunity.sd_setImage(with: URL(string:self.objSelectCommunityModel[indexPath.row].logo), placeholderImage: UIImage(named: "travel"))
            }
       
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        for i in 0..<arrSelect.count
        {
            if i == indexPath.item
            {
                if arrSelect[i] == "1"{
                    arrSelect[i] = "0"
                }else{
                    arrSelect[i] = "1"
                    if DataManager.shared.selectedCommunity.count > 0
                    {
                        for _ in DataManager.shared.selectedCommunity
                        {
                            if DataManager.shared.selectedCommunity.contains(self.objSelectCommunityModel[indexPath.row].id!)
                            {
                                break
                            }
                            else
                            {
                                DataManager.shared.selectedCommunity.append(self.objSelectCommunityModel[indexPath.row].id!)
                            }
                        }
                    }
                    else
                    {
                        DataManager.shared.selectedCommunity.append(self.objSelectCommunityModel[indexPath.row].id!)
                    }
                    print(DataManager.shared.selectedCommunity)
                }
            }
        }
        print(self.arrSelect)
        collectionView.reloadData()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/2), height: collectionView.frame.size.height/2 - 20)
    }
}
extension CommunitiesVC: SelectCommunityDelegate{
    func SelectCommunitySuccessResponse(response: [JSON]) {
        DispatchQueue.main.async(execute: {() -> Void in
            DataManager.shared.hideLoader()
            print("My response=====",response)
            self.objSelectCommunityModel.removeAll()
            for obj in response
            {
                let data = SelectCommunityModel(CommunityDict: obj)
                self.objSelectCommunityModel.append(data)
            }
            print(self.objSelectCommunityModel.count)
            self.setupArr()
            DispatchQueue.main.async(execute: {() -> Void in
                self.cell.communitycollectionVw.reloadData()
            })
        })
    }
    func SelectCommunityFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
    func SelectCommunityFailedResponseWithStatus(error: String, statusCode: Int) {
        if statusCode == 201
        {
            DataManager.shared.hideLoader()
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                })
            })
        }
    }
}
extension CommunitiesVC{
    func setupUI(){
        communitiesTblVw.separatorStyle = .none
        communitiesTblVw.tableHeaderView = UIView(frame: CGRect.zero)
        communitiesTblVw.tableFooterView = UIView(frame: CGRect.zero)
        communitiesTblVw.delegate = self
        communitiesTblVw.dataSource = self
        self.communitiesTblVw.register(UINib(nibName: Constant.NibName.CommunitiesCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.CommunitiesCell)
    }
    func setupArr()
    {
        for _ in 0..<self.objSelectCommunityModel.count
        {
            arrSelect.append("0")
        }
    }
}
extension CommunitiesVC: SignUpControllerDelegate{
    func SuccessResponse(responseDict: [String : Any]) {
        print(responseDict)
        DispatchQueue.main.async(execute: {() -> Void in
            self.view.endEditing(true)
            self.objSignupModel = SignupModel(signupModel: responseDict as [String : AnyObject])
            DataManager.shared.hideLoader()
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: self.objSignupModel.message, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
//                let appDelegate = UIApplication.shared.delegate! as! AppDelegate
//                let mainVC = TabbarVC()
//                appDelegate.window?.rootViewController = mainVC
//                appDelegate.window?.makeKeyAndVisible()
                if self.objSignupModel.data.registerType.lowercased() == "normal"
                {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.LoginVC) as! LoginVC
                self.navigationController?.pushViewController(vc, animated: true)
                }
                else
                {
                    UserDefaults.standard.setValue(self.objSignupModel.data.id, forKey: Constant.user_defaults_value.user_id)
                    let appDelegate = UIApplication.shared.delegate! as! AppDelegate
                    let mainVC = TabbarVC()
                    appDelegate.window?.rootViewController = mainVC
                    appDelegate.window?.makeKeyAndVisible()
                    
                }
            })
        })
    }
    func FailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
}

