//
//  CommunitiesVC+Extension.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension CommunitiesVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.CommunitiesCell) as! CommunitiesCell
        cell.selectionStyle = .none
        cell.communitycollectionVw.delegate = self
        cell.communitycollectionVw.dataSource = self
        cell.bttnNext.addTarget(self, action: #selector(gotoNext), for: .touchUpInside)
        cell.communitycollectionVw.register(UINib(nibName: Constant.NibName.ComunityCollectionCell, bundle: nil), forCellWithReuseIdentifier: Constant.CellIdentifier.ComunityCollectionCell)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
   @objc func gotoNext(){
//       let vc = self.storyboard?.instantiateViewController(withIdentifier:Constant.StoryBoard.Identifer.HomeVC) as! HomeVC
//    self.navigationController?.pushViewController(vc, animated: true)
    let appDelegate = UIApplication.shared.delegate! as! AppDelegate
    let mainVC = TabbarVC()
    appDelegate.window?.rootViewController = mainVC
    appDelegate.window?.makeKeyAndVisible()
    }
}
extension CommunitiesVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 8
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: Constant.CellIdentifier.ComunityCollectionCell, for: indexPath) as! ComunityCollectionCell
        return collectionCell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.size.width/2 - 10), height: collectionView.frame.size.height/2)
    }
}
extension CommunitiesVC{
    func setupUI(){
        communitiesTblVw.separatorStyle = .none
        communitiesTblVw.tableHeaderView = UIView(frame: CGRect.zero)
        communitiesTblVw.tableFooterView = UIView(frame: CGRect.zero)
        communitiesTblVw.delegate = self
        communitiesTblVw.dataSource = self
        self.communitiesTblVw.register(UINib(nibName: Constant.NibName.CommunitiesCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.CommunitiesCell)
    }
}
