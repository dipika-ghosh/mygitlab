//
//  ComunityCollectionCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
class ComunityCollectionCell: UICollectionViewCell {
    @IBOutlet weak var imgTick: UIImageView!
    @IBOutlet weak var imgCommunity: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgCommunity.contentMode = .scaleToFill
        imgCommunity.layer.cornerRadius = 8.0
        imgCommunity.clipsToBounds = true
    }
}
