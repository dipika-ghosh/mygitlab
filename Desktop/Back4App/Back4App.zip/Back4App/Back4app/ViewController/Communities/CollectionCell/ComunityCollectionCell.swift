//
//  ComunityCollectionCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ComunityCollectionCell: UICollectionViewCell {

    @IBOutlet weak var imgCommunity: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgCommunity.contentMode = .scaleToFill
        imgCommunity.layer.cornerRadius = 10.0
        imgCommunity.clipsToBounds = true

    }

}
