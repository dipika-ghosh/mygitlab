//
//  CommunitiesCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import hkGraddiant
class CommunitiesCell: UITableViewCell {
    @IBOutlet weak var gradientVw: UIView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var communitycollectionVw: UICollectionView!
    @IBOutlet weak var vwProgress: UIProgressView!
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var bttnNext: UIButton!
    
    @IBOutlet weak var imgUser: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        vwProgress.transform = vwProgress.transform.scaledBy(x: 1, y: 5)
        vwProgress.layer.cornerRadius = 10
        vwProgress.clipsToBounds = true
        vwProgress.layer.sublayers![1].cornerRadius = 10
        vwProgress.subviews[1].clipsToBounds = true
        
        vwProgress.progress = (((100/6) * 6) * 1/100)
        let result = vwProgress.progress * 100
        let str = String(format:"%.1f", result)
        lblProgress.text = "  Progress: \(str)%"
        
//        vwProgress.progress = ((100/1) * 1/100)
//        lblProgress.text = "  Progress: \(vwProgress.progress * 100)%"
        imgUser.contentMode = .scaleAspectFit
        imgUser.layer.cornerRadius = 10.0
        imgUser.clipsToBounds = true
        
        gradientVw.layer.cornerRadius = 10
        gradientVw.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
