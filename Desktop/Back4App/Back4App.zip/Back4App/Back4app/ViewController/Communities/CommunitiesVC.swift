//  CommunitiesVC.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class CommunitiesVC: UIViewController {
    @IBOutlet weak var communitiesTblVw: UITableView!
    var cell : CommunitiesCell = CommunitiesCell()
    var collectionCell : ComunityCollectionCell = ComunityCollectionCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
  
    @IBAction func bttnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true )
    }
}
