//  CommunitiesVC.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SwiftyJSON
class CommunitiesVC: UIViewController {
    @IBOutlet weak var communitiesTblVw: UITableView!
    var cell : CommunitiesCell = CommunitiesCell()
    var collectionCell : ComunityCollectionCell = ComunityCollectionCell()
    var arrSelect = [String]()
    var objSelectCommunity = SelectCommunity()
    var objSelectCommunityModel = [SelectCommunityModel]()
    var objSignUpController = SignUpController()
    var objSignupModel = SignupModel()
    var selected_id = String()
    var uploadImage : UIImage?
    var dict : [String:String] = [String:String]()
    var objCommunityUpload = CommunityUpload()
    public var CommunityDataArr :[String: Any] = [:]
     override func viewDidLoad() {
        super.viewDidLoad()
         objSelectCommunity.delegate = self
         objSignUpController.delegate = self
         objCommunityUpload.delegate = self
        
         print(self.selected_id)
        if (DataManager.shared.communitySelectFlag == "add my community"){
            objSelectCommunity.fetchMyCommunityList(interest_id: self.selected_id)
        }else
        {
            objSelectCommunity.fetchCommunityList(interest_id: self.selected_id)
            let registerType = "\(DataManager.shared.userInfoData[Parameter.Registration.register_type]!)"
            if (registerType == "facebook"){
            }
            else if registerType == "google"
            {
            }
            else
            {
                if let _ = (DataManager.shared.userInfoData[Parameter.Registration.profileImage] as? UIImage)
                {
                    self.uploadImage = (DataManager.shared.userInfoData[Parameter.Registration.profileImage] as! UIImage)
                }
            }
        }
        setupUI()
       
    }
    @IBAction func bttnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true )
    }
}
extension CommunitiesVC:CommunityUploadDelegate{
    func CommunityUploadSuccessResponse(response: [String:AnyObject],status:String) {
        print("CommunityUploadSuccessResponse==",response)
        DispatchQueue.main.async(execute: {() -> Void in
            DataManager.shared.hideLoader()
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: status, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                self.navigationController?.popViewController(animated: true)
            })
            
        })
    }
    
    func CommunityUploadFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
    
    func CommunityUploadFailedResponseWith(error: String, statusCode: Int) {
        if statusCode == 201
        {
            DataManager.shared.hideLoader()
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {
                })
            })
        }
    }
    
    
}
