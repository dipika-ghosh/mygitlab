//  SignUpVC+Extensions.swift
//  Back4app
//  Created by webskitters on 12/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
import AVFoundation
import SwiftyJSON
extension SignUpVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier:Constant.CellIdentifier.SignUpCell) as! SignUpCell
        cell.selectionStyle = .none
        cell.txtName.delegate = self
        cell.txtPassword.delegate = self
        cell.btnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        cell.btnchoose.addTarget(self, action: #selector(ChooseAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension SignUpVC {
    func setupUI(){
        tblSignUp.separatorStyle = .none
        tblSignUp.tableHeaderView = UIView(frame: CGRect.zero)
        tblSignUp.tableFooterView = UIView(frame: CGRect.zero)
        tblSignUp.delegate = self
        tblSignUp.dataSource = self
        self.tblSignUp.register(UINib(nibName: Constant.NibName.SignUpCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.SignUpCell)
        picker.delegate = self
    }
   @objc func NextAction()
    {
        if isValidated()
        {
            if let _ = pickedImage
            {
                let param: [String:Any] = ["email" :cell.txtName.text!,
                                           "register_type" : "normal"
                ]
                self.objEmailExist.emailAlredyExistOrNot(param: param)
            }
            else
            {
                DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.ImageUpload_Error, vc:self )
                }
            }
        }
    }
    @objc func ChooseAction()
    {
        print("Choose image from gallery/Camera")
        showCamera()
//        let recaptcha = ReCaptcha(
//            apiKey: "6LdbaeYUAAAAAHQWYvyYEQpwoGyGYTvRiv3KR4JP",
//            baseURL: URL(string: "Back4App")
////            recaptcha?.configureWebView { [weak self] webview in
////                webview.frame = self?.view.bounds ?? CGRect.zero
////            }
//        let recaptcha = ReCaptcha(apiKey: "6LdbaeYUAAAAAHQWYvyYEQpwoGyGYTvRiv3KR4JP", baseURL: <#T##URL?#>, endpoint: <#T##ReCaptcha.Endpoint#>, locale: <#T##Locale?#>)
//        )
    }
    @objc func BackToLogin()
    {
        self.navigationController?.popViewController(animated: true)
    }
    func isValidated() -> Bool {
        if (cell.txtName.text?.isEmpty)! || cell.txtName.text == "" || cell.txtName.text == " " {
            DispatchQueue.main.async{
            Utility.showAlert(message: Constant.Error_Message.Email_Error, vc:self )
            }
            return false
        }
        else if (Utility.validateEmail(cell.txtName.text!) == false)
        {
            DispatchQueue.main.async{
            Utility.showAlert(message: Constant.Error_Message.ValidEmail_Error, vc:self )
            }
            return false
        }
        else if (cell.txtPassword.text?.isEmpty)! || cell.txtPassword.text == "" || cell.txtPassword.text == " " {
            DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.Password_Error, vc:self )
            }
            return false
        }
       else if ((cell.txtPassword.text?.count)! < 6)
        {
            DispatchQueue.main.async{
                Utility.showAlert(message: Constant.Error_Message.PasswordCount_Error, vc: self)
            }
            return false
        }
        else {
            return true
        }
    }
    private func ShowProgress()
    {
        if (cell.txtName.text != "" && cell.txtName.text != " ") && (cell.txtPassword.text != "" && cell.txtPassword.text != " ")
        {
            if imageEntered
            {
                cell.prgrsBar.progress = ((100/6 ) * 1/100)
                let result = cell.prgrsBar.progress * 100
                let str = String(format:"%.1f", result)
                cell.lblProgress.text = "  Progress: \(str)%"
            }
            else
            {
                cell.prgrsBar.progress = ((100/12 ) * 1/100)
                let result = cell.prgrsBar.progress * 100
                let str = String(format:"%.1f", result)
                cell.lblProgress.text = "  Progress: \(str)%"
            }
            nameEntered = true
        }
    }
}
extension SignUpVC : EmailExistDelegate{
    func emailExistFailedResponse(error: String) {
        DataManager.shared.hideLoader()
        DispatchQueue.main.async(execute: {() -> Void in
            Utility.alertWithOkMessage(title: Constant.variableText.appName, message: error, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
        })
    }
    func emailExistSuccessResponse(responseArr: [String:Any], msg: String, isAvailable: Bool) {
         DataManager.shared.hideLoader()
        print("email exist response===",responseArr)
        if isAvailable == true{
            DispatchQueue.main.async(execute: {() -> Void in
                Utility.alertWithOkMessage(title: Constant.variableText.appName, message: msg, buttonText: Constant.variableText.ok, viewController: self, completionHandler: {})
            })
        }else{
            DispatchQueue.main.async(execute: {() -> Void in
                let name = self.cell.txtName.text!
                if let firstName = name.components(separatedBy: "@").first {
                    DataManager.shared.userInfoData[Parameter.Registration.name] = firstName
                }
                let device_token = Utility.getObjectForKey(Constant.user_defaults_value.device_token) as? String ?? ""
                DataManager.shared.userInfoData[Parameter.Registration.email] = self.cell.txtName.text
                DataManager.shared.userInfoData[Parameter.Registration.password] = self.cell.txtPassword.text
                DataManager.shared.userInfoData[Parameter.Registration.deviceToken] = device_token
                DataManager.shared.userInfoData[Parameter.Registration.register_type] = "normal"
                DataManager.shared.userInfoData[Parameter.Registration.profileImage] = self.pickedImage
                let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.ShowImageVC) as! ShowImageVC
                self.navigationController?.pushViewController(vc, animated: true)
            })
        }
    }
}
extension SignUpVC : UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == cell.txtName
        {
            textField.placeholder = nil
            cell.lblName.isHidden = false
            if !nameAnimated
            {
            cell.lblName.pushTransition(0.3)
            nameAnimated = true
            }
        }
        if textField == cell.txtPassword
        {
            textField.placeholder = nil
            cell.lblPassword.isHidden = false
            if !passAnimated
            {
            cell.lblPassword.pushTransition(0.3)
            passAnimated = true
            }
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("done click ")
        if textField == cell.txtName{
            ShowProgress()
        }
        else{
            ShowProgress()
        }
    }
    
}
extension SignUpVC :UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func showCamera(){
        DispatchQueue.main.async{
            if AVCaptureDevice.authorizationStatus(for: AVMediaType.video) ==  AVAuthorizationStatus.authorized
            {
                let alert:UIAlertController=UIAlertController(title: "Choose option", message: nil, preferredStyle: UIAlertController.Style.actionSheet)
                let cameraAction = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default)
                {
                    UIAlertAction in
                    self.openCamera()
                }
                let gallaryAction = UIAlertAction(title: "Gallery", style: UIAlertAction.Style.default)
                {
                    UIAlertAction in
                    self.openGallary()
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
                {
                    UIAlertAction in
                }
                alert.addAction(cameraAction)
                alert.addAction(gallaryAction)
                alert.addAction(cancelAction)
                self.present(alert, animated: true, completion: nil)
            }
            else
            {
                let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: AVMediaType.video)
                switch cameraAuthorizationStatus {
                case .denied:
                    if #available(iOS 8.0, *) {
                        let alertController = UIAlertController(title: "", message:"The camera settings for Back4App is disabled. Please enable from Settings", preferredStyle: UIAlertController.Style.alert)
                        let okAction = UIAlertAction(title:  "Settings", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
                            let settingsUrl = NSURL(string:UIApplication.openSettingsURLString)
                            if let url = settingsUrl {
                                UIApplication.shared.open(url as URL, options: [:]
                                    , completionHandler: nil)
                            }
                        }
                        let cancel = UIAlertAction(title:  "Cancel", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
                        }
                        alertController.addAction(okAction)
                        alertController.addAction(cancel)
                        self.present(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        let alert = UIAlertView(title: "Oops!", message: "The camera settings for Back4App is disabled. Please enable from Settings", delegate: nil, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    break
                case .authorized:
                    break
                case .restricted:
                    break
                case .notDetermined:
                    AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
                        if response {
                            //access granted
                        } else {
                        }
                    }
                    break
                @unknown default:
                    print("error")
                    break
                }
            }
        }
    }
    func openCamera()
    {
        if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            picker.sourceType = UIImagePickerController.SourceType.camera
            self.present(picker, animated: true, completion: nil)
        }
        else
        {
            Utility.showAlert(message: Constant.Error_Message.DontHaveCamera_Error, vc: self)
        }
    }
    func openGallary()
    {
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
    //MARK: PickerView Delegate Methods
    @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        pickedImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        Utility.showAlert(message: Constant.Error_Message.Image_Upload_Sucess, vc: self)
        if nameEntered
        {
            cell.prgrsBar.progress = ((100/6 ) * 1/100)
            let result = cell.prgrsBar.progress * 100
            let str = String(format:"%.1f", result)
            cell.lblProgress.text = "  Progress: \(str)%"
        }
        else
        {
            cell.prgrsBar.progress = ((100/12 ) * 1/100)
            let result = cell.prgrsBar.progress * 100
            let str = String(format:"%.1f", result)
            cell.lblProgress.text = "  Progress: \(str)%"
        }
        imageEntered = true
    }
}
