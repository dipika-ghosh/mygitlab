//
//  SignUpVC+Extensions.swift
//  Back4app
//
//  Created by webskitters on 12/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit

extension SignUpVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier:Constant.CellIdentifier.SignUpCell) as! SignUpCell
        cell.selectionStyle = .none
        cell.txtName.delegate = self
        cell.txtPassword.delegate = self
        cell.btnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        cell.btnchoose.addTarget(self, action: #selector(ChooseAction), for: .touchUpInside)
        cell.btnLogin.addTarget(self, action: #selector(BackToLogin), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension SignUpVC {
    func setupUI(){
        tblSignUp.separatorStyle = .none
        tblSignUp.tableHeaderView = UIView(frame: CGRect.zero)
        tblSignUp.tableFooterView = UIView(frame: CGRect.zero)
        tblSignUp.delegate = self
        tblSignUp.dataSource = self
        self.tblSignUp.register(UINib(nibName: Constant.NibName.SignUpCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.SignUpCell)
    }
   @objc func NextAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.ShowImageVC) as! ShowImageVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func ChooseAction()
    {
        
    }
    @objc func BackToLogin()
    {
        self.navigationController?.popViewController(animated: true)
    }

}
extension SignUpVC : UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == cell.txtName
        {
            //cell.lblName.isHidden = false
            textField.placeholder = nil
            self.setView(view: cell.lblName, hidden: false)
        }
        if textField == cell.txtPassword
        {
            //cell.lblPassword.isHidden = false
            textField.placeholder = nil
            self.setView(view: cell.lblPassword, hidden: false)
        }
        
    }
    func setView(view: UIView, hidden: Bool) {
        UIView.transition(with: view, duration: 1.0, options: .curveEaseInOut, animations: {
            view.isHidden = hidden
        })
    }
}
