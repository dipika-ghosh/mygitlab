//
//  SignUpCell.swift
//  Back4app
//
//  Created by webskitters on 12/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class SignUpCell: UITableViewCell {
    @IBOutlet weak var imgLogo: UIImageView!
    
    @IBOutlet weak var lblNameWidth: NSLayoutConstraint!
    @IBOutlet weak var txtName: UITextField!

    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var lblPasswordWidth: NSLayoutConstraint!
    @IBOutlet weak var prgrsBar: UIProgressView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var passwordVW: UIView!
    @IBOutlet weak var nameVW: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnchoose: UIButton!
    @IBOutlet weak var gradVW1: UIView!
    @IBOutlet weak var lblProgress: UILabel!

    @IBOutlet weak var btnLogin: UIButton!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        prgrsBar.transform = prgrsBar.transform.scaledBy(x: 1, y: 5)
        prgrsBar.layer.cornerRadius = 10
        prgrsBar.clipsToBounds = true
        prgrsBar.layer.sublayers![1].cornerRadius = 10
        prgrsBar.subviews[1].clipsToBounds = true
        prgrsBar.progress = ((100/5) * 1/100)
        lblProgress.text = "Progress: \(prgrsBar.progress * 100)%"
        nameVW.layer.cornerRadius = 10.0
        nameVW.clipsToBounds = true
        nameVW.layer.borderWidth = 1.0
        nameVW.layer.borderColor = UIColor.gray.cgColor
        
        passwordVW.layer.cornerRadius = 10.0
        passwordVW.clipsToBounds = true
        passwordVW.layer.borderWidth = 1.0
        passwordVW.layer.borderColor = UIColor.gray.cgColor
        
        var rect: CGRect = lblName.frame //get frame of label
        rect.size = (lblName.text?.size(withAttributes: [NSAttributedString.Key.font: UIFont(name: lblName.font.fontName , size: lblName.font.pointSize)!]))! //Calculate as per label font
        lblNameWidth.constant = rect.width
        
        var rect1: CGRect = lblPassword.frame //get frame of label
        rect1.size = (lblPassword.text?.size(withAttributes: [NSAttributedString.Key.font: UIFont(name: lblPassword.font.fontName , size: lblPassword.font.pointSize)!]))! //Calculate as per label font
        lblPasswordWidth.constant = rect1.width
        
        gradVW1.layer.cornerRadius = 10
         gradVW1.clipsToBounds = true
        
        btnchoose.layer.cornerRadius = 10
        btnchoose.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

