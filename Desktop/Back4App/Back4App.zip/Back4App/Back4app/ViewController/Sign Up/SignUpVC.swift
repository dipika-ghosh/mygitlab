//  SignUpVC.swift
//  Back4app
//  Created by webskitters on 12/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class SignUpVC: UIViewController {
    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblSignUp: UITableView!
    var cell : SignUpCell = SignUpCell()
    var nameAnimated = false
    var passAnimated = false
    var picker = UIImagePickerController()
    var pickedImage : UIImage?
     var objEmailExist = EmailExist()
    var nameEntered = false
    var imageEntered = false
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        objEmailExist.delegate = self
    }
    @IBAction func btnBackAction(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
}
