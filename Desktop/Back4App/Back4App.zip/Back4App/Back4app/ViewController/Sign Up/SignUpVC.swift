//
//  SignUpVC.swift
//  Back4app
//
//  Created by webskitters on 12/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {

    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblSignUp: UITableView!
    var cell : SignUpCell = SignUpCell()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    @IBAction func btnBackAction(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
}
