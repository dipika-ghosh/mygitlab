//
//  SearchVC + Extensions.swift
//  Back4app
//
//  Created by webskitters on 18/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import Foundation
import UIKit
extension SearchVC
{
    func setupUI(){
        tblSearch.separatorStyle = .none
        tblSearch.tableHeaderView = UIView(frame: CGRect.zero)
        tblSearch.tableFooterView = UIView(frame: CGRect.zero)
        tblSearch.delegate = self
        tblSearch.dataSource = self
        self.tblSearch.register(UINib(nibName: Constant.NibName.SearchCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.SearchCell)
    }
}
extension SearchVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblSearch.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.SearchCell) as! SearchCell
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
