//
//  SearchCell.swift
//  Back4app
//
//  Created by webskitters on 18/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet weak var cellVW: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTag1: UILabel!
    @IBOutlet weak var imgNotification: UIImageView!
    @IBOutlet weak var lblTag2: UILabel!
    @IBOutlet weak var lblTag3: UILabel!
    @IBOutlet weak var lblTag4: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var separatorVW: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgNotification.layer.cornerRadius = 10
        imgNotification.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
