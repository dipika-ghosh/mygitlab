//  SearchVC.swift
//  Back4app
//  Created by webskitters on 17/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
class SearchVC: UIViewController {
    @IBOutlet weak var mainVW: UIView!
    @IBOutlet weak var tblSearch: UITableView!
    var cell : SearchCell = SearchCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
}
