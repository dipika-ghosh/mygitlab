//
//  ShowImageCell.swift
//  Back4app
//
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit

class ShowImageCell: UITableViewCell {

    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var lblProgress: UILabel!
    @IBOutlet weak var gradVW1: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        progressBar.transform = progressBar.transform.scaledBy(x: 1, y: 5)
        progressBar.layer.cornerRadius = 10
        progressBar.clipsToBounds = true
        progressBar.layer.sublayers![1].cornerRadius = 10
        progressBar.subviews[1].clipsToBounds = true
        
        gradVW1.layer.cornerRadius = 10
        gradVW1.clipsToBounds = true
        
        imgUser.contentMode = .scaleToFill
        imgUser.layer.cornerRadius = 10.0
        imgUser.clipsToBounds = true
        progressBar.progress = (((100/5) * 2) * 1/100)
        lblProgress.text = "Progress: \(progressBar.progress * 100)%"
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
