//
//  ShowImageVC.swift
//  Back4app
//
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
//

import UIKit
import hkGraddiant


class ShowImageVC: UIViewController {

    
    @IBOutlet weak var tblShowImage: UITableView!
    var cell : ShowImageCell = ShowImageCell()
    override func viewDidLoad() {
        super.viewDidLoad()
         setupUI()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
