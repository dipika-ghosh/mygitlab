//  ShowImageVC.swift
//  Back4app
//  Created by webskitters on 13/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import hkGraddiant
class ShowImageVC: UIViewController {
    @IBOutlet weak var tblShowImage: UITableView!
    var cell : ShowImageCell = ShowImageCell()
    var uploadImage : UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        print(DataManager.shared.userInfoData)
        self.uploadImage = (DataManager.shared.userInfoData[Parameter.Registration.profileImage] as! UIImage)
         setupUI()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
