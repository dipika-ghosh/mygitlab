//  ShowImageVC + Extensions.swift
//  Back4app
//  Created by webskitters on 16/03/20.
//  Copyright © 2020 webskitters. All rights reserved.
import Foundation
import UIKit
extension ShowImageVC
{
    func setupUI(){
        tblShowImage.separatorStyle = .none
        tblShowImage.tableHeaderView = UIView(frame: CGRect.zero)
        tblShowImage.tableFooterView = UIView(frame: CGRect.zero)
        tblShowImage.delegate = self
        tblShowImage.dataSource = self
        self.tblShowImage.register(UINib(nibName: Constant.NibName.ShowImageCell, bundle: nil), forCellReuseIdentifier: Constant.CellIdentifier.ShowImageCell)
    }
    @objc func NextAction()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: Constant.StoryBoard.Identifer.FashionVC) as! FashionVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension ShowImageVC : UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tblShowImage.dequeueReusableCell(withIdentifier: Constant.CellIdentifier.ShowImageCell) as! ShowImageCell
        cell.selectionStyle = .none
    
        cell.btnNext.addTarget(self, action: #selector(NextAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
