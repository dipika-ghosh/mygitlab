//  DataManager.swift
//  Back4App
//  Created by webskitters on 16/01/20.
//  Copyright © 2020 webskitters. All rights reserved.
import UIKit
import SVProgressHUD
class DataManager: NSObject {
     private override init() { }
    static let shared                                       = DataManager()
    public let apiManager : APIManager                      = APIManager()
    public var userInfoData : [String:Any]            = [
    Parameter.Registration.email                            : "",
    Parameter.Registration.password                         : "",
    Parameter.Registration.deviceToken                      : "",
    Parameter.Registration.deviceType                       : "iOS",
    Parameter.Registration.register_type                    : "",
    Parameter.Registration.profileImage                     : "",
    Parameter.Registration.address                          : "",
    Parameter.Registration.facebook_auth_key                : "",
    Parameter.Registration.google_auth_key                  : "",
    Parameter.Registration.profileImageSocial               : "",
    Parameter.Registration.phone                            : ""
    ]
    
    
    
    
    public var sizeSaveInfoData = [String:Any]()
    public var selectedCommunity = [String]()
    public var selectedInterest = [String]()
    public var communitySelectFlag = String()
    public func showLoader() {
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.setForegroundColor(UIColor.black)
        //  SVProgressHUD.setBackgroundColor(UIColor.color(withHexCode: Constants.AppColorHexCode.appGrayColor, alpha: 1.0))
        SVProgressHUD.setBackgroundColor(UIColor.clear)
        SVProgressHUD.show()
    }
    func showLoader(text:String) {
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.setForegroundColor(UIColor.black)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.setFont(UIFont.fontWorkSansMedium(fontSize: 14.0)!)
        SVProgressHUD.show(withStatus: text)
    }
    func showLoaderWithInteractionOn() {
        SVProgressHUD.setDefaultMaskType(.none)
        SVProgressHUD.setForegroundColor(UIColor.lightGray)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.show()
    }
    func showLoaderWithInteractionOn(text:String) {
        SVProgressHUD.setDefaultMaskType(.none)
        SVProgressHUD.setForegroundColor(UIColor.lightGray)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.setFont(UIFont.fontWorkSansMedium(fontSize: 12.0)!)
        SVProgressHUD.show(withStatus: text)
    }
    func hideLoader() {
        SVProgressHUD.dismiss()
    }
    func hideLoader(delay:TimeInterval) {
        SVProgressHUD.dismiss(withDelay: delay)
    }
    func UnableToFindUser()
    {
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.user_id)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.access_token)
        Utility.removeObjectFromUserDefaults(forKey: Constant.user_defaults_value.isVerified)
        let mainStoryboardIpad : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nav = mainStoryboardIpad.instantiateViewController(withIdentifier: "RootNavigationVC") as! RootNavigationVC
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = nav
        appDelegate.window?.makeKeyAndVisible()
    }
}
