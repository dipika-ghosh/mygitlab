//
//  Extension.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 13/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import Foundation
import UIKit
extension UIButton{
    func setButton(){
        self.layer.masksToBounds = false
        self.clipsToBounds = false
        self.layer.shadowColor = UIColor.white.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.layer.shadowOpacity = 1.0
        self.layer.cornerRadius = 20
        
    }
    
}
extension UIImageView{
    func imageRound(){
        self.layer.borderWidth = 1.0
        self.layer.masksToBounds = false
        self.layer.borderColor = UIColor.clear.cgColor
        self.layer.cornerRadius = self.frame.size.height/2
        self.clipsToBounds = true
    }
}
