//
//  DataManager.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 12/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import SVProgressHUD
class DataManager: NSObject {
    
    static let shared = DataManager()
  
    public func showLoader() {
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.setForegroundColor(UIColor.black)
        //  SVProgressHUD.setBackgroundColor(UIColor.color(withHexCode: Constants.AppColorHexCode.appGrayColor, alpha: 1.0))
        SVProgressHUD.setBackgroundColor(UIColor.clear)
        
        SVProgressHUD.show()
    }
    
    func showLoader(text:String) {
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.setForegroundColor(UIColor.black)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.setFont(UIFont.fontcomfortaRegular(fontSize: 14.0)!)
        SVProgressHUD.show(withStatus: text)
    }
    
    func showLoaderWithInteractionOn() {
        SVProgressHUD.setDefaultMaskType(.none)
        SVProgressHUD.setForegroundColor(UIColor.lightGray)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.show()
    }
    
    func showLoaderWithInteractionOn(text:String) {
        SVProgressHUD.setDefaultMaskType(.none)
        SVProgressHUD.setForegroundColor(UIColor.lightGray)
        SVProgressHUD.setBackgroundColor(UIColor.darkGray)
        SVProgressHUD.setFont(UIFont.fontcomfortaRegular(fontSize: 12.0)!)
        SVProgressHUD.show(withStatus: text)
    }
    
    func hideLoader() {
        SVProgressHUD.dismiss()
    }
    
    func hideLoader(delay:TimeInterval) {
        SVProgressHUD.dismiss(withDelay: delay)
    }
}
extension UIFont{
    class func fontcomfortaRegular(fontSize:CGFloat)->UIFont? {
        return UIFont(name: "comfortaa_regular", size: fontSize)
    }
}
