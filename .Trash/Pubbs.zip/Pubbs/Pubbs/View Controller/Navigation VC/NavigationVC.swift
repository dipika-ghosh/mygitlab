//
//  NavigationVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 01/06/19.
//  Copyright © 2019 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
protocol slideMenuDelegate {
    func slideMenuItemSelectedAtIndex(_index : Int32)
}
class NavigationVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    @IBOutlet weak var lblProfileName: UILabel!
    
    var delegate : slideMenuDelegate?
    var btnMenu : UIButton!
    @IBOutlet weak var navTblVw: UITableView!
    @IBOutlet weak var crossBttn: UIButton!
    
    var cell : NavigationFirstCell = NavigationFirstCell()
    var NameArr = ["My Profile","My Trips","My Subscriptions","About Us","FAQ"]
    var ImgArr = ["user-img","MyTrip","Subscription","information","AboutUs",]
    
    
  
    override func viewDidLoad() {
        super.viewDidLoad()

        navTblVw.dataSource = self
        navTblVw.delegate = self
        navTblVw.separatorStyle = .none
        navTblVw.tableFooterView = UIView()
       fetchProfileData()
    }
    
    @IBAction func crossBttnActn(_ sender: UIButton) {
        btnMenu.tag = 0
        
        if (self.delegate != nil) {
            var index = Int32(sender.tag)
            if(sender == self.crossBttn){
                index = -1
            }
            delegate?.slideMenuItemSelectedAtIndex(_index: index)
        }
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width,height: UIScreen.main.bounds.size.height)
            self.view.layoutIfNeeded()
            self.tabBarController?.tabBar.isHidden = false
            UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.darkGray], for: .normal)
            self.view.backgroundColor = UIColor.clear
        }, completion: { (finished) -> Void in
            self.view.removeFromSuperview()
            self.removeFromParent()
        })
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.NameArr.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tablecell = tableView.dequeueReusableCell(withIdentifier: "NavigationSecondCell") as! NavigationSecondCell
        tablecell.selectionStyle = .none
        tablecell.lblName.text = self.NameArr[indexPath.row]
        
        tablecell.imgVw.image = UIImage(named: ImgArr[indexPath.row])
        return tablecell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath.row == 0){
           let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyProfileVC") as! MyProfileVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
       else if (indexPath.row == 1){
//            let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyWalletVC") as! MyWalletVC
//            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if (indexPath.row == 2){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SubscriptionVC") as! SubscriptionVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if (indexPath.row == 3){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutusVC") as! AboutusVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "FaqVC") as! FaqVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func logoutBttnActn(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Logout", message: "Do you want to logout?", preferredStyle: UIAlertController.Style.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            print("Handle Ok logic here")
             UserDefaults.standard.set(nil, forKey: "user_Ph_no")
//            UserDefaults.standard.set(nil, forKey: "user_Ph")
//            UserDefaults.standard.set(nil, forKey: "user_Pass")
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(vc, animated: true)
            
            
            
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
    }
    func fetchProfileData() {
        //           DataManager.shared.showLoader()
        guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(ph_no).observeSingleEvent(of: .value, with: { (snapshot) in
            
            let value = snapshot.value as? [String: AnyObject]
            self.lblProfileName.text = (value!["email"] as? String ?? "") + "\n\n" + (value!["phone_no"] as? String ?? "")
            
           
            //DataManager.shared.hideLoader()
        }) { (error) in
            // DataManager.shared.hideLoader()
            print(error.localizedDescription)
        }
    }
}
