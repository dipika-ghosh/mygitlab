//
//  FaqVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 11/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class FaqVC: UIViewController {

    @IBOutlet weak var contentVw: UIView!
    @IBOutlet weak var tblVwFaq: UITableView!
    var cell : FAQCell = FAQCell()
    var ArrFaq = ["Why should you choose us?","What is a subscription?","Subscription renewal","How can I reset my password?","Can I use bicycles without a subscription","How do I hire a bike?","What if the map of my app shows a different location?","Can I rent Pubbs bikes without an app or without an internet-enabled mobile phone?","How do I return my bike correctly?","Which iOS version can our Pubbs app support?","For locating, map navigation do we need mobile Gps to use?","What should I do when I have a Pubbs Bicycle problem?","Can I use my account to rent more than one bicycle?","What Payment Mode do we accept?","Bluetooth is not connecting"]
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    func setupUI(){
        contentVw.clipsToBounds = true
        contentVw.layer.masksToBounds = false;
        contentVw.layer.cornerRadius = 25
        contentVw.layer.shadowColor = UIColor.lightGray.cgColor
        contentVw.layer.shadowOffset = CGSize(width: 0, height: 4)
        contentVw.layer.shadowOpacity = 1.0
        tblVwFaq.delegate = self
        tblVwFaq.dataSource = self
        tblVwFaq.tableFooterView = UIView()
        tblVwFaq.separatorStyle = .none
    }
    @IBAction func bttnBack(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    
}
extension FaqVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArrFaq.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "FAQCell") as! FAQCell
        cell.selectionStyle = .none
       cell.lblQuestion.text = ArrFaq[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
}
