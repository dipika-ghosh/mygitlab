//
//  SubscriptionDetailsCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 08/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class SubscriptionDetailsCell: UITableViewCell {
    @IBOutlet weak var lblSubscriptionName: UILabel!
    @IBOutlet weak var lblPlanId: UILabel!
    @IBOutlet weak var lblPlanMony: UILabel!
    @IBOutlet weak var lblPlanDescription: UILabel!
    @IBOutlet weak var btnAccept: UIButton!
    @IBOutlet weak var contentVw: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
