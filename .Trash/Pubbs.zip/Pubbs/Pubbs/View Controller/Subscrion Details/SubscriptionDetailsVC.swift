//
//  SubscriptionDetailsVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 08/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase

class SubscriptionDetailsVC: UIViewController {
    var dictSubscriptionDetails = [String: Any]()
    var dictBankDetails = [String: Any]()
    @IBOutlet weak var myContentVW: UIView!
    var cell : SubscriptionDetailsCell = SubscriptionDetailsCell()
    @IBOutlet weak var tblSubscriptionDetail: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func setupUI(){
        myContentVW.clipsToBounds = true
        myContentVW.layer.masksToBounds = false;
        myContentVW.layer.cornerRadius = 25
        myContentVW.layer.shadowColor = UIColor.lightGray.cgColor
        myContentVW.layer.shadowOffset = CGSize(width: 0, height: 4)
        myContentVW.layer.shadowOpacity = 1.0
        tblSubscriptionDetail.delegate = self
        tblSubscriptionDetail.dataSource = self
        tblSubscriptionDetail.tableFooterView = UIView()
        tblSubscriptionDetail.separatorStyle = .none
    }


}

extension SubscriptionDetailsVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "SubscriptionDetailsCell") as! SubscriptionDetailsCell
        cell.selectionStyle = .none
        cell.lblSubscriptionName.text = "Subscription Plan Name : \((dictSubscriptionDetails["subscriptionPlanName"] as? String) ?? "")"//arrSubscriptionData[indexPath.row]["subscriptionPlanName"] as? String
        cell.lblPlanId.text = "Subscription Plan Id : \((dictSubscriptionDetails["subscriptionId"] as? String) ?? "")"
        cell.lblPlanMony.text = "Subscription Plan Money : \((dictSubscriptionDetails["subscriptionPlanPrice"] as? String) ?? "")"
        cell.lblPlanDescription.text = (dictSubscriptionDetails["subscriptionDescription"] as? String) ?? ""
        cell.btnAccept.addTarget(self, action: #selector(btnAgreeAction), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let dictSubscription = arrSubscriptionData[indexPath.row]
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PayNowVC") as! PayNowVC
//        vc.dictSubscriptionDetails = dictSubscriptionDetails
//        vc.dictBankDetails = dictBankDetails
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    @objc func btnAgreeAction(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PayNowVC") as! PayNowVC
        vc.dictSubscriptionDetails = dictSubscriptionDetails
        vc.dictBankDetails = dictBankDetails
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension SubscriptionDetailsVC {
    
    func updateSubscriptionPlanInUserProfile() {
        
        let update: [String : AnyObject] = ["subscriptionPlanName" : dictSubscriptionDetails["subscriptionPlanName"] as AnyObject,
                                            "subscriptionId" : dictSubscriptionDetails["subscriptionId"] as AnyObject,
                                            "subscriptionAmt" : dictSubscriptionDetails["subscriptionPlanPrice"]  as AnyObject,
                                            "subscriptionDescription" : dictSubscriptionDetails["subscriptionPlanName"] as AnyObject]
        let planId = (dictSubscriptionDetails["subscriptionId"] as? String ?? "") + "PUBBS_OD_3763606"
        let subcription: [String : AnyObject] = [planId : update as AnyObject]
        let mySubcription: [String : AnyObject] = ["MySubscriptions" : subcription as AnyObject]
        
        guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        var updateReference: DatabaseReference!
        updateReference = Database.database().reference()
        updateReference.child("iOS_Users").child(ph_no).updateChildValues(mySubcription) { (error:Error?, ref:DatabaseReference) in
            if let error = error {
                print("Data could not be saved: \(error).")
            } else {
                
                
                let alertController = UIAlertController(title: "Pubbs", message: "Data saved successfully!", preferredStyle: .alert)
                
                let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                    
                    // Code in this block will trigger when OK button tapped.
                    print("Ok button tapped");
                }
                alertController.addAction(OKAction)
                
                self.present(alertController, animated: true, completion:nil)
                print("Data saved successfully!")
            }
            
        }
    }
}
