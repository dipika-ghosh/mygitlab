//
//  MyProfileVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 29/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase

class MyProfileVC: UIViewController {
    @IBOutlet weak var tblProfile: UITableView!
    var cell : MyProfileCell = MyProfileCell()
    var profileData = [String: AnyObject]()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblProfile.delegate = self
        tblProfile.dataSource = self
        tblProfile.tableFooterView = UIView()
        tblProfile.separatorStyle = .none
         //DataManager.shared.showLoader()
        fetchProfileData()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchProfileData()
    }
    func fetchProfileData() {
//           DataManager.shared.showLoader()
        guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(ph_no).observeSingleEvent(of: .value, with: { (snapshot) in
          
            let value = snapshot.value as? [String: AnyObject]
            self.profileData = value!
            self.tblProfile.reloadData()
             //DataManager.shared.hideLoader()
        }) { (error) in
           // DataManager.shared.hideLoader()
            print(error.localizedDescription)
        }
    }
    @IBAction func changePasswordAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func bttnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension MyProfileVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "MyProfileCell") as! MyProfileCell
        cell.setData(data: profileData)
        
        cell.selectionStyle = .none
        cell.btnEdit.addTarget(self, action: #selector(editProfile), for: .touchUpInside)
        cell.contentVw.clipsToBounds = true
        cell.contentVw.layer.masksToBounds = false;
        cell.contentVw.layer.cornerRadius = 25
        cell.contentVw.layer.shadowColor = UIColor.lightGray.cgColor
        cell.contentVw.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        cell.contentVw.layer.shadowOpacity = 1.0
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    @objc func editProfile() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        vc.profileData = profileData
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
