//
//  MyProfileCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 29/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class MyProfileCell: UITableViewCell {
@IBOutlet weak var contentVw: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var lblAge: UILabel!
    
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblOperator: UILabel!
    @IBOutlet weak var btnUpdate: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setData(data: [String: AnyObject]) {
        lblName.text = (data["name"] as? String ?? "")
        lblAge.text = (data["age"] as? String ?? "")
        lblGender.text = data["gender"] as? String ?? ""
        lblAddress.text = (data["address"] as? String ?? "")
        lblMobileNo.text = (data["phone_no"] as? String ?? "")
        lblEmail.text = data["email"] as? String ?? ""
        lblOperator.text = "Operator: " + (data["AreaName"] as? String ?? "")
    }
}
