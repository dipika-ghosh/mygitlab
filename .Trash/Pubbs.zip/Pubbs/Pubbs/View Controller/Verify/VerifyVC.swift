//
//  VerifyVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 04/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
class VerifyVC: UIViewController {

    @IBOutlet weak var verifyTblVw: UITableView!
    var cell : VerifyCell = VerifyCell()
    var ph_no : String?
    var txtOtp : String?
    var postData = [String : AnyObject]()
    override func viewDidLoad() {
        super.viewDidLoad()

        verifyTblVw.delegate = self
        verifyTblVw.dataSource = self
        verifyTblVw.tableFooterView = UIView()
        verifyTblVw.separatorStyle = .none
        sendOTP()
    }
    
    @IBAction func bttnVerifyActn(_ sender: Any) {
        if (cell.txtPh_no.text != self.txtOtp){
            print("incorrect OTP")
        }else{
             VerifyOTP()
        }
       
    }
    
    func sendOTP(){
        
      let verificationCode = String(1000+arc4random_uniform(8999))
        
        let headers = ["content-type": "application/json"]
        
        self.txtOtp = verificationCode
        let request = NSMutableURLRequest(url: NSURL(string: "http://api.msg91.com/api/sendotp.php?authkey=302203AFZGbvIT8m5dc0de10&mobile=91\(ph_no!)&message=Your%20otp%20is%20\(verificationCode)&sender=SMSIND&otp=\(verificationCode)")! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 10.0)
        
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = headers
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
                
                print(httpResponse)
            }
        })
        
        dataTask.resume()
    }
    
    func VerifyOTP(){
        DataManager.shared.showLoader()
        let headers = ["content-type": "application/json"]
        let request = NSMutableURLRequest(url: NSURL(string: "http://api.msg91.com/api/verifyRequestOTP.php?authkey=302203AFZGbvIT8m5dc0de10&mobile=91\(ph_no!)&otp=\(cell.txtPh_no.text!)")! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 10.0)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = headers
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
                
                
                var ref: DatabaseReference!
                ref = Database.database().reference()
                let userID = Auth.auth().currentUser?.uid
                
                ref.child("iOS_Users").child(self.ph_no!).setValue(self.postData) {
                    (error:Error?, ref:DatabaseReference) in
                    if let error = error {
                        print("Data could not be saved: \(error).")
                    } else {
                        
                        print("Data saved successfully!")
                        UserDefaults.standard.set(self.ph_no, forKey: "user_Ph_no")
                         DataManager.shared.hideLoader()
                        let alertController = UIAlertController(title: "Pubbs", message: "Registration successfull", preferredStyle: .alert)
                        
                        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                             UserDefaults.standard.set(self.ph_no!, forKey: "user_Ph_no")
                            // Code in this block will trigger when OK button tapped.
                            print("Ok button tapped");
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                            
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }
                        
                        alertController.addAction(OKAction)
                        
                        self.present(alertController, animated: true, completion:nil)
                        
                        
                    }
                }
                
                print(httpResponse)
            }
        })
        
        dataTask.resume()
    }
    
}
extension VerifyVC: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "VerifyCell") as! VerifyCell
        cell.selectionStyle = .none
        cell.lblShowNo.text = "your OTP is successfully sent to " + self.ph_no!
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
