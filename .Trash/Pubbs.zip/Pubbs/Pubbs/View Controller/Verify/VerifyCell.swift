//
//  VerifyCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 04/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class VerifyCell: UITableViewCell {
    @IBOutlet weak var bttnVeryfy: UIButton!
    
    @IBOutlet weak var lblShowNo: UILabel!
    @IBOutlet weak var txtPh_no: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        txtPh_no?.placeholderColor(UIColor.lightGray)
        
        
        
        bttnVeryfy.layer.masksToBounds = false;
        bttnVeryfy.layer.shadowColor = UIColor.lightGray.cgColor
        bttnVeryfy.layer.shadowOffset = CGSize(width: 0, height: 0)
        bttnVeryfy.layer.shadowOpacity = 1.0
        
        bttnVeryfy.layer.cornerRadius = 25
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
