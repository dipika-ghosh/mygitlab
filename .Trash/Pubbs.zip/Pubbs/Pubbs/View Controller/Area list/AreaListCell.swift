//
//  AreaListCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 08/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class AreaListCell: UITableViewCell {

    @IBOutlet weak var lblAreaId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

