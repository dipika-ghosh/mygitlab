//
//  ArealistVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 08/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
protocol UpdateSelectedStation: class {
    func updateStationList(areaName: String, areaId: String, stationList: [[String: Any]])
}

class ArealistVC: UIViewController {

    @IBOutlet weak var myContentVw: UIView!
    @IBOutlet weak var tblVwArea: UITableView!
    var cell : AreaListCell = AreaListCell()
    var arrAreaList: [String]?
    var arrNameAreaList = [String]()
    var stationList: [[String: Any]]?
    var areaName: String?
    var myArealist = [String:Any]()
    var cityName = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        print("=====",myArealist)
        self.fetchMySelectedArea(data: myArealist)
        setupUI()
    }
    weak var delegate: UpdateSelectedStation?

    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func setupUI(){
        myContentVw.clipsToBounds = true
        myContentVw.layer.masksToBounds = false;
        myContentVw.layer.cornerRadius = 25
        myContentVw.layer.shadowColor = UIColor.lightGray.cgColor
        myContentVw.layer.shadowOffset = CGSize(width: 0, height: 4)
        myContentVw.layer.shadowOpacity = 1.0
        tblVwArea.delegate = self
        tblVwArea.dataSource = self
        tblVwArea.tableFooterView = UIView()
        tblVwArea.separatorStyle = .none
    }
    func fetchMySelectedArea(data:[String:Any]){
        for (key,value) in data{
            print(key)
            if key == self.cityName{
                if let snap = value as? [String:Any] {
                   print(snap)
                    for (myKey,myValue) in snap{
                        if myKey == "AreaList"{
                             if let opereatorValue = myValue as? [String:Any] {
                                
                                for (idKey,idValue) in opereatorValue{
                                     if let idValue1 = idValue as? [String:Any] {
                                    if let name = idValue1["name"] as? String{
                                        self.arrNameAreaList.append(name)
                                    }
                                }
                            }
                           
                            
                        }
                    }
                        
                }
            }
        }
    }
        print(self.arrNameAreaList)
        self.tblVwArea.reloadData()
    }
}
extension ArealistVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         if arrNameAreaList.count != 0{
             return arrNameAreaList.count
         }else{
            return 0
        }
       
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "AreaListCell") as! AreaListCell
        cell.selectionStyle = .none
        if arrNameAreaList.count != 0{
             cell.lblAreaId.text = arrNameAreaList[indexPath.row]
        }
       
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      //  let vc = self.storyboard?.instantiateViewController(withIdentifier: "ArealistVC") as! ArealistVC
        for controller in self.navigationController?.viewControllers ?? [] {
            if controller is HomeVC {
                guard let area = arrAreaList?[indexPath.row] else {return}
              //  let arrStation = stationList?.fi
//                let step = controller as! HomeVC
//                step.areaId = area
//                step.arrStationList = stationList!
                self.navigationController?.popToViewController(controller, animated: true)
                delegate?.updateStationList(areaName: areaName ?? "", areaId: area, stationList: stationList!)
            }
        }
//        vc.arrAreaList = areaIdsArr
//        vc.stationList = station
      //  self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
