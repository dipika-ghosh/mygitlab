//
//  LoginCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 04/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class LoginCell: UITableViewCell {

    @IBOutlet weak var bttnLogin: UIButton!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPhNo: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        txtPassword?.placeholderColor(UIColor.lightGray)
        txtPhNo?.placeholderColor(UIColor.lightGray)
        
        
        
        bttnLogin.layer.masksToBounds = false;
        bttnLogin.layer.shadowColor = UIColor.lightGray.cgColor
        bttnLogin.layer.shadowOffset = CGSize(width: 0, height: 0)
        bttnLogin.layer.shadowOpacity = 1.0
        
        bttnLogin.layer.cornerRadius = 25
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
