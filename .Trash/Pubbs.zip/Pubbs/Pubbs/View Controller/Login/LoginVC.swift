//
//  LoginVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 04/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase

class LoginVC: UIViewController,UITextFieldDelegate{

    @IBOutlet weak var tblvwLogin: UITableView!
    var cell : LoginCell = LoginCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblvwLogin.delegate = self
        tblvwLogin.dataSource = self
        tblvwLogin.tableFooterView = UIView()
        tblvwLogin.separatorStyle = .none
    }
    


    @IBAction func bttnLoginActn(_ sender: Any) {
        if isValidated(){
             fetchLoginData(my_ph_no: cell.txtPhNo.text!, my_passwords: cell.txtPassword.text!)
        }
       
    }
    func fetchLoginData(my_ph_no: String, my_passwords: String){
        DataManager.shared.showLoader()
//        let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as AnyObject
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(my_ph_no).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let get_ph_no = value?["phone_no"] as? String ?? ""
            let get_password = value?["password"] as? String ?? ""
            if (get_ph_no == my_ph_no) && (get_password == my_passwords){
                print("login successfull")
                UserDefaults.standard.set(my_ph_no, forKey: "user_Ph_no")
                DataManager.shared.hideLoader()
                let alertController = UIAlertController(title: "Pubbs", message: "login successfull", preferredStyle: .alert)
                
                let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                    
                    // Code in this block will trigger when OK button tapped.
                    print("Ok button tapped");
                    UserDefaults.standard.set(self.cell.txtPhNo.text!, forKey: "user_Ph_no")
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                   
                    self.navigationController?.pushViewController(vc, animated: true)
                    
                }
                
                alertController.addAction(OKAction)
                
                self.present(alertController, animated: true, completion:nil)
            }else{
                 DataManager.shared.hideLoader()
                print("incorrect credentials")
                 Utility.showAlert(message: "incorrect credentials", vc: self)
            }
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print(textField.text!)
        return true
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
         UserDefaults.standard.set(textField.text!, forKey: "user_Ph_no")
        print("=====",textField.text!)
        return true
    }
    func isValidated() -> Bool {
        
        if  cell.txtPhNo.text == ""
        {
            Utility.showAlert(message: "Please enter your phone number", vc: self)
            return false
        }
        else if ((cell.txtPassword.text?.isEmpty)!) || cell.txtPassword.text == " "
        {
            Utility.showAlert(message: "Please enter your password", vc: self)
            return false
        }
        else if ((cell.txtPassword.text?.count)! < 6)
        {
            Utility.showAlert(message:"Password must be 6 character", vc: self)
            return false
        }
        
        else {
            return true
        }
    }
    
}
extension LoginVC: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "LoginCell") as! LoginCell
        cell.selectionStyle = .none
        cell.txtPhNo.delegate = self
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
