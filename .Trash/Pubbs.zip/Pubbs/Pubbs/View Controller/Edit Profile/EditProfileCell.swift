//
//  EditProfileCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 01/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class EditProfileCell: UITableViewCell {
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtGender: UITextField!
    
    @IBOutlet weak var btnUpdate: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
      btnUpdate.setButton()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setData(data: [String: AnyObject]) {
        txtName.text = data["name"] as? String ?? ""
        txtAge.text = data["age"] as? String ?? ""
        txtGender.text = data["gender"] as? String ?? ""
        txtAddress.text = data["address"] as? String ?? ""
        
    }
}
