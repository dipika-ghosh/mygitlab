//
//  EditProfileVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 01/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
class EditProfileVC: UIViewController {
    @IBOutlet weak var imCheckGirl: UIImageView!
    
    @IBOutlet weak var imgCheckBoy: UIImageView!
    @IBOutlet weak var imgGirl: UIImageView!
    @IBOutlet weak var imgBoy: UIImageView!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var myVw: UIView!
    @IBOutlet weak var viewGenderChoose: UIView!
    @IBOutlet weak var containerVW: UIView!
    @IBOutlet weak var tblProfile: UITableView!
    var profileData = [String: AnyObject]()
    var cell : EditProfileCell = EditProfileCell()
    var indicatorBackView: UIView!
    var activityView = UIActivityIndicatorView(style: .whiteLarge)
    override func viewDidLoad() {
        super.viewDidLoad()
        tblProfile.delegate = self
        tblProfile.dataSource = self
        tblProfile.tableFooterView = UIView()
        tblProfile.separatorStyle = .none
      
        containerVW.layer.masksToBounds = false;
        containerVW.layer.cornerRadius = 25
        containerVW.layer.shadowColor = UIColor.lightGray.cgColor
        containerVW.layer.shadowOffset = CGSize(width: 0, height: 0)
        containerVW.layer.shadowOpacity = 1.0
//        fetchProfileData()
      setupResetPasswordVW()
    }
    func setupResetPasswordVW()
    {
        indicatorBackView = UIView(frame: CGRect(x: self.view.frame.origin.x - 30, y: self.view.frame.origin.y - 100, width:
            self.view.frame.width + 40, height: self.view.frame.height))
        indicatorBackView.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        indicatorBackView.isHidden = true
        self.indicatorBackView.translatesAutoresizingMaskIntoConstraints = true
        self.indicatorBackView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.myVw.addSubview(indicatorBackView)
        activityView.translatesAutoresizingMaskIntoConstraints = false
        self.viewGenderChoose.addSubview(activityView)
        activityView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        activityView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        let tapevent = UITapGestureRecognizer(target: self, action: #selector(self.handleTapEvent(_:)))
        indicatorBackView.addGestureRecognizer(tapevent)
        indicatorBackView.isUserInteractionEnabled = true
        
        self.btnDone.setButton()
        self.imgBoy.imageRound()
        self.imgGirl.imageRound()
        viewGenderChoose.layer.masksToBounds = false;
        viewGenderChoose.layer.cornerRadius = 30
        self.imgCheckBoy.isHidden = true
        self.imCheckGirl.isHidden = true
        self.myVw.bringSubviewToFront(viewGenderChoose)
        
    }
    @objc func handleTapEvent(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
        indicatorBackView.isHidden = true
        
        viewGenderChoose.isHidden   = true
        
    }
    @IBAction func bttnCancel(_ sender: Any) {
        self.view.endEditing(true)
        indicatorBackView.isHidden = true
        
        viewGenderChoose.isHidden   = true
    }
    @IBAction func BttnDoneActn(_ sender: Any) {
        self.view.endEditing(true)
        indicatorBackView.isHidden = true
        
        viewGenderChoose.isHidden   = true
    }
    @IBAction func bttnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnGenderSelect(_ sender: Any) {
        self.view.endEditing(true)
        indicatorBackView.isHidden = false
        viewGenderChoose.isHidden = false
    }
    
    @IBAction func bttnBoySelect(_ sender: Any) {
        self.imgCheckBoy.isHidden = false
        self.imCheckGirl.isHidden = true
        cell.txtGender.text = "male"
    }
    
    @IBAction func bttnGirlSelect(_ sender: Any) {
        self.imgCheckBoy.isHidden = true
        self.imCheckGirl.isHidden = false
         cell.txtGender.text = "female"
    }
}
extension EditProfileVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "EditProfileCell") as! EditProfileCell
      //  cell.setData(data: profileData)
        
        cell.selectionStyle = .none
        cell.btnUpdate.addTarget(self, action: #selector(updateProfile), for: .touchUpInside)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    @objc func updateProfile() {
        
        let update: [String : AnyObject] = ["name" : cell.txtName.text as AnyObject,
                                            "age" : cell.txtAge.text as AnyObject,
                                            "gender" : cell.txtGender.text as AnyObject,
                                            "address" : cell.txtAddress.text as AnyObject]
//        let update: [String : AnyObject] = ["name" : "Dipika" as AnyObject,
//                                            "age" : "30" as AnyObject,
//                                            "gender" : "F" as AnyObject,
//                                            "address" : "bedia para,dumdum" as AnyObject]
        guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        var updateReference: DatabaseReference!
        updateReference = Database.database().reference()
        updateReference.child("iOS_Users").child(ph_no).updateChildValues(update) { (error:Error?, ref:DatabaseReference) in
            if let error = error {
                print("Data could not be saved: \(error).")
            } else {
                
                
                let alertController = UIAlertController(title: "Pubbs", message: "Data saved successfully!", preferredStyle: .alert)
                
                let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                    
                    // Code in this block will trigger when OK button tapped.
                    print("Ok button tapped");
                    self.navigationController?.popViewController(animated: true)
                }
                alertController.addAction(OKAction)
                
                self.present(alertController, animated: true, completion:nil)
                print("Data saved successfully!")
            }
            
        }
    }
}
