//
//  ChangePasswordCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 13/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class ChangePasswordCell: UITableViewCell {
    @IBOutlet weak var txtConfirmPass: UITextField!
    
    @IBOutlet weak var bttnUpdate: UIButton!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtPhNo: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
       bttnUpdate.setButton()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
