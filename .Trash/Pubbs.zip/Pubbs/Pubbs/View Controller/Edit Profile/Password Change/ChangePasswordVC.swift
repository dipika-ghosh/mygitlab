//
//  ChangePasswordVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 13/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
class ChangePasswordVC: UIViewController {

    @IBOutlet weak var contentVw: UIView!
    @IBOutlet weak var tblChangePass: UITableView!
    var cell : ChangePasswordCell = ChangePasswordCell()
    override func viewDidLoad() {
        super.viewDidLoad()

        tblChangePass.delegate = self
        tblChangePass.dataSource = self
        tblChangePass.tableFooterView = UIView()
        tblChangePass.separatorStyle = .none
        
        contentVw.layer.masksToBounds = false;
        contentVw.layer.cornerRadius = 25
        contentVw.layer.shadowColor = UIColor.lightGray.cgColor
        contentVw.layer.shadowOffset = CGSize(width: 0, height: 0)
        contentVw.layer.shadowOpacity = 1.0
    }
    
    @IBAction func bttnUpdateActn(_ sender: Any) {
        if isValidated(){
            DataManager.shared.showLoader()
            let update: [String : AnyObject] = ["password" : cell.txtPass.text as AnyObject
            ]
            
            guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
            var updateReference: DatabaseReference!
            updateReference = Database.database().reference()
            updateReference.child("iOS_Users").child(ph_no).updateChildValues(update) { (error:Error?, ref:DatabaseReference) in
                if let error = error {
                     DataManager.shared.hideLoader()
                    print("Data could not be saved: \(error).")
                }
                else
                {
                     DataManager.shared.hideLoader()
                    let alertController = UIAlertController(title: "Pubbs", message: "Password update successfully!", preferredStyle: .alert)
                    
                    let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                       
                        print("Ok button tapped");
                        self.navigationController?.popViewController(animated: true)
                    }
                    alertController.addAction(OKAction)
                    
                    self.present(alertController, animated: true, completion:nil)
                    print("Data saved successfully!")
                }
                
            }
        }
       

    }
    
    @IBAction func bttnBack(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    
}
extension ChangePasswordVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "ChangePasswordCell") as! ChangePasswordCell
        //  cell.setData(data: profileData)
         guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return cell}
        cell.txtPhNo.text = ph_no
        cell.selectionStyle = .none
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
}
    func isValidated() -> Bool {
        
       
         if ((cell.txtPass.text?.isEmpty)!) || cell.txtPass.text == " "
        {
            Utility.showAlert(message: "Please enter your password", vc: self)
            return false
        }
        else if ((cell.txtPass.text?.count)! < 6)
        {
            Utility.showAlert(message:"Password must be 6 character", vc: self)
            return false
        }
            
        else if (cell.txtConfirmPass.text?.isEmpty)! || (cell.txtConfirmPass.text) == " "
        {
            Utility.showAlert(message: "Please enter your confirm password", vc: self)
            return false
        }
        else if (cell.txtPass.text != cell.txtConfirmPass.text)
        {
            Utility.showAlert(message: "Password mismatch!", vc: self)
            return false
        }
        else {
            return true
        }
    }
}
