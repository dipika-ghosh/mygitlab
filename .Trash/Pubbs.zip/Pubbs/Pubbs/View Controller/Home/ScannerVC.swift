//
//  ScannerVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 13/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import AVFoundation
protocol BarcodeDelegate{
    func barcodeReaded(barcode: String)
}
class ScannerVC: UIViewController,AVCaptureMetadataOutputObjectsDelegate {

    var delegate: BarcodeDelegate?
    @IBOutlet weak var ViewPreview: UIView!
    var captureSession: AVCaptureSession?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    var isReading: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ViewPreview.layer.cornerRadius = 5;
        
        captureSession = nil;
        
        
        if !isReading {
            if (self.startReading()) {
                //  btnStartStop.setTitle("Stop", for: .normal)
                //  lblBarcode.text = "Scanning for QR Code..."
            }
        }
        else {
            stopReading()
            // btnStartStop.setTitle("Start", for: .normal)
        }
        isReading = !isReading
        
        
    }
    
    @IBAction func backActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func startReading() -> Bool {
        let captureDevice = AVCaptureDevice.default(for: .video)//defaultDevice(withMediaType: AVMediaTypeVideo)
        do {
            let input = try AVCaptureDeviceInput(device: captureDevice!)
            captureSession = AVCaptureSession()
            captureSession?.addInput(input)
            // Do the rest of your work...
        } catch let error as NSError {
            // Handle any errors
            print(error)
            return false
        }
        
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
        videoPreviewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        videoPreviewLayer.frame = ViewPreview.layer.bounds
        ViewPreview.layer.addSublayer(videoPreviewLayer)
        
        /* Check for metadata */
        let captureMetadataOutput = AVCaptureMetadataOutput()
        captureSession?.addOutput(captureMetadataOutput)
        captureMetadataOutput.metadataObjectTypes = captureMetadataOutput.availableMetadataObjectTypes
        print(captureMetadataOutput.availableMetadataObjectTypes)
        captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        captureSession?.startRunning()
        
        return true
    }
    @objc func stopReading() {
        captureSession?.stopRunning()
        captureSession = nil
        videoPreviewLayer.removeFromSuperlayer()
    }
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        for metadata in metadataObjects {
            if let readableObject = metadata as? AVMetadataMachineReadableCodeObject,
                let code = readableObject.stringValue {
                dismiss(animated: true)
                delegate?.barcodeReaded(barcode: code)
                print(code)
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                vc.qr_code = code
                self.navigationController?.pushViewController(vc, animated: true)
                
                self.performSelector(onMainThread: #selector(stopReading), with: nil, waitUntilDone: false)
                isReading = false;
                
            }
        }
        
    }

}
