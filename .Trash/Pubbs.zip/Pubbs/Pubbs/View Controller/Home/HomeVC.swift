//
//  HomeVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 05/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import GoogleMaps
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
import CoreBluetooth
class HomeVC: BaseViewController,CLLocationManagerDelegate{
    @IBOutlet weak var imgCall: UIImageView!
    @IBOutlet weak var imgSearch: UIImageView!
    
    @IBOutlet weak var VwCat: UIView!
    @IBOutlet weak var bttnCat: UIButton!
    @IBOutlet weak var bttnMenu: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var SearchVw: UIView!
    @IBOutlet weak var Bttncall: UIButton!
    @IBOutlet weak var mapVw: UIView!
    var mapView: GMSMapView?
    var locationManager = CLLocationManager()
     var path = GMSMutablePath()
    var flagShowVW = false
    var currentCityName : String?
    var areaId: String?
    var arrStationList = [[String: Any]]()
    var MyrxByteArray = [UInt8]()
    var lockReturnArr = [UInt8]()
    
    private(set) var connectedPeripheral : CBPeripheral?
    var peripherals = [CBPeripheral]()
    var centralManager: CBCentralManager!
    var peripheral: CBPeripheral!
    var currentCharacteristic: CBCharacteristic! = nil
    
    let BEAN_SCRATCH_UUID = CBUUID(string: "6E400003-B5A3-F393-E0A9-E50E24DCCA9E")//CBUUID(string:
    let BEAN_SERVICE_UUID = CBUUID(string: "6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    var characteristic : CBCharacteristic!
     var qr_code : String?
    var lockStatus : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton(btnShowMenu: bttnMenu)
        //DataManager.shared.showLoader()
         let my_ph_no = UserDefaults.standard.value(forKey: "user_Ph_no")
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(my_ph_no! as! String).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let areaName = value?["AreaName"] as? String
            if areaName != nil{
                self.getAreaIdFromDatabase()
            }else{
                DataManager.shared.hideLoader()
                let refreshAlert = UIAlertController(title: "Pubbs", message: "Please choose your operator", preferredStyle: UIAlertController.Style.alert)
                
                refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                    print("Handle Ok logic here")
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "OperatorListVC") as! OperatorListVC
                    vc.currentCityName = self.currentCityName
                    self.navigationController?.pushViewController(vc, animated: true)
                    self.VwCat.isHidden = true
                    self.flagShowVW = false
                    
                }))
                
                refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                    print("Handle Cancel Logic here")
                }))
                
                self.present(refreshAlert, animated: true, completion: nil)
            }
          
        }) { (error) in
            print(error.localizedDescription)
        }
        
        
        
        getcurrentlocation()
        
        self.VwCat.isHidden = true
        if qr_code != nil{
            print("BLE here")
            self.startManager()
            
        }

        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if qr_code != nil{
            print("BLE here")
            self.startManager()
            
        }
    }
    @IBAction func bttnChangeOperator(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "OperatorListVC") as! OperatorListVC
        vc.currentCityName = self.currentCityName
        self.navigationController?.pushViewController(vc, animated: true)
        self.VwCat.isHidden = true
        self.flagShowVW = false
    }
    
    @IBAction func bttnTutorial(_ sender: Any) {
    }
    @IBAction func bttnCatActn(_ sender: Any) {
        if flagShowVW == false{
            self.VwCat.isHidden = false
            self.SearchVw.addSubview(self.VwCat)
            self.flagShowVW = true
        }else{
            self.VwCat.isHidden = true
            self.flagShowVW = false
        }
        
    }
    @IBAction func bttnScanActn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
       
        self.navigationController?.pushViewController(vc, animated: true)
         // self.startManager()
//        let my_ph_no = UserDefaults.standard.value(forKey: "user_Ph_no")
//        let ref = Database.database().reference(withPath: "iOS_Users")
//        ref.child(my_ph_no! as! String).observeSingleEvent(of: .value, with: { (snapshot) in
//            // Get user value
//            let value = snapshot.value as? NSDictionary
//            let areaName = value?["AreaName"] as? String
//            if areaName != nil{
//                let vc = self.storyboard?.instantiateViewController(withIdentifier: "SubscriptionVC") as! SubscriptionVC
//                self.navigationController?.pushViewController(vc, animated: true)
//            }else{
//                let refreshAlert = UIAlertController(title: "Pubbs", message: "Please choose your operator", preferredStyle: UIAlertController.Style.alert)
//
//                refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
//                    print("Handle Ok logic here")
//
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "OperatorListVC") as! OperatorListVC
//                    vc.currentCityName = self.currentCityName
//                    self.navigationController?.pushViewController(vc, animated: true)
//                    self.VwCat.isHidden = true
//                    self.flagShowVW = false
//
//                }))
//
//                refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
//                    print("Handle Cancel Logic here")
//                }))
//
//                self.present(refreshAlert, animated: true, completion: nil)
//            }
//
//        }) { (error) in
//            print(error.localizedDescription)
//        }
//
       
    }
    func getcurrentlocation() {
        
       // if (allStationsLatLongArr.count != 0){
            let camera = GMSCameraPosition.camera(withLatitude: (locationManager.location?.coordinate.latitude ?? 0.0), longitude: (locationManager.location?.coordinate.longitude ?? 0.0), zoom: 20.0)
            self.mapView = GMSMapView.map(withFrame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.mapVw.frame.height), camera: camera)
            mapView?.settings.myLocationButton = true
            mapView?.isMyLocationEnabled = true
            mapView?.settings.compassButton = true
            self.Bttncall.layer.cornerRadius = 0.5 * Bttncall.bounds.size.width
            Bttncall.clipsToBounds = true
            Bttncall.layer.masksToBounds = false;
            Bttncall.layer.shadowColor = UIColor.lightGray.cgColor
            Bttncall.layer.shadowOffset = CGSize(width: 0, height: 4)
            Bttncall.layer.shadowOpacity = 1.0
        
            SearchVw.clipsToBounds = true
            SearchVw.layer.masksToBounds = false;
            SearchVw.layer.cornerRadius = 25
            SearchVw.layer.shadowColor = UIColor.lightGray.cgColor
           SearchVw.layer.shadowOffset = CGSize(width: 0, height: 4)
           SearchVw.layer.shadowOpacity = 1.0
        
            self.mapVw.addSubview(mapView!)
            self.mapVw?.addSubview(Bttncall)
            self.mapVw?.addSubview(SearchVw)
        
            self.SearchVw.addSubview(imgSearch)
            self.SearchVw.addSubview(txtSearch)
            self.Bttncall.addSubview(self.imgCall)
            self.mapView?.isMyLocationEnabled = true
            self.mapView?.settings.myLocationButton = true
            mapView?.isMyLocationEnabled = true
            mapView?.settings.compassButton = true
            self.locationManager.delegate = self
            
            let polygon = GMSPolygon(path: path)
        
            polygon.fillColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            polygon.strokeColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)//UIColor.withAlphaComponent(#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1))(0.8)
            //polygon.strokeWidth = 0.2
            polygon.map = mapView
        
//            for index in 0...allStationsLatLongArr.count - 1 {
//
//                let data = allStationsLatLongArr[index]
//
//                let location = CLLocationCoordinate2D(latitude: data.latitude, longitude: data.longitude)
//                print("location: \(location)")
//                let marker = GMSMarker()
//                marker.position = location
//                marker.icon = self.imageWithImage(image: UIImage(named: "cycle")!, scaledToSize: CGSize(width: 30.0, height: 30.0))
//
//                marker.snippet = stationNameArr[index]
//                marker.map = mapView
//
//          //  }
//
//
//        }
        
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: locationManager.location?.coordinate.latitude ?? 0.0, longitude:  locationManager.location?.coordinate.longitude ?? 0.0) // <- New York
        
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, _) -> Void in
            
            placemarks?.forEach { (placemark) in
                
                if let city = placemark.locality {
                    print("------",city)
                    self.currentCityName = city
                } // Prints "New York"
            }
        })
    }
    
}

extension HomeVC: UpdateSelectedStation {
    func updateStationList(areaName: String, areaId: String, stationList: [[String : Any]]) {
//        arrStationList = stationList.filter { (station) -> Bool in
//            station["areaId"] as! String == areaId
//        }
        saveAreaIDRspectToUser(areaName: areaName, areaId: areaId)
        getcurrentlocation()
        getActualStationList(areaId: areaId, stationList: stationList)
    }
    func getActualStationList(areaId: String, stationList: [[String : Any]]) {
        arrStationList.removeAll()
        for item in stationList {
            guard let area = item["areaId"] as? String, area == areaId else { continue }
            arrStationList.append(item)
        }
        guard !arrStationList.isEmpty, let stationArea = arrStationList.first else {return }
        setAllStationInMap(of: stationArea)
    }
    
    func setAllStationInMap(of stationArea: [String: Any]) {
         DataManager.shared.hideLoader()
        guard let latitude = stationArea["stationLatitude"] as? String, let longitude = stationArea["stationLongitude"] as? String else {return}
        let camera = GMSCameraPosition.camera(withLatitude: Double(latitude) as! CLLocationDegrees, longitude: Double(longitude) as! CLLocationDegrees, zoom: 13.0)
      //  self.mapView = GMSMapView.map(withFrame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.mapVw.frame.height), camera: camera)
        mapView?.camera = camera
        mapView?.animate(to: camera)
        let location = CLLocationCoordinate2D(latitude: Double(latitude) as! CLLocationDegrees, longitude: Double(longitude) as! CLLocationDegrees)
        print("location: \(location)")
        let marker = GMSMarker()
        marker.position = location
        marker.icon = self.imageWithImage(image: UIImage(named: "areaIcon")!, scaledToSize: CGSize(width: 30.0, height: 30.0))
        marker.map = mapView
        if let stationRadious = stationArea["stationRadius"] as? String {
            let circ = GMSCircle(position: location, radius: ((Double(stationRadious)) ?? 0) * 500)
            circ.fillColor = UIColor.withAlphaComponent(#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1))(0.2)
            circ.strokeColor = UIColor.withAlphaComponent(#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1))(0.2)
           // circ.strokeWidth = 1.0;
            circ.map = mapView
        }
        //            marker.snippet = stationNameArr[index]
        guard let markerList = stationArea["markerList"] as? [[String: Any]] else {return}
        let gsmPath = GMSMutablePath()
        for marker in markerList {
            let latitudeMa = marker["latitude"] as? Double ?? Double(marker["latitude"] as? String ?? "")
            let longitudeMa = marker["longitude"] as? Double ?? Double(marker["longitude"] as? String ?? "")
            let location = CLLocationCoordinate2D(latitude: latitudeMa as! CLLocationDegrees, longitude: longitudeMa as! CLLocationDegrees)
            print("location: \(location)")
            let marker = GMSMarker()
            marker.position = location
            marker.icon = self.imageWithImage(image: UIImage(named: "areaIcon")!, scaledToSize: CGSize(width: 30.0, height: 30.0))
            gsmPath.addLatitude(location.latitude, longitude: location.longitude)
//            marker.snippet = stationNameArr[index]
            marker.map = mapView
            
        }
        let latitudeMa = markerList.first?["latitude"] as? Double ?? Double(markerList.first?["latitude"] as? String ?? "")
        let longitudeMa = markerList.first?["longitude"] as? Double ?? Double(markerList.first?["longitude"] as? String ?? "")
        gsmPath.addLatitude(latitudeMa as! CLLocationDegrees, longitude: longitudeMa as! CLLocationDegrees)
        
        
        let fillingPolygon = GMSPolygon(path:path)
        let fillColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
        fillingPolygon.fillColor = fillColor
        fillingPolygon.map = mapView
        
        
        
        
       // let polyLine = GMSPolyline(path: gsmPath)
       // polyLine.strokeWidth = 1
        
       // polyLine.strokeColor = UIColor.withAlphaComponent(#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1))(0.8)//UIColor.blue
       
        //polyLine.map = mapView
        DataManager.shared.hideLoader()
    }
    
    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    func saveAreaIDRspectToUser(areaName: String, areaId: String) {
        let areaID: [String : AnyObject] = ["AreaName" : areaName as AnyObject,
                                            "AreaID" : areaId as AnyObject]
        guard let ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        var updateReference: DatabaseReference!
        updateReference = Database.database().reference()
        updateReference.child("iOS_Users").child(ph_no).updateChildValues(areaID) { (error:Error?, ref:DatabaseReference) in
            if let error = error {
                print("Data could not be saved: \(error).")
            } else {
                print("Data saved successfully!")
            }
            
        }
      //  ref.child("iOS_Users").child(self.ph_no!).setValue(self.postData) {
    }
    
}

extension HomeVC {
    func getAreaIdFromDatabase() {
        // DataManager.shared.showLoader()
        guard let my_ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(my_ph_no).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            if let areaName = value?["AreaName"] as? String, let areaID = value?["AreaID"] as? String {
                self.getAreaData(areaName: areaName, areaID: areaID)
            }
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func getAreaData(areaName: String, areaID: String) {
        var stationArea = [[String: Any]]()
        let ref = Database.database().reference(withPath: areaName)
        ref.observeSingleEvent(of: .value, with: { snapshot in
            if !snapshot.exists() { return }
            // print(snapshot) // Its print all values including Snap (User)
            print(snapshot.value!)
            // let Zonename = snapshot.childSnapshot(forPath: "Zone").value as? [String: Any]
            let stationDic = snapshot.childSnapshot(forPath: "Station").value as? [String: Any]
            let stationDicValue = stationDic?.values
            for item in stationDicValue! {
                stationArea.append(item as! [String : Any])
            }
            self.getActualStationList(areaId: areaID, stationList: stationArea)
        })
    }
}

extension HomeVC:CBCentralManagerDelegate,CBPeripheralDelegate{
    //MARK: === BLE =====
    func startManager(){
        centralManager = CBCentralManager(delegate: self, queue: DispatchQueue.main)
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch (central.state)
        {
        case .unsupported:
            print("BLE Unsupported")
            break
            print("BLE unauthorized")
            break
        case .poweredOff:
            print("BLE is not on.")
            break
        case .poweredOn:
            print("BLE is on.")
            print("Scanning...")
            self.centralManager?.scanForPeripherals(withServices: nil, options: nil)
            break
        case .unknown:
            print("BLE state unknown")
            break
        default:
            print("BLE state default.")
        }
    }
    
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        print("Did discover peripheral", peripheral)
        let device = (advertisementData as NSDictionary)
            .object(forKey: CBAdvertisementDataLocalNameKey)
            as? NSString
        
        //  if device?.contains("CFL Nordic -testing1") == true {
        if device?.contains("PUBBS_Ble_Lock") == true {
            self.stopScan()
            
            self.connectedPeripheral = peripheral
            self.connectedPeripheral!.delegate = self
            
            central.connect(peripheral, options: nil)
        }
        
        
        
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        print("Connected to \(peripheral)")
        // central.connect(peripheral, options: nil)
        
        self.stopScan()
        
        if self.lockStatus == "open"{
            self.stopScan()
            
            peripheral.discoverServices(nil)
        }
        else{
            let refreshAlert = UIAlertController(title: "Pubbs", message: "Connecting to... \(peripheral.name!)", preferredStyle: UIAlertController.Style.alert)
            
            refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                print("Handle Ok logic here")
                self.stopScan()
                
                peripheral.discoverServices(nil)
                
                
            }))
            
            refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                print("Handle Cancel Logic here")
            }))
            
            present(refreshAlert, animated: true, completion: nil)
        }
    }
    
    
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("connection failed", error as Any)
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if self.connectedPeripheral != nil {
            self.connectedPeripheral!.delegate = nil
            self.connectedPeripheral = nil
        }
        print("Disconnected.", error as Any)
        self.startManager()
        
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverIncludedServicesFor service: CBService, error: Error?) {
        for charateristic in service.characteristics!
        {
            
        }
        
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        
        for service in peripheral.services! {
            let thisService = service as CBService
            
            if service.uuid == BEAN_SERVICE_UUID {
                peripheral.discoverCharacteristics(nil,for: thisService)
            }
        }
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        
        if characteristic.uuid == BEAN_SCRATCH_UUID {
            self.characteristic = characteristic
            print("my uuid===",characteristic.uuid)
            
            
        }
        
        
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        print("counter dipika",characteristic)
        
        
        let rxData = characteristic.value
        if let rxData = rxData {
            let numberOfBytes = rxData.count
            var rxByteArray = [UInt8](repeating: 0, count: numberOfBytes)
            (rxData as NSData).getBytes(&rxByteArray, length: numberOfBytes)
            //print("recieve data",rxByteArray)
            self.MyrxByteArray = rxByteArray
            print("recieve data",self.MyrxByteArray)
            let lastTenElements = Array(self.MyrxByteArray.suffix(8))
            let lastFourElements = Array(self.MyrxByteArray.suffix(4))
            self.lockReturnArr = lastTenElements
            print("my end range==",self.lockReturnArr)
            
            if lastFourElements == [1, 1, 0, 0]{
                
                if self.lockStatus != "open"{
                    let refreshAlert = UIAlertController(title: "Connected", message: "Do you want to start your ride?", preferredStyle: UIAlertController.Style.alert)
                    
                    refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                        print("Handle Ok logic here")
                        self.lockStatus = "open"
                        
                        self.startManager()
                        
                        
                    }))
                    
                    refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                        print("Handle Cancel Logic here")
                    }))
                    
                    present(refreshAlert, animated: true, completion: nil)
                }
            }
            else if lastFourElements == [2, 1, 0, 0]
            {
                if self.lockStatus != "open"{
                    let refreshAlert = UIAlertController(title: "Connected", message: "Your lock is already open", preferredStyle: UIAlertController.Style.alert)
                    
                    refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                        print("Handle Ok logic here")
                        
                        
                    }))
                    
                    refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                        print("Handle Cancel Logic here")
                    }))
                    
                    present(refreshAlert, animated: true, completion: nil)
                }else
                {
                    self.connectedPeripheral!.delegate = nil
                    self.connectedPeripheral = nil
                }
                
            }
            
        }
        
        
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        print(characteristic.value)
        print(error)
    }
    
    
    
    func writeValue(data: Data, forCharacteristic characteristic: CBCharacteristic, type: CBCharacteristicWriteType) {
        if connectedPeripheral == nil {
            return
        }
        connectedPeripheral?.writeValue(data, for: characteristic, type: type)
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        for characteristic in service.characteristics! {
            let thisCharacteristic = characteristic as CBCharacteristic
            
            //  if thisCharacteristic.uuid == BEAN_SCRATCH_UUID {
            
            peripheral.setNotifyValue(true,for: thisCharacteristic)
            let descriptor = peripheral.discoverDescriptors(for: thisCharacteristic)
            
            peripheral.readValue(for: characteristic)
            
            
            /// Combined all those 4 data and write as data
            
            var finalData = NSMutableData()
            
            // else if self.lockStatus == "open"{
            /// Combined all those 4 data and write as data
            var step1 = toByteArray(UInt16(15))
            
            
            var step2 = toByteArray(UInt16(8))
            var step3 = toByteArray(UInt16(0))
            
            var step4 = toByteArray(UInt16(5))
            var step5 = toByteArray(UInt16(70))
            
            
            var step6 = toByteArray(UInt16(78))
            
            var step7 = toByteArray(UInt16(0))
            
            var step8 = toByteArray(UInt16(0))
            
            var step9 = toByteArray(UInt16(0))
            
            
            
            
            var step10 = toByteArray(UInt16(0))
            
            var step11 = toByteArray(UInt16(0))
            
            var step12 = toByteArray(UInt16(0))
            
            var step13 = toByteArray(UInt16(1))
            
            var step14 = toByteArray(UInt16(1))
            
            var step15 = toByteArray(UInt16(0))
            
            var step16 = toByteArray(UInt16(0))
            
            
            if step1.contains(0){
                step1 = [step1.remove(at: 0)]
            }
            
            if step2.contains(0){
                step2 = [step2.remove(at: 0)]
            }
            if step3.contains(0){
                step3 = [step3.remove(at: 0)]
            }
            if step4.contains(0){
                step4 = [step4.remove(at: 0)]
            }
            if step5.contains(0){
                step5 = [step5.remove(at: 0)]
            }
            if step6.contains(0){
                step6 = [step6.remove(at: 0)]
            }
            if step7.contains(0){
                step7 = [step7.remove(at: 0)]
            }
            
            if step8.contains(0){
                step8 = [step8.remove(at: 0)]
            }
            
            if step9.contains(0){
                step9 = [step9.remove(at: 0)]
            }
            
            if step10.contains(0){
                step10 = [step10.remove(at: 0)]
            }
            
            
            if step11.contains(0){
                step11 = [step11.remove(at: 0)]
            }
            if step12.contains(0){
                step12 = [step12.remove(at: 0)]
            }
            
            if step13.contains(0){
                step13 = [step13.remove(at: 0)]
            }
            if step14.contains(0){
                step14 = [step14.remove(at: 0)]
            }
            
            if step15.contains(0){
                step15 = [step15.remove(at: 0)]
            }
            
            if step16.contains(0){
                step16 = [step16.remove(at: 0)]
            }
            finalData.append(Data(step1))
            
            
            finalData.append(Data(step2))
            
            finalData.append(Data(step3))
            finalData.append(Data(step4))
            finalData.append(Data(step5))
            finalData.append(Data(step6))
            finalData.append(Data(step7))
            finalData.append(Data(step8))
            finalData.append(Data(step9))
            
            finalData.append(Data(step10))
            finalData.append(Data(step11))
            finalData.append(Data(step12))
            finalData.append(Data(step13))
            finalData.append(Data(step14))
            finalData.append(Data(step15))
            finalData.append(Data(step16))
            
            print("send data to lock===",finalData)
            
            if self.lockStatus == "open"{
                
                finalData.setData(NSData() as Data)
                
                
                print("recieve data",self.MyrxByteArray)
                for index in 0..<self.MyrxByteArray.count - 4 {
                    
                    var myElement = toByteArray(UInt16(self.MyrxByteArray[index]))
                    if myElement.contains(0){
                        myElement = [myElement.remove(at: 0)]
                    }
                    finalData.append(Data(myElement))
                    
                }
                
                
                
                var myStep1 = toByteArray(UInt16(2))
                
                var myStep2 = toByteArray(UInt16(1))
                
                var myStep3 = toByteArray(UInt16(0))
                
                var myStep4 = toByteArray(UInt16(0))
                
                
                if myStep1.contains(0){
                    myStep1 = [myStep1.remove(at: 0)]
                }
                if myStep2.contains(0){
                    myStep2 = [myStep2.remove(at: 0)]
                }
                if myStep3.contains(0){
                    myStep3 = [myStep3.remove(at: 0)]
                }
                if myStep4.contains(0){
                    myStep4 = [myStep4.remove(at: 0)]
                }
                
                finalData.append(Data(myStep1))
                finalData.append(Data(myStep2))
                finalData.append(Data(myStep3))
                finalData.append(Data(myStep4))
                print("send data to lock second time===",finalData)
                
                
                
            }
            peripheral.writeValue(finalData as Data, for: thisCharacteristic, type: CBCharacteristicWriteType.withResponse)
            // self.peripheral.setNotifyValue(true,for: thisCharacteristic)
            
            
        }
    }
    
    
    func toByteArray<T>(_ value: T) -> [UInt8] {
        var value = value
        return withUnsafeBytes(of: &value) { Array($0) }
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        
        for request in requests {
            if let value = request.value {
                
                let messageText = String(data: value, encoding: String.Encoding.utf8) as! String
            }
            /*this will trigger delegate call back */
            peripheral.respond(to: request, withResult: .success)
        }
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        
        print("peripeheral have received the write successfully, kind of three way hand shaking technique")
    }
    
    func stopScan(){
        self.centralManager.stopScan()
    }
    
    //MARK: ===END===
}
