//
//  SubscriptionVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 06/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase

class SubscriptionVC: UIViewController{

    @IBOutlet weak var myContentVW: UIView!
    @IBOutlet weak var tblVwSubscription: UITableView!
     var cell : SubscriptionCell = SubscriptionCell()
    var arrSubscriptionData = [[String: Any]]()
    var bankDetails = [String: Any]()
    override func viewDidLoad() {
        super.viewDidLoad()

       setupUI()
        getAreaIdFromDatabase()
        
    }
    


    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func setupUI(){
        myContentVW.clipsToBounds = true
        myContentVW.layer.masksToBounds = false;
        myContentVW.layer.cornerRadius = 25
        myContentVW.layer.shadowColor = UIColor.lightGray.cgColor
        myContentVW.layer.shadowOffset = CGSize(width: 0, height: 4)
        myContentVW.layer.shadowOpacity = 1.0
        tblVwSubscription.delegate = self
        tblVwSubscription.dataSource = self
        tblVwSubscription.tableFooterView = UIView()
        tblVwSubscription.separatorStyle = .none
    }
}
extension SubscriptionVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrSubscriptionData.count
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "SubscriptionCell") as! SubscriptionCell
        cell.selectionStyle = .none
        cell.lblSubscriptionName.text = arrSubscriptionData[indexPath.row]["subscriptionPlanName"] as? String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dictSubscription = arrSubscriptionData[indexPath.row]
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SubscriptionDetailsVC") as! SubscriptionDetailsVC
        vc.dictSubscriptionDetails = dictSubscription
        vc.dictBankDetails = bankDetails
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
extension SubscriptionVC {
    func getAreaIdFromDatabase() {
        DataManager.shared.showLoader()
        guard let my_ph_no = UserDefaults.standard.value(forKey: "user_Ph_no") as? String else {return}
        let ref = Database.database().reference(withPath: "iOS_Users")
        ref.child(my_ph_no).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            if let areaName = value?["AreaName"] as? String, let areaID = value?["AreaID"] as? String {
                self.getSubscriptionData(areaName: areaName, areaID: areaID)
            }
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    func getSubscriptionData(areaName: String, areaID: String) {
//        arrSubscriptionData = [[String: Any]]()
       // arrSubscriptionData.removeAll()
        let ref = Database.database().reference(withPath: areaName)
        ref.observeSingleEvent(of: .value, with: { snapshot in
            if !snapshot.exists() { return }
            // print(snapshot) // Its print all values including Snap (User)
            print(snapshot.value!)
            // let Zonename = snapshot.childSnapshot(forPath: "Zone").value as? [String: Any]
            let bankDetailsDic = snapshot.childSnapshot(forPath: "BankDetails").value as? [String: Any]
            let values = bankDetailsDic?.values
            self.bankDetails = values!.first as! [String : Any]
            let subscriptionDic = snapshot.childSnapshot(forPath: "Subscription").value as? [String: Any]
            let subscriptionDicValue = subscriptionDic?.values
            for item in subscriptionDicValue! {
                self.arrSubscriptionData.append(item as! [String : Any])
                self.tblVwSubscription.reloadData()
                 DataManager.shared.hideLoader()
            }
           // self.getActualStationList(areaId: areaID, stationList: stationArea)
        })
    }
}
