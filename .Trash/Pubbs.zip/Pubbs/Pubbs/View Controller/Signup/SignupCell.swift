//
//  SignupCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 07/12/19.
//  Copyright © 2019 Dipika Ghosh. All rights reserved.
//

import UIKit

class SignupCell: UITableViewCell {
    @IBOutlet weak var txtConfirmPass: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhNo: UITextField!
    
    @IBOutlet weak var signupBttn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        txtConfirmPass?.placeholderColor(UIColor.lightGray)
        txtPass?.placeholderColor(UIColor.lightGray)
        txtEmail?.placeholderColor(UIColor.lightGray)
        txtPhNo?.placeholderColor(UIColor.lightGray)
        
        
        
        signupBttn.layer.masksToBounds = false;
        signupBttn.layer.shadowColor = UIColor.lightGray.cgColor
        signupBttn.layer.shadowOffset = CGSize(width: 0, height: 0)
        signupBttn.layer.shadowOpacity = 1.0
        
        signupBttn.layer.cornerRadius = 25
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
