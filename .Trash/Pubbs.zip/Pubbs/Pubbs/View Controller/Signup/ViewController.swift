//
//  ViewController.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 07/12/19.
//  Copyright © 2019 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase

class ViewController: UIViewController {
 var cell : SignupCell = SignupCell()
    
    
    @IBOutlet weak var tblVwSignup: UITableView!
     
    override func viewDidLoad() {
        super.viewDidLoad()
        tblVwSignup.delegate = self
        tblVwSignup.dataSource = self
        tblVwSignup.tableFooterView = UIView()
        tblVwSignup.separatorStyle = .none
        
//        if let _ = UserDefaults.standard.value(forKey: "user_Ph_no") {
//            
//            let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
//            self.navigationController?.pushViewController(vc, animated: true)
//        }

        
        
    }
    @IBAction func bttnLogin(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func signupBttnActn(_ sender: Any) {
        if isValidated(){
            let phone_no = cell.txtPhNo.text
            let email = cell.txtEmail.text
            let password = cell.txtPass.text
            
            
            let userID = Auth.auth().currentUser?.uid
            let post: [String : AnyObject] = ["phone_no" : phone_no as AnyObject,
                                              "email" : email as AnyObject,
                                              "password" : password as AnyObject,
                                              "address" : "address" as AnyObject,
                                              "age" : "age" as AnyObject,
                                              "gender" : "gender" as AnyObject,
                                              "name" : "name" as AnyObject,
                                              "user_id" : "PUBBS-\(userID ?? "")" as AnyObject,
                                              "device_token" : "device_token" as AnyObject
            ]
           
            let alertController = UIAlertController(title: "Pubbs", message: "Please verify your phone number to complete your signup process!", preferredStyle: .alert)
            
            let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                
                // Code in this block will trigger when OK button tapped.
                print("Ok button tapped");
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "VerifyVC") as! VerifyVC
                vc.ph_no = self.cell.txtPhNo.text!
                vc.postData = post
                
                self.navigationController?.pushViewController(vc, animated: true)
                
            }
            
            alertController.addAction(OKAction)
            
            self.present(alertController, animated: true, completion:nil)
        }
        
        
        
    }
    func isValidated() -> Bool {
        
        if  cell.txtPhNo.text == ""
        {
            Utility.showAlert(message: "Please enter your phone number", vc: self)
            return false
        }
            
        else if cell.txtEmail.text == "" || cell.txtEmail.text == " "
        {
            Utility.showAlert(message: "Please enter your email" , vc: self)
            return false
        }
        else if (Utility.validateEmail(cell.txtEmail.text!) == false)
        {
            Utility.showAlert(message: "Please enter a valid email", vc: self)
            return false
        }
        else if (Utility.checkTextSufficientComplexity(text: cell.txtPass.text!) == false)
        {
            Utility.showAlert(message: "password should be one upercase , one lower case, one special character & one number", vc: self)
            return false
        }
        else if ((cell.txtPass.text?.isEmpty)!) || cell.txtPass.text == " "
        {
            Utility.showAlert(message: "Please enter your password", vc: self)
            return false
        }
        else if ((cell.txtPass.text?.count)! < 6)
        {
            Utility.showAlert(message:"Password must be 6 character", vc: self)
            return false
        }
            
        else if (cell.txtConfirmPass.text?.isEmpty)! || (cell.txtConfirmPass.text) == " "
        {
            Utility.showAlert(message: "Please enter your confirm password", vc: self)
            return false
        }
        else if (cell.txtPass.text != cell.txtConfirmPass.text)
        {
            Utility.showAlert(message: "Password mismatch!", vc: self)
            return false
        }
        else {
            return true
        }
    }

}

extension ViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "SignupCell") as! SignupCell
        cell.selectionStyle = .none
       
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension UITextField {
    func placeholderColor(_ color: UIColor){
        var placeholderText = ""
        if self.placeholder != nil{
            placeholderText = self.placeholder!
        }
        self.attributedPlaceholder = NSAttributedString(string: placeholderText, attributes: [NSAttributedString.Key.foregroundColor : color])
    }
}




class FirebaseAuthManager {
  
    func createUser(email: String, password: String, completionBlock: @escaping (_ success: Bool) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) {(authResult, error) in
            if let user = authResult?.user {
                print(user)
                completionBlock(true)
            } else {
                completionBlock(false)
            }
        }
    }
    
}

