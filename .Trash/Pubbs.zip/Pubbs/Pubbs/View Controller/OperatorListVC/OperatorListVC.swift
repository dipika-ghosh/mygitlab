//
//  OperatorListVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 05/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseDatabase
class OperatorListVC: UIViewController {

    @IBOutlet weak var tblVwOperator: UITableView!
    @IBOutlet weak var myContentVw: UIView!
    var cell : OperatorListCell = OperatorListCell()
    var areaNameArr = [String]()
    var areaIdsArr = [String]()
    var areaNamesArr = [String]()
    var areaHeroIdsArr = [String]()
    var areaHeroNamesArr = [String]()
    var areaGarbageIdsArr = [String]()
    var areaGarbageNamesArr = [String]()
    var currentCityName : String?
    var station = [[String: Any]]()
    var stationHero = [[String: Any]]()
    var stationGarbage = [[String: Any]]()
    var MyAreaListArr = [[String: Any]]()
    var allData = NSDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()

        self.currentCityName = self.currentCityName?.uppercased()
        //print("my city\(self.currentCityName!)")
       //self.currentCityName = "KHARAGPUR"
       setupUI()
        getOlaData()
       
        
        DispatchQueue.main.asyncAfter(deadline: .now(), execute: {
           // self.getOlaData()
        })
    }
    
    @IBAction func bttnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func getOlaData(){
        // DataManager.shared.showLoader()
        let rf = Database.database().reference(fromURL: "https://iitpubbsuser.firebaseio.com/")
        rf.observeSingleEvent(of: .value, with: { snapshot in
            
            if !snapshot.exists() { return }
           
            self.allData = snapshot.value as! NSDictionary
            for (key,value) in self.allData{
                print(key)
                let zoneValue = (snapshot.childSnapshot(forPath:key as! String).childSnapshot(forPath: "Zone").value as? NSDictionary) ?? [:]
                print(zoneValue)
                if zoneValue != [:]{
                    for (zoneKey,ZoneValue) in zoneValue{
                        let mykey = zoneKey as! String
                        if mykey ==  self.currentCityName{
                            self.areaNameArr.append(key as! String)
                           
                            self.MyAreaListArr.append(zoneValue as! [String : Any])
                            
                        }
                        
                    }
                }
                
        }
            print("=======",self.MyAreaListArr)
   
            self.tblVwOperator.reloadData()
//        let ref = Database.database().reference(withPath: "Ola")
//        ref.observeSingleEvent(of: .value, with: { snapshot in
//
//            if !snapshot.exists() { return }
//
//            // print(snapshot) // Its print all values including Snap (User)
//
//            print(snapshot.value!)
//
//            let Zonename = snapshot.childSnapshot(forPath: "Zone").value as? [String: Any]
//            let stationDic = snapshot.childSnapshot(forPath: "Station").value as? [String: Any]
//            let stationDicValue = stationDic?.values
//            for item in stationDicValue! {
//                self.station.append(item as! [String : Any])
//            }
//
//            let key = snapshot.childSnapshot(forPath: "KHARAGPUR").key
//             let AreaList = snapshot.childSnapshot(forPath: "AreaList").key
//            let city = Zonename?["KHARAGPUR"] as? [String: Any]
//            let arealit = city?["AreaList"] as? [String: Any]
//            print("dipika print arealit==",arealit)
//            //let area = arealit?.keys
//            let area = arealit?.values
//            for item in area! {
//                let id = (item as AnyObject).value(forKey: "id") as? String ?? ""
//                let name = (item as AnyObject).value(forKey: "name") as? String ?? ""
//                self.areaNamesArr.append(name)
//                self.areaIdsArr.append(id)
//            }
//            //  let id = arealit?.first?["id"] as? String
//            print("=====",Zonename)
//            print("=====",key)
//             print("=====",AreaList)
//            if key == self.currentCityName{
//                if AreaList != "" {
//                     self.areaNameArr.append("Ola")
//                     self.getHeroHexiData()
//                }
//
//            }
//
        })
    }
    
        func getHeroHexiData(){
            let ref = Database.database().reference(withPath: "HeroHexi")
            ref.observeSingleEvent(of: .value, with: { snapshot in
                
                if !snapshot.exists() { return }
                
                // print(snapshot) // Its print all values including Snap (User)
                
                print(snapshot.value!)
                
                let Zonename = snapshot.childSnapshot(forPath: "Zone").value as? [String: Any]
                let stationDic = snapshot.childSnapshot(forPath: "Station").value as? [String: Any]
                let stationDicValue = stationDic?.values
                for item in stationDicValue! {
                    self.stationHero.append(item as! [String : Any])
                }
                print("=====",Zonename!)
                let key = snapshot.childSnapshot(forPath: "KHARAGPUR").key
                let AreaList = snapshot.childSnapshot(forPath: "AreaList").key
                print("=====",key)
                print("=====",AreaList)
                let city = Zonename?["KHARAGPUR"] as? [String: Any]
                let arealit = city?["AreaList"] as? [String: Any]
                print("HeroHexi print arealit==",arealit)
                //let area = arealit?.keys
                if let area = arealit?.values {
                    for item in area {
                        let id = (item as AnyObject).value(forKey: "id") as? String ?? ""
                        let name = (item as AnyObject).value(forKey: "name") as? String ?? ""
                        self.areaHeroNamesArr.append(name)
                        self.areaHeroIdsArr.append(id)
                    }
                }
                if key == self.currentCityName{
                    if AreaList != ""{
                        self.areaNameArr.append("HeroHexi")
                        self.getGarbageData()
                    }
                    
                }
                
            })
    }
        
        func getGarbageData(){
            let ref = Database.database().reference(withPath: "Garbage")
            ref.observeSingleEvent(of: .value, with: { snapshot in
                
                if !snapshot.exists() { return }
                
                // print(snapshot) // Its print all values including Snap (User)
                
                print(snapshot.value!)
                
                let Zonename = snapshot.childSnapshot(forPath: "Zone").value as? NSDictionary ?? [:]
                print("=====",Zonename)
                let stationDic = snapshot.childSnapshot(forPath: "Station").value as? [String: Any]
                if let stationDicValue = stationDic?.values {
                    for item in stationDicValue {
                        self.stationGarbage.append(item as! [String : Any])
                    }
                }
                let key = snapshot.childSnapshot(forPath: "KHARAGPUR").key
                let AreaList = snapshot.childSnapshot(forPath: "AreaList").key
                print("=====",key)
                print("=====",AreaList)
                let city = Zonename["KHARAGPUR"] as? [String: Any]
                let arealit = city?["AreaList"] as? [String: Any]
                print("HeroHexi print arealit==",arealit)
                //let area = arealit?.keys
                if let area = arealit?.values {
                    for item in area {
                        let id = (item as AnyObject).value(forKey: "id") as? String ?? ""
                        let name = (item as AnyObject).value(forKey: "name") as? String ?? ""
                        self.areaGarbageNamesArr.append(name)
                        self.areaGarbageIdsArr.append(id)
                    }
                }
                if Zonename != [:]{
                    if key == self.currentCityName{
                        if AreaList != ""{
                            self.areaNameArr.append("Garbage")
                            
                        }
                        
                    }
                }
               
                self.tblVwOperator.reloadData()
                DataManager.shared.hideLoader()
                
            })
        }
    func setupUI(){
        myContentVw.clipsToBounds = true
        myContentVw.layer.masksToBounds = false;
        myContentVw.layer.cornerRadius = 25
        myContentVw.layer.shadowColor = UIColor.lightGray.cgColor
        myContentVw.layer.shadowOffset = CGSize(width: 0, height: 4)
        myContentVw.layer.shadowOpacity = 1.0
        tblVwOperator.delegate = self
        tblVwOperator.dataSource = self
        tblVwOperator.tableFooterView = UIView()
        tblVwOperator.separatorStyle = .none
    }
   
}
extension OperatorListVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.areaNameArr = self.areaNameArr.uniqueOrdered()
        if self.areaNameArr.count != 0{
             return self.areaNameArr.count
        }else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "OperatorListCell") as! OperatorListCell
        cell.selectionStyle = .none
        self.areaNameArr = self.areaNameArr.uniqueOrdered()
        if self.areaNameArr.count != 0{
            cell.lblName.text = self.areaNameArr[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        switch self.areaNameArr[indexPath.row] {
//        case "Ola":
//            vc.arrAreaList = areaIdsArr
//            vc.arrNameAreaList = areaNamesArr
//            vc.stationList = station
//        case "HeroHexi":
//            vc.arrAreaList = areaHeroIdsArr
//            vc.arrNameAreaList = areaHeroNamesArr
//            vc.stationList = stationHero
//        default:
//            vc.arrAreaList = areaGarbageIdsArr
//            vc.arrNameAreaList = areaGarbageNamesArr
//            vc.stationList = stationGarbage
//        }
        
        
      
        
       // if ((self.MyAreaListArr[indexPath.row]) != [Any]){
              let vc = self.storyboard?.instantiateViewController(withIdentifier: "ArealistVC") as! ArealistVC
             vc.myArealist = self.MyAreaListArr[indexPath.row]
        vc.cityName = self.currentCityName!
            for controler in self.navigationController?.viewControllers ?? [] {
                if controler is HomeVC {
                    let homeVc = controler as! HomeVC
                    vc.delegate = homeVc
                }
            }
            self.navigationController?.pushViewController(vc, animated: true)
       // }
       
        
       
    }
    
}
extension Sequence where Iterator.Element: Hashable {
    func unique() -> [Iterator.Element] {
        return Array(Set<Iterator.Element>(self))
    }
    
    func uniqueOrdered() -> [Iterator.Element] {
        return reduce([Iterator.Element]()) { $0.contains($1) ? $0 : $0 + [$1] }
    }
}

//for (key,value) in self.allData{
//    print(key)
//    let allValue : NSDictionary = value as! NSDictionary
//    for (areaKey,areaValue) in allValue{
//        let subKey = areaKey as! String
//        if subKey == "Zone"{
//            let ZoneValue : NSDictionary = areaValue as! NSDictionary
//            for (zoneKey,ZoneValue) in ZoneValue {
//                let subKey = zoneKey as! String
//                if subKey == self.currentCityName{
//                    self.areaNameArr.append(key as! String)
//                    let myZoneValue : NSDictionary = ZoneValue as! NSDictionary
//                    for (item,itemValue) in myZoneValue{
//                        let itemKey = item as! String
//                        if itemKey == "AreaList"{
//                            self.MyAreaListArr.append(itemValue as! [String : Any])
//                        }
//                    }
//
//                }
//                print("dipika===",self.MyAreaListArr.count)
//            }
//
//        }
//
//    }
//
//}
