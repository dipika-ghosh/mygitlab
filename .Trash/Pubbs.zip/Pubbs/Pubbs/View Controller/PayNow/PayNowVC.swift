//
//  PayNowVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 09/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class PayNowVC: UIViewController {

    @IBOutlet weak var tblPayNow: UITableView!
    @IBOutlet weak var lblPlanPrice: UILabel!
    @IBOutlet weak var lblPlanName: UILabel!
    var cell : PayNowCell = PayNowCell()
    var dictSubscriptionDetails = [String: Any]()
    var dictBankDetails = [String: Any]()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    func setupUI(){
//        myContentVW.clipsToBounds = true
//        myContentVW.layer.masksToBounds = false;
//        myContentVW.layer.cornerRadius = 25
//        myContentVW.layer.shadowColor = UIColor.lightGray.cgColor
//        myContentVW.layer.shadowOffset = CGSize(width: 0, height: 4)
//        myContentVW.layer.shadowOpacity = 1.0
        tblPayNow.delegate = self
        tblPayNow.dataSource = self
        tblPayNow.tableFooterView = UIView()
        tblPayNow.separatorStyle = .none
        self.lblPlanPrice.text = "₹ " + ((dictSubscriptionDetails["subscriptionPlanPrice"] as? String) ?? "")
    }
    
    @IBAction func payNowAction(_ sender: Any) {
        
        
    }
    @IBAction func bttnBackActn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension PayNowVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "PayNowCell") as! PayNowCell
        cell.selectionStyle = .none
        cell.lblPlanName.text = (dictSubscriptionDetails["subscriptionPlanName"] as? String) ?? ""//arrSubscriptionData[indexPath.row]["subscriptionPlanName"] as? String
        cell.lblPlanPrice.text = "₹ " + ((dictSubscriptionDetails["subscriptionPlanPrice"] as? String) ?? "")
        cell.lblOtherPlanName.text = "Other Plan"
        cell.lblOtherPlanPrice.text = "₹ 0"
        cell.lblTotalPlanPrice.text = "₹ " + ((dictSubscriptionDetails["subscriptionPlanPrice"] as? String) ?? "")
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        let dictSubscription = arrSubscriptionData[indexPath.row]
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PayNowVC") as! PayNowVC
//        vc.dictSubscriptionDetails = dictSubscriptionDetails
//        vc.dictBankDetails = dictBankDetails
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
