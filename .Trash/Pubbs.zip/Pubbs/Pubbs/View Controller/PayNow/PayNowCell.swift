//
//  PayNowCell.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 09/02/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class PayNowCell: UITableViewCell {

    @IBOutlet weak var lblPlanName: UILabel!
    @IBOutlet weak var lblOtherPlanName: UILabel!
    @IBOutlet weak var lblPlanPrice: UILabel!
    @IBOutlet weak var lblOtherPlanPrice: UILabel!
    @IBOutlet weak var lblTotalPlanPrice: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
