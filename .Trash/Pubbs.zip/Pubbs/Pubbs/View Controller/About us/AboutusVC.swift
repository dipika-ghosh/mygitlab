//
//  AboutusVC.swift
//  Pubbs
//
//  Created by Dipika Ghosh on 11/01/20.
//  Copyright © 2020 Dipika Ghosh. All rights reserved.
//

import UIKit

class AboutusVC: UIViewController {
    @IBOutlet weak var contentVw: UIView!
    
    @IBOutlet weak var tblVwAboutus: UITableView!
    var cell : AboutUsCell = AboutUsCell()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        contentVw.clipsToBounds = true
        contentVw.layer.masksToBounds = false;
        contentVw.layer.cornerRadius = 25
        contentVw.layer.shadowColor = UIColor.lightGray.cgColor
        contentVw.layer.shadowOffset = CGSize(width: 0, height: 4)
        contentVw.layer.shadowOpacity = 1.0
        tblVwAboutus.delegate = self
        tblVwAboutus.dataSource = self
        tblVwAboutus.tableFooterView = UIView()
        tblVwAboutus.separatorStyle = .none
    }
    @IBAction func backBttn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bttnWebsite(_ sender: Any) {
        let url = URL(string: "https://pubbs.in")!
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
            //If you want handle the completion block than
            UIApplication.shared.open(url, options: [:], completionHandler: { (success) in
                print("Open url : \(success)")
            })
        }
    }
    
}
extension AboutusVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cell = tableView.dequeueReusableCell(withIdentifier: "AboutUsCell") as! AboutUsCell
        cell.selectionStyle = .none
        cell.lblDetails.text = "Welcome to PUBBS, your first source for different types of intelligent locks for bicycles in India.We are dedicated to providing you with the best public bicycle sharing, concentrating on Hardware Communication, Mobile Management System,We are dedicated to providing you with the best public bicycle sharing, concentrating on Hardware Communication, Mobile Management System,and Smart Lock Mechanisms. Pubbs is a technology platform for innovative bicycle-sharing to address this last mile problem. It helps people to cover a short distance at very negligible costs without waiting. Our dream is to overcome micro-mobility with their bicycle sharing app for the billions of Indians.The PUBBS, headed by Professor Debapratim Pandit of Indian Institute of Technology, Kharagpur, Architecture and Regional Planning, has come a long way since the start of its venture. As Mr. Pandit began first, his enthusiasm for greater urban mobility led his team to build this lock that can be used by anyone without any special modifications or instructions in order to provide PUBBS with an unforgettable ride. We now serve customers across the country and look forward to transforming our passion into our own webpage. We hope you are as happy to offer our products to your customers. Please feel free to contact us if you have any questions or comments.We believe in building healthier neighbourhoods that are less congested. Not only is cycling an excellent form of exercise, in some of the most congested cities in the world,it is likely to get you quicker. Together, we will create a positive shift in the urban landscape of our city by reducing congestion."
        let yourAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        let yourOtherAttributes = [NSAttributedString.Key.foregroundColor: UIColor.blue]
        
        let partOne = NSMutableAttributedString(string: "Website Details : ", attributes: yourAttributes)
        let partTwo = NSMutableAttributedString(string: "https://pubbs.in", attributes: yourOtherAttributes)
        
        let combination = NSMutableAttributedString()
        
        combination.append(partOne)
        combination.append(partTwo)
        
        
        
        cell.lblWebsite.attributedText = combination
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    
}
